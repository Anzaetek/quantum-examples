# finance_lab → quantum-finance migration guide

> **1:1 swap-in reference** (FINANCE_LAB_PORT_PLAN Phase 17.5). For each
> finance_lab Python workflow, the equivalent pure-Rust `quantum-finance`
> command. Compute is 1:1 (numeric parity gates in [`TESTING.md`](../TESTING.md)
> §5.13–§5.19); plotting is replaced by numeric artifacts (notebooks render
> them). The authoritative gap list is [`FINANCE_LAB_PORT_PLAN.md` §4d](../FINANCE_LAB_PORT_PLAN.md).

## Setup

```bash
# Repo (dev): commands go through cargo.
source scripts/env.sh                       # libtorch for the libtorch-linked CLI
cargo run -q -p quantum-finance -- <cmd>

# Dist (shipped binary): set QF_BIN, then the run scripts swap in 1:1.
export QF_BIN=<dist>/bin/quantum-finance
bash examples/finance/run_all.sh            # RUN_FULL=1 for the training workflows
```

No Python is required at run time — the reference Python is used only offline to
mint committed golden fixtures.

## Workflow swap-in table

| finance_lab (Python) | quantum-finance (Rust) | Notes / parity |
|----------------------|------------------------|----------------|
| `timegan` (TimeGAN train) | `quantum-finance timegan` | three-phase schedule; convergence gate (§5.6) |
| `timegan_qcbm` (QCBM-latent hybrid) | `quantum-finance timegan-qcbm` | frozen-QCBM latent (Phase 4) |
| TimeGAN post-hoc metrics (`discriminative_score`, `predictive_score`) | `quantum-finance timegan-eval` | synth beats noise on both metrics (§5.17) |
| `ctimegan` (Conditional TimeGAN) | `quantum-finance ctimegan` | LearnableAlphaBeta + ConditionalGenerator + regime conditioning (§5.19) |
| `ctimegan_qcbm` | `quantum-finance ctimegan-qcbm` | conditional generator + QCBM latent (§5.19) |
| `regime_classify` regime_gen (`--method hmm`) | `quantum-finance regime-gen [csv] [out.csv]` | features ≤1e-10 vs pandas; HMM scaler exact vs sklearn (§5.14) |
| `regime_classify` train (DNN/QNN/boosting) | `quantum-finance regime-classify train --model {dnn,qnn,qnn-toy,qnn-rich,qnn-pqc,gbdt,xgb,lightgbm}` | DNN/GBDT within 5pp of sklearn (§5.16) |
| `arch_search` (`cli_finetune`) | `quantum-finance arch-search finetune --model {gbdt,mlp} --n-trials N --walk-folds K [--out-csv f]` | TPE + macro-F1 walk-forward (§5.18) |
| `arch_search` (`cli_trainonce`) | `quantum-finance arch-search trainonce --model {gbdt,mlp}` | single midpoint eval (§5.18) |
| QCBM on copula innovations | `quantum-finance qcbm` | PennyLane `probs` parity ≤1e-10 (§5.5) |
| (real-data backtest) | `quantum-finance xauusd [csv]` | real XAUUSD; cuts drawdown vs B&H (§5.13) |
| regime-strategy backtest | `quantum-finance backtest` | walk-forward equity/PnL/drawdown (§5.11) |

## Flag mapping (regime-classify train)

| Python flag | Rust flag | Default |
|-------------|-----------|---------|
| `--data` | `--data <csv>` | in-memory XAUUSD HMM labels |
| `--model` | `--model` | `dnn` |
| `--test-size` / `--val-size` | `--test-size` / `--val-size` | `0.2` / `0.1` |
| `--seed` | `--seed` | `0` |
| `--time-ordered-split` | (default; `--random-split` to disable) | causal |
| `--balance-train` | `--balance-train` | off |
| `--dnn-*` (hidden/depth/dropout/lr/epochs/batch/patience) | `--dnn-hidden/--dnn-depth/--dnn-dropout/--dnn-lr/--dnn-epochs/--dnn-batch/--dnn-patience` | 128/2/0.1/1e-3/50/64/8 |
| `--no-dnn-classw` | `--no-dnn-classw` | class weights on |
| `--qnn-*` (n-qubits/n-layers/model/hidden-dim) | `--qnn-n-qubits/--qnn-n-layers/--qnn-hidden-dim/--qnn-steps/--qnn-max-rows` | preset |

## Unsupported / deferred (with status)

| finance_lab feature | Status | See |
|---------------------|--------|-----|
| `catboost` model | **unsupported** — no maintained Rust CatBoost | §4d |
| `tabpfn*` models (5 paths) | **pending** — Rust TabPFN lib in prep; gated behind a `tabpfn` Cargo feature | §4c |
| `xgb`/`lightgbm` exactness | **functional 1:1** — served by a pure-Rust Friedman GBDT (not the C++ libs); within 5pp of sklearn GBDT | §4d |
| `pqc_*`/`qfeat_*` (quantum-feature boosting) | **pending** — needs the QNN→GBDT feature wiring | §4d |
| matplotlib plotting (candlesticks, PCA, fan charts, 3D) | **out of toolkit (by rule)** — CLI emits numeric artifacts; notebooks render | §4d |
| ctimegan boundary-continuity / scenarios / cached-Z | **deferred** — core conditional generator landed | §4d |
| `{train,generate,eval}` sub-verb nesting | **deferred** — current flat subcommands expose the same compute | §4d (17.1) |

## The `run_*.sh` scripts

`examples/finance/` mirrors finance_lab's per-workflow shell scripts, driving
the Rust CLI with numeric assertions:

| Script | Workflow |
|--------|----------|
| `run_all.sh` | orchestrator (fast path; `RUN_FULL=1` adds training workflows) |
| `run_xauusd.sh` | real XAUUSD backtest |
| `run_regime.sh` | regime label (`regime-gen`) + classify (`regime-classify train`) |
| `run_timegan.sh` | TimeGAN train + post-hoc metrics |
| `run_ctimegan.sh` | conditional TimeGAN (+ QCBM latent) |
| `run_archsearch.sh` | TPE architecture search |

All scripts honour `QF_BIN` (dist binary) and `DATA_DIR`/`XAUUSD` (data paths).
