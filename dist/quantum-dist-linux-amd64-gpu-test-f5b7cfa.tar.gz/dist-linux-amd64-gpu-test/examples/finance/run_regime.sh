#!/usr/bin/env bash
# 1:1 swap-in for finance_lab's regime generate+classify run. Labels regimes
# with the Gaussian HMM (`regime-gen`), then trains the supervised classifier
# (`regime-classify train`). Numeric anchors (deterministic).
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"

GEN="$(qf regime-gen "$SERIES")"
echo "$GEN"
assert_line "$GEN" "n_rows 5438"
assert_line "$GEN" "regime0_frac 0.3617"

# Label the synthetic series, then classify on those labels via --data (the
# default path is not used so no real-data fixture is required).
LAB="$(mktemp /tmp/fin-regime-XXXXXX.csv)"
qf regime-gen "$SERIES" "$LAB" >/dev/null 2>&1
CLF="$(qf regime-classify train --model dnn --data "$LAB")"
rm -f "$LAB"
echo "$CLF"
assert_line "$CLF" "n_train 3806 n_val 544 n_test 1088"
VAL="$(echo "$CLF" | sed -n 's/^val_acc //p')"
assert_ge "$VAL" 0.88 "regime val_acc"
echo "FIN OK: regime (label + classify, val_acc=$VAL)"
