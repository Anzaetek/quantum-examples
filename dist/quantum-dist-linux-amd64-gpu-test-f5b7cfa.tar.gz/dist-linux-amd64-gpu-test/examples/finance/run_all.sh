#!/usr/bin/env bash
# Orchestrator for the finance_lab-port run scripts (FINANCE_LAB_PORT_PLAN
# Phase 17.3) — the 1:1 swap-in for finance_lab's `run_all.sh`, driving the
# Rust `quantum-finance` CLI. Numbers only; prints "RUN OK" on success.
#
# Fast deterministic path by default (qcbm + xauusd + regime label/classify).
# Set RUN_FULL=1 to also run the model-training workflows (timegan, ctimegan,
# arch-search) — slower, but the same numeric gates.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"

echo "== QCBM =="
QCBM="$(qf qcbm)"
echo "$QCBM"
assert_line "$QCBM" "final_kl 0.000000"

echo "== Backtest (synthetic series) =="
bash "$HERE/run_backtest.sh"

echo "== Regime label + classify =="
bash "$HERE/run_regime.sh"

if [ "${RUN_FULL:-0}" = "1" ]; then
    echo "== TimeGAN (+ eval) =="
    bash "$HERE/run_timegan.sh"
    echo "== Conditional TimeGAN (+ qcbm) =="
    bash "$HERE/run_ctimegan.sh"
    echo "== Architecture search =="
    bash "$HERE/run_archsearch.sh"
fi

echo "RUN OK: finance_lab-port workflows verified numerically via quantum-finance"
