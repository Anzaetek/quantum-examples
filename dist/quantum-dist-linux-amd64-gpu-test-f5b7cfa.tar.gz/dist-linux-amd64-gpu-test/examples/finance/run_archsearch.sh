#!/usr/bin/env bash
# 1:1 swap-in for finance_lab's architecture-search run: TPE `finetune` over the
# GBDT model, macro-F1 on a walk-forward CV. Numeric gate: the search selects
# (best ≥ mean) above the macro-F1 floor.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"

AS="$(qf arch-search finetune --model gbdt --n-trials 6 --walk-folds 2 --max-rows 1200)"
echo "$AS"
assert_line "$AS" "selected 1"
BEST="$(echo "$AS" | sed -n 's/^best_macro_f1 //p')"
assert_ge "$BEST" 0.85 "arch-search best_macro_f1"
echo "FIN OK: arch-search (TPE finetune, best_f1=$BEST)"
