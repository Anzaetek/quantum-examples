#!/usr/bin/env bash
# 1:1 swap-in for finance_lab's TimeGAN run: train (`timegan`) + post-hoc
# discriminative/predictive evaluation (`timegan-eval`). Numeric gate: the
# synthetic data beats the noise baseline under both metric nets.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"

TG="$(qf timegan)"
echo "$TG"
assert_line "$TG" "e_loss0_improved 1"

EV="$(qf timegan-eval)"
echo "$EV"
assert_line "$EV" "synth_beats_noise 1"
echo "FIN OK: timegan (train + post-hoc metrics)"
