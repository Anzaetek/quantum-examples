#!/usr/bin/env bash
# Shared helpers for the finance_lab-port run scripts (FINANCE_LAB_PORT_PLAN
# Phase 17.3). These drive the **Rust** `quantum-finance` CLI 1:1 on compute —
# the swap-in for finance_lab's Python `run_*.sh`. Numeric-only checks.
#
# Binary resolution: in a dist, set `QF_BIN=<dist>/bin/quantum-finance`; in the
# repo (default) the commands go through `cargo run -q -p quantum-finance --`.
# Data: `DATA_DIR` defaults to the repo's `examples/data`.

set -euo pipefail

QF_BIN="${QF_BIN:-}"
DATA_DIR="${DATA_DIR:-examples/data}"
# SYNTHETIC series only — these public run-scripts ship in the dist, which must
# contain NO real market data (see demo/data/README.md). SERIES is a fake
# instrument; XAUUSD kept as an alias so older callers keep working.
SERIES="${SERIES:-$DATA_DIR/synthetic_daily.csv}"
XAUUSD="$SERIES"

# Re-establish the libtorch runtime path. macOS SIP strips DYLD_* (and Linux
# strips nothing, but we mirror for symmetry) every time a SIP-protected
# /bin/bash is exec'd — and these scripts are launched via `bash run_all.sh`,
# so by the time we run the prebuilt QF_BIN (which has no LC_RPATH) the loader
# path is gone. LIBTORCH is a plain var (not DYLD_*/LD_*) and survives the
# strip, so we rebuild the loader path from it here. (cargo-run path is
# unaffected; this only matters for the stripped QF_BIN binary.)
if [ -n "${LIBTORCH:-}" ]; then
    export LIBTORCH_BYPASS_VERSION_CHECK=1
    case "$(uname -s)" in
        Darwin) export DYLD_LIBRARY_PATH="$LIBTORCH/lib${DYLD_LIBRARY_PATH:+:$DYLD_LIBRARY_PATH}" ;;
        Linux)  export LD_LIBRARY_PATH="$LIBTORCH/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ;;
    esac
fi

# Run the quantum-finance CLI (dist binary or cargo).
qf() {
    if [ -n "$QF_BIN" ]; then
        "$QF_BIN" "$@"
    else
        cargo run -q -p quantum-finance -- "$@"
    fi
}

fin_fail() { echo "FIN FAIL: $1" >&2; exit 1; }

# assert_line <output> <exact-line>   — output must contain the exact line.
assert_line() {
    echo "$1" | grep -q "^$2$" || fin_fail "expected line: $2"
}

# assert_ge <value> <floor> <label>   — numeric value ≥ floor.
assert_ge() {
    awk "BEGIN{exit !($1 >= $2)}" || fin_fail "$3: $1 < $2"
}
