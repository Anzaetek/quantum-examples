#!/usr/bin/env bash
# SMA-trend regime backtest on the bundled SYNTHETIC daily series. Numeric
# anchors (deterministic). The data is SYNTHETIC — not real market data
# (see demo/data/README.md).
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"

OUT="$(qf xauusd "$SERIES")"
echo "$OUT"
assert_line "$OUT" "n_bars 5462"
assert_line "$OUT" "close_last 1114.222"
assert_line "$OUT" "strat_lower_dd 1"
echo "FIN OK: backtest (synthetic)"
