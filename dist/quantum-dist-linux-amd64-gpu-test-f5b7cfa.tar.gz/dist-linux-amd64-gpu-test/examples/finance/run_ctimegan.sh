#!/usr/bin/env bash
# 1:1 swap-in for finance_lab's Conditional-TimeGAN runs: the regime-conditioned
# generator (`ctimegan`) and the QCBM-latent hybrid (`ctimegan-qcbm`). Numeric
# gate: conditioning is real (per-regime synthetic means differ).
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"

CT="$(qf ctimegan)"
echo "$CT"
assert_line "$CT" "conditioning_works 1"
assert_line "$CT" "alpha_beta_positive 1"

CTQ="$(qf ctimegan-qcbm)"
echo "$CTQ"
assert_line "$CTQ" "conditioning_works 1"
echo "FIN OK: ctimegan (+ qcbm latent)"
