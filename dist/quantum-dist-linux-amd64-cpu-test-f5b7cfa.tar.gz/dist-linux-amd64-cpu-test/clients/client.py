#!/usr/bin/env python3
"""
Command-line wrapper around the ``quantum_client`` module.

Mirrors the commands exposed by the Rust client under
``examples/client-rust/`` one-for-one. Both clients speak the same
length-prefixed JSON protocol; this file exists so Python users don't
need to understand socket framing to try the server.

Usage::

    python client.py [--socket ENDPOINT] [--token TOKEN] <command> [args]

Commands::

    ping
    info [FILE]                  # defaults to bundled Bell QASM
    optimize [FILE]
    compile FILE TARGET          # target = qasm|json|opticqasm|lean4|rocq
    demo

Environment::

    QUANTUM_SOCKET               overrides --socket (default /tmp/quantum.sock)
    QUANTUM_SERVER_TOKEN         bearer token for TCP mode
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Tuple

from quantum_client import Client, ServerError, DEFAULT_SOCKET


BELL_QASM = """OPENQASM 2.0;
include "qelib1.inc";
qreg q[2];
creg c[2];
h q[0];
cx q[0], q[1];
measure q[0] -> c[0];
measure q[1] -> c[1];
"""


def _format_from_extension(path: str) -> str:
    if path.endswith(".json"):
        return "json"
    if path.endswith(".opticqasm"):
        return "opticqasm"
    return "qasm"


def _load_source(arg: str | None) -> Tuple[str, str]:
    if arg is None:
        return BELL_QASM, "qasm"
    with open(arg, "r", encoding="utf-8") as f:
        return f.read(), _format_from_extension(arg)


def cmd_ping(client: Client) -> None:
    print(json.dumps(client.ping(), indent=2, sort_keys=True))


def cmd_info(client: Client, file: str | None) -> None:
    source, fmt = _load_source(file)
    print(json.dumps(client.info(source, format=fmt), indent=2, sort_keys=True))


def cmd_optimize(client: Client, file: str | None) -> None:
    source, fmt = _load_source(file)
    result = client.optimize(source, format=fmt, iterations=3)
    print(json.dumps(result, indent=2, sort_keys=True))


def cmd_compile(client: Client, file: str, target: str) -> None:
    source, fmt = _load_source(file)
    result = client.compile(source, target=target, format=fmt)
    print(json.dumps(result, indent=2, sort_keys=True))


def cmd_demo(client: Client) -> None:
    print("=== quantum-server demo (python) ===")
    try:
        print("  ping  →", client.ping())
    except ServerError as e:
        print("  ping  ×", e)
        return

    info = client.info(BELL_QASM)
    print(
        "  info  → num_qubits={num_qubits} num_clbits={num_clbits}"
        " gate_count={gate_count} depth={depth}".format(**info)
    )

    redundant = (
        "OPENQASM 2.0;\ninclude \"qelib1.inc\";\nqreg q[1];\n"
        "h q[0];\nh q[0];\nx q[0];\nx q[0];\n"
    )
    opt = client.optimize(redundant, iterations=3)
    print(
        "  opt   → {gate_count_before} gates → {gate_count_after} gates".format(**opt)
    )

    lean = client.compile(BELL_QASM, target="lean4")
    first_lines = lean["output"].splitlines()[:4]
    print("  lean4 →", len(lean["output"]), "bytes")
    for line in first_lines:
        print("          ", line)


def main() -> int:
    parser = argparse.ArgumentParser(prog="client.py", description=__doc__)
    parser.add_argument(
        "--socket",
        default=os.environ.get("QUANTUM_SOCKET", DEFAULT_SOCKET),
        help="Unix socket path or tcp:HOST:PORT endpoint",
    )
    parser.add_argument(
        "--token",
        default=os.environ.get("QUANTUM_SERVER_TOKEN"),
        help="bearer token for TCP mode",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("ping", help="health check")

    p_info = subparsers.add_parser("info", help="circuit metadata")
    p_info.add_argument("file", nargs="?", help="circuit file (default: Bell QASM)")

    p_opt = subparsers.add_parser("optimize", help="optimize and return QASM")
    p_opt.add_argument("file", nargs="?", help="circuit file")

    p_comp = subparsers.add_parser("compile", help="compile to another format")
    p_comp.add_argument("file", help="circuit file")
    p_comp.add_argument("target", choices=["qasm", "json", "opticqasm", "lean4", "rocq"])

    subparsers.add_parser("demo", help="run ping + info + optimize + compile once")

    args = parser.parse_args()

    try:
        with Client(args.socket, token=args.token) as client:
            if args.command == "ping":
                cmd_ping(client)
            elif args.command == "info":
                cmd_info(client, args.file)
            elif args.command == "optimize":
                cmd_optimize(client, args.file)
            elif args.command == "compile":
                cmd_compile(client, args.file, args.target)
            elif args.command == "demo":
                cmd_demo(client)
    except FileNotFoundError as e:
        print(f"connect failed: {e}", file=sys.stderr)
        print(
            "hint: start the server with\n"
            "    quantum-server --listen unix:{}".format(DEFAULT_SOCKET),
            file=sys.stderr,
        )
        return 1
    except ServerError as e:
        print(f"rpc error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
