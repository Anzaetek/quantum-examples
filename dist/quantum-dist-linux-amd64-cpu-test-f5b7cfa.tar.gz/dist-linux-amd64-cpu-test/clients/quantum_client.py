"""
Minimal reference client for the quantum-server RPC protocol.

Depends only on the Python standard library (socket, json, struct, os),
so it runs on any interpreter >= 3.8 without pip install. Tested on
CPython 3.13.5 (project .venv), 3.14.3 (homebrew), and 3.9.6 (macOS
system); should work anywhere Python 3.8+ runs.

Usage
-----

As a library:

    from quantum_client import Client

    with Client("/tmp/quantum.sock") as c:
        print(c.ping())
        print(c.info(bell_qasm, format="qasm"))
        print(c.optimize(bell_qasm, iterations=3))
        print(c.compile(bell_qasm, target="lean4")["output"][:200])

As a CLI (see `client.py` next to this file):

    python client.py ping
    python client.py info circuit.qasm
    python client.py optimize circuit.qasm
    python client.py compile circuit.qasm lean4
    python client.py demo

Protocol
--------

Every message is framed as a 4-byte big-endian length followed by a
UTF-8 JSON body. The request/response shape is JSON-RPC 2.0 subset:

    request : {"method": "info", "params": {...}, "id": 1}
    ok      : {"id": 1, "result": {...}}
    error   : {"id": 1, "error": {"code": 400, "message": "..."}}
"""

from __future__ import annotations

import json
import os
import socket
import struct
from typing import Any, Dict, Optional, Union


DEFAULT_SOCKET = "/tmp/quantum.sock"


class ServerError(RuntimeError):
    """Raised when the server returns an `error` field."""

    def __init__(self, code: int, message: str) -> None:
        super().__init__(f"quantum-server error {code}: {message}")
        self.code = code
        self.message = message


class Client:
    """Connection-oriented client for one quantum-server endpoint.

    Accepts either a Unix socket path (``/tmp/quantum.sock`` or
    ``unix:/tmp/quantum.sock``) or a TCP endpoint (``tcp:HOST:PORT``).
    TCP mode requires ``token`` to be set; the client injects
    ``{"auth": token}`` into every request's ``params``.
    """

    def __init__(
        self,
        endpoint: str = DEFAULT_SOCKET,
        token: Optional[str] = None,
        timeout: float = 10.0,
    ) -> None:
        self.endpoint = endpoint
        self.token = token or os.environ.get("QUANTUM_SERVER_TOKEN")
        self.timeout = timeout
        self._sock: Optional[socket.socket] = None
        self._request_id = 0

    # ---- connection management -------------------------------------

    def __enter__(self) -> "Client":
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def connect(self) -> None:
        if self.endpoint.startswith("tcp:"):
            host, _, port = self.endpoint[4:].rpartition(":")
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            sock.connect((host, int(port)))
        else:
            path = self.endpoint[5:] if self.endpoint.startswith("unix:") else self.endpoint
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            sock.connect(path)
        self._sock = sock

    def close(self) -> None:
        if self._sock is not None:
            try:
                self._sock.close()
            finally:
                self._sock = None

    # ---- framing helpers -------------------------------------------

    def _send(self, payload: bytes) -> None:
        assert self._sock is not None, "client not connected"
        self._sock.sendall(struct.pack(">I", len(payload)) + payload)

    def _recv_exact(self, n: int) -> bytes:
        assert self._sock is not None, "client not connected"
        buf = bytearray()
        while len(buf) < n:
            chunk = self._sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("server closed connection")
            buf.extend(chunk)
        return bytes(buf)

    def _recv_message(self) -> Dict[str, Any]:
        (length,) = struct.unpack(">I", self._recv_exact(4))
        body = self._recv_exact(length)
        return json.loads(body.decode("utf-8"))

    # ---- RPC plumbing ----------------------------------------------

    def _call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        if self._sock is None:
            self.connect()
        self._request_id += 1
        body: Dict[str, Any] = {"method": method, "id": self._request_id}
        params = dict(params or {})
        if self.token is not None:
            params["auth"] = self.token
        body["params"] = params
        self._send(json.dumps(body).encode("utf-8"))
        response = self._recv_message()
        if "error" in response and response["error"] is not None:
            err = response["error"]
            raise ServerError(int(err.get("code", 0)), str(err.get("message", "")))
        return response.get("result")

    # ---- methods ---------------------------------------------------

    def ping(self) -> Dict[str, Any]:
        return self._call("ping")

    def info(self, source: str, format: str = "qasm") -> Dict[str, Any]:
        return self._call("info", {"source": source, "format": format})

    def parse(self, source: str, format: str = "qasm") -> Dict[str, Any]:
        return self._call("parse", {"source": source, "format": format})

    def optimize(
        self,
        source: str,
        format: str = "qasm",
        iterations: int = 3,
    ) -> Dict[str, Any]:
        return self._call(
            "optimize",
            {"source": source, "format": format, "iterations": iterations},
        )

    def compile(
        self,
        source: str,
        target: str,
        format: str = "qasm",
    ) -> Dict[str, Any]:
        return self._call(
            "compile",
            {"source": source, "format": format, "target": target},
        )


# ---- module-level convenience wrappers ---------------------------------

def call(
    method: str,
    params: Optional[Dict[str, Any]] = None,
    endpoint: Union[str, Client] = DEFAULT_SOCKET,
    token: Optional[str] = None,
) -> Any:
    """One-shot helper: open a connection, send one request, close.

    Handy for quick scripts that only need a single method call. Re-use
    a ``Client`` instance via ``with Client(...) as c`` for multi-call
    workflows.
    """
    if isinstance(endpoint, Client):
        return endpoint._call(method, params)
    with Client(endpoint, token=token) as c:
        return c._call(method, params)
