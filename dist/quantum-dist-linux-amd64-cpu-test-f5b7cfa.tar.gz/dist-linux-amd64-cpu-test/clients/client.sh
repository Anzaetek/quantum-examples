#!/usr/bin/env bash
# Shell client for quantum-server.
#
# Zero host dependencies by default: if the shipped `quantum-client`
# binary is reachable (next to this script under ../bin, a sibling, or
# on PATH) this script just delegates to it — no python, no jq, no nc.
# It only falls back to the inline `python3` framing helper (+ optional
# `jq` pretty-print) when that binary is absent, so the script still
# works in a bare source checkout. Either way the interface is identical.
#
# Usage:
#   ./client.sh [--socket unix:/path | --socket tcp:HOST:PORT]
#               [--token TOKEN]
#               <command> [args]
#
# Commands (identical to the Rust/Python clients):
#   ping
#   info [FILE]                  # defaults to bundled Bell QASM
#   optimize [FILE]
#   compile FILE TARGET          # target: qasm|json|opticqasm|lean4|rocq
#   demo
#
# Environment:
#   QUANTUM_SOCKET               overrides --socket (default /tmp/quantum.sock)
#   QUANTUM_SERVER_TOKEN         bearer token for TCP mode

set -euo pipefail

SOCKET="${QUANTUM_SOCKET:-/tmp/quantum.sock}"
TOKEN="${QUANTUM_SERVER_TOKEN:-}"

BELL_QASM='OPENQASM 2.0;
include "qelib1.inc";
qreg q[2];
creg c[2];
h q[0];
cx q[0], q[1];
measure q[0] -> c[0];
measure q[1] -> c[1];
'

# Parse flags up to the first positional argument.
while [[ $# -gt 0 ]]; do
    case "$1" in
        --socket) SOCKET="$2"; shift 2;;
        --token)  TOKEN="$2";  shift 2;;
        -h|--help)
            grep -E '^# ' "$0" | sed 's/^# \?//'
            exit 0
            ;;
        *) break;;
    esac
done

if [[ $# -eq 0 ]]; then
    echo "usage: $0 [--socket ENDPOINT] [--token TOKEN] <command> [args]" >&2
    exit 2
fi
CMD="$1"; shift

# --- Prefer the shipped quantum-client binary (zero host deps) ---------------
# Resolve it relative to this script (dist layout: clients/ + bin/), as a
# sibling, or from PATH. When found, delegate verbatim — the binary speaks the
# length-prefixed JSON-RPC natively, so no python/jq/nc is needed at all.
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
QC=""
for cand in "$SELF_DIR/../bin/quantum-client" "$SELF_DIR/quantum-client" "$SELF_DIR/bin/quantum-client"; do
    [ -x "$cand" ] && { QC="$cand"; break; }
done
[ -z "$QC" ] && command -v quantum-client >/dev/null 2>&1 && QC="$(command -v quantum-client)"
if [ -n "$QC" ]; then
    set -- "$CMD" "$@"
    [ -n "$TOKEN" ] && set -- --token "$TOKEN" "$@"
    exec "$QC" --socket "$SOCKET" "$@"
fi
# --- Fallback: no binary on hand → inline python framing ---------------------

# One-shot RPC call. Uses a short inline Python helper so we don't have
# to reinvent length-prefix framing in pure shell. Reads the JSON body
# from stdin, writes the response body to stdout.
#
# Important: we pass the script as `python3 -c` rather than via a
# heredoc, because a heredoc (`python3 - <<EOF`) would itself BE the
# process's stdin and swallow the piped request body.
rpc() {
    local endpoint="$1"
    python3 -c '
import socket
import struct
import sys

endpoint = sys.argv[1]
body = sys.stdin.buffer.read()

if endpoint.startswith("tcp:"):
    host, _, port = endpoint[4:].rpartition(":")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((host, int(port)))
else:
    path = endpoint[5:] if endpoint.startswith("unix:") else endpoint
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(path)

sock.sendall(struct.pack(">I", len(body)) + body)

def recv_exact(n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            sys.stderr.write("server closed connection\n")
            sys.exit(1)
        buf.extend(chunk)
    return bytes(buf)

(length,) = struct.unpack(">I", recv_exact(4))
sys.stdout.buffer.write(recv_exact(length))
sock.close()
' "$endpoint"
}

# Build a JSON params object, optionally injecting the auth token.
build_params() {
    local inner="$1"
    if [[ -n "$TOKEN" ]]; then
        python3 - "$TOKEN" <<PY
import json, sys
inner = json.loads('''${inner}''')
inner["auth"] = sys.argv[1]
print(json.dumps(inner))
PY
    else
        printf '%s' "$inner"
    fi
}

# Build a full JSON-RPC request body.
build_request() {
    local method="$1"
    local params="$2"
    printf '{"method":"%s","params":%s,"id":1}' "$method" "$params"
}

call_method() {
    local method="$1"
    local params="$2"
    if [[ -z "$params" ]]; then
        params='{}'
    fi
    local params_full
    params_full="$(build_params "$params")"
    local req
    req="$(build_request "$method" "$params_full")"
    printf '%s' "$req" | rpc "$SOCKET"
}

# Pretty-print when jq is available, otherwise raw.
pretty() {
    if command -v jq >/dev/null 2>&1; then
        jq .
    else
        cat
    fi
}

load_source() {
    local file="${1:-}"
    if [[ -z "$file" ]]; then
        printf '%s' "$BELL_QASM"
    else
        cat "$file"
    fi
}

format_from_ext() {
    case "${1:-}" in
        *.json)      echo json;;
        *.opticqasm) echo opticqasm;;
        *)           echo qasm;;
    esac
}

json_escape() {
    python3 -c 'import json, sys; print(json.dumps(sys.stdin.read()))'
}

case "$CMD" in
    ping)
        call_method ping "{}" | pretty
        ;;
    info)
        src="$(load_source "${1:-}" | json_escape)"
        fmt="$(format_from_ext "${1:-}")"
        call_method info "{\"source\":${src},\"format\":\"${fmt}\"}" | pretty
        ;;
    optimize)
        src="$(load_source "${1:-}" | json_escape)"
        fmt="$(format_from_ext "${1:-}")"
        call_method optimize "{\"source\":${src},\"format\":\"${fmt}\",\"iterations\":3}" | pretty
        ;;
    compile)
        if [[ $# -lt 2 ]]; then
            echo "compile: need <file> <target>" >&2
            exit 2
        fi
        src="$(cat "$1" | json_escape)"
        fmt="$(format_from_ext "$1")"
        tgt="$2"
        call_method compile "{\"source\":${src},\"format\":\"${fmt}\",\"target\":\"${tgt}\"}" | pretty
        ;;
    demo)
        echo "=== quantum-server demo (shell) ==="
        result_ping="$(call_method ping '')"
        echo "  ping  → $result_ping"

        src="$(printf '%s' "$BELL_QASM" | json_escape)"
        params_info='{"source":'"${src}"',"format":"qasm"}'
        result_info="$(call_method info "$params_info")"
        echo "  info  → $result_info"

        redundant='OPENQASM 2.0;
include "qelib1.inc";
qreg q[1];
h q[0];
h q[0];
x q[0];
x q[0];
'
        src_r="$(printf '%s' "$redundant" | json_escape)"
        params_opt='{"source":'"${src_r}"',"format":"qasm","iterations":3}'
        result_opt="$(call_method optimize "$params_opt")"
        echo "  opt   → $result_opt"
        ;;
    *)
        echo "unknown command: $CMD" >&2
        exit 2
        ;;
esac
