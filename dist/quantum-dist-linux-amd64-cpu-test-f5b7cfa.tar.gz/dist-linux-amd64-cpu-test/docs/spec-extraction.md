# Spec extraction — Aria source ↔ Lean stub ↔ closed proof

This walkthrough demonstrates the full **Aria → extracted Lean → closed
Lean** pipeline that the toolkit ships today, on three small algorithms:

| Algorithm                       | Aria source                    | Extracted (sorries)                          | Closed (Float-level)                                  |
|---------------------------------|--------------------------------|----------------------------------------------|-------------------------------------------------------|
| Bell state                      | `examples/aria/bell.aria`      | `proofs/lean4/QuantumProofs/Generated/`*     | `proofs/lean4/Generated_Closed.lean::bell_correct`    |
| Deutsch–Jozsa (constant oracle) | `examples/aria/deutsch_jozsa.aria` | (extract via CLI; see below)            | `proofs/lean4/Generated_Closed.lean::dj_constant_correct` |
| GHZ on 3 qubits                 | (built-in template — see § Pipeline) | (extract via Rust API)                | `proofs/lean4/Generated_Closed.lean::ghz_correct`     |

\* The `Generated/` directory is a write target, not a source file
checked into the repo: every CI run regenerates `Bell.lean` into a
temporary directory (CI stage 7c) to validate the pipeline.

The closed-form proofs live in **`proofs/lean4/Generated_Closed.lean`**
and run end-to-end via `lean --run` with **no mathlib dependency**, so
they slot into the standalone CI stage 9 alongside the existing 23
gate-level theorems.

## Pipeline at a glance

```text
       ┌────────────────────┐    spec extract    ┌─────────────────────┐
       │   Aria source      │ ─────────────────▶ │   Generated Lean    │
       │ (examples/aria/…)  │                    │  (sorry-bodied)     │
       └────────────────────┘                    └─────────────────────┘
                                                            │
                                                            │  hand-finish
                                                            ▼
       ┌────────────────────────────────────────────────────────────┐
       │   Generated_Closed.lean (Float-level, no mathlib)          │
       │   theorem bell_correct / dj_constant_correct / ghz_correct │
       └────────────────────────────────────────────────────────────┘
```

Three entry points feed the extraction step (the second arrow above):

1. **CLI** — handy for one-off extracts:
   ```sh
   quantum spec extract \
       --aria examples/aria/bell.aria \
       --instantiate "Bell" \
       --out proofs/lean4/QuantumProofs/Generated/
   ```
2. **Rust library** — `quantum_core::spec::extract_aria(&src, "Bell")`.
3. **`#[quantum_core::spec]` attribute** — emits a sidecar
   `<fn>_write_lean4` for any `fn() -> Circuit`.

The extracted file conforms to the schema documented in
`proofs/lean4/QuantumProofs/Generated/README.md`.

## Worked example — Bell state

### 1. Aria source (`examples/aria/bell.aria`)

```aria
@assert unitary
@prove "bell_correct" equiv { creates (|00> + |11>)/sqrt(2) }
@bound gate_count = 2

circuit Bell {
    qreg q[2]
    creg c[2]

    apply H on q[0]
    apply CX on q[0], q[1]

    measure q -> c
}
```

### 2. Extracted Lean stub (`Generated/Bell.lean`)

Running

```sh
quantum spec extract --aria examples/aria/bell.aria \
    --instantiate "Bell" --out /tmp/aria-out/
```

writes the following file (elided headers shown):

```lean
namespace Exported.Bell
open QuantumProofs.CircuitSemantics

def circuit : Circuit 2 :=
  [.h ⟨0, by omega⟩,
   .cx ⟨0, by omega⟩ ⟨1, by omega⟩]

theorem assert_unitary_0 : is_unitary (denote circuit) := by sorry

theorem bell_correct : True := by sorry

theorem bell_correct_basis_states (k : Fin (2^2)) :
    apply (denote circuit) (basis_state 2 k) =
    apply (denote reference) (basis_state 2 k) := by sorry

end Exported.Bell
```

The `is_unitary` and `apply` predicates referenced here are defined in
`QuantumProofs.Basic`. They were added as part of TODO item 6(a) so
extracted files compile without redefining them per-theorem.

### 3. Closed-form proof (`proofs/lean4/Generated_Closed.lean`)

Rather than wrestling mathlib's deep Kronecker bookkeeping, the
closed-form proof works at the **Float level** using the same
`Mat2/Mat4/Mat8` infrastructure as `proofs/lean4/Standalone.lean`:

```lean
def Bell : Mat4 := CNOT4 * H_tensor_I

def bell_state_amplitudes : Bool :=
  let col0 : Array C := Array.ofFn (n := 4) fun i => Bell.get i.val 0
  -- expected:  [1/√2, 0, 0, 1/√2]
  (col0.getD 0 C.zero ≈ C.invSqrt2) &&
    (col0.getD 1 C.zero ≈ C.zero) &&
    (col0.getD 2 C.zero ≈ C.zero) &&
    (col0.getD 3 C.zero ≈ C.invSqrt2)

theorem bell_correct : bell_state_amplitudes = true := by native_decide
```

`native_decide` reduces the entire claim to a Float computation: the
Bell circuit's first column equals `(1/√2, 0, 0, 1/√2)` to within 1e-9.
This is the same evidentiary standard as the existing standalone
proofs in `Standalone.lean`.

## Running the proofs

```sh
# 1. The standalone gate identities (23 theorems).
cd proofs/lean4 && lean --run Standalone.lean

# 2. The new circuit-level closed proofs (Bell + DJ + GHZ).
cd proofs/lean4 && lean --run Generated_Closed.lean
```

CI stage 9b (added with item 6(e)) runs the second command on every
push. The mathlib-backed `Generated/` artefacts remain opt-in via
`QUANTUM_MATHLIB=1` and are intentionally not gated.

## Why two layers?

The mathlib-backed `is_unitary` / `apply` definitions in
`QuantumProofs.Basic` are designed for *symbolic* manipulation:
inductive proofs over `Circuit n`, conjugation with `Matrix.kronecker`,
etc. The closed-form Float layer is for *computational* validation: it
proves the same end-to-end claim by literally running the circuit on
basis vectors and checking the amplitudes.

Both layers consume the *same Aria source*. That's the value the
spec-extraction pipeline delivers: write an algorithm once in Aria,
get both proof avenues for free.

## MBQC pattern correspondence (C4)

The same Float layer also certifies the **MBQC compiler**: that
`circuit_to_pattern` (the gate-model → measurement-pattern lowering in
`crates/quantum-core/src/mbqc/compile.rs`) preserves the circuit's unitary.

A circuit gate lowers to MBQC primitives — single-qubit teleport gadgets and
CZ graph edges. The key two-qubit case is the **H-sandwich**:

```
CX(control, target)  =  (H on target) · CZ(control, target) · (H on target)
```

`Generated_Closed.lean` rebuilds whole algorithms from exactly these primitives
and `native_decide`s that they reproduce the gate-model circuit:

| Theorem | Claim |
|---------|-------|
| `mbqc_cx_correct` | `(I⊗H)·CZ·(I⊗H) = CNOT` (the CX gadget) |
| `bell_mbqc_correct` | Bell rebuilt from MBQC primitives on `\|00⟩` = `(\|00⟩+\|11⟩)/√2` |
| `mbqc_ghz_gadgets_correct` | both 3-qubit CX gadgets `= CX(0,1)`, `CX(1,2)` |
| `ghz_mbqc_correct` | GHZ rebuilt from MBQC primitives on `\|000⟩` = `(\|000⟩+\|111⟩)/√2` |

This is the circuit↔pattern cross-correspondence (`MBQC_PLAN.md` C4.3), closed
sorry-free at the Float layer for `bell.aria` and GHZ — the executable-proof
counterpart of the in-tree `quantum-qml/tests/mbqc_verify.rs` channel checks.

**General `denote_pattern` (C4.2).** Beyond the hand-built gadget proofs above,
`Generated_Closed.lean` defines one computable `denote_pattern : PatternD →
Array C` that denotes *any* pattern — `|+⟩^n` prep, CZ along every edge, the
`⟨+_φ|` +branch measurement contraction — to its output state `U|+⟩^n` (the
Float mirror of the Rust `simulate_pattern_deterministic`). The obligation
`denote_pattern ≈ denote_circuit` (circuit on the `|+⟩` input) is then
`native_decide`d for the actual `circuit_to_pattern` output of Bell
(`bell_pattern_correct`) and GHZ (`ghz_pattern_correct`).

**Auto-emission (C4.1) — `--mbqc`.** The obligation above no longer has to be
hand-written. `quantum spec extract --mbqc` writes, alongside each
`<Name>.lean`, a **self-contained** `<Name>_Pattern.lean`:

```bash
quantum spec extract --aria examples/aria/bell.aria \
    --instantiate "Bell" --mbqc --out /tmp/
# → /tmp/Bell.lean          (gate-model theorem skeleton)
# → /tmp/Bell_Pattern.lean  (MBQC pattern + native_decide certificate)
lean --run /tmp/Bell_Pattern.lean        # ⇒ "All Bell pattern proofs verified"
```

The emitted file inlines the Float infra (`C` / `PatternD` / `denote_pattern`,
byte-identical to `Generated_Closed.lean`), the `circuit_to_pattern` output as
a `PatternD` literal, the expected `U|+⟩^n` from the Rust
`simulate_pattern_deterministic`, and
`theorem <name>_pattern_correct : … := by native_decide`. No `import`, no
mathlib — so compiling the file *is* the proof. Circuits using gates the MBQC
compiler does not support are skipped with a warning rather than failing the
extraction. (`spec::render_pattern_file` is the emitter; `examples/mbqc_spec_export`
and CI stage 7c exercise it on Bell.)

**Mathlib-layer obligation (C5 step 5) — `--mbqc-mathlib`.** A second flavour
emits the `Matrix`-valued obligation into `MBQC/<Name>_Pattern.lean`:

```bash
quantum spec extract --aria examples/aria/bell.aria \
    --instantiate "Bell" --mbqc-mathlib \
    --out proofs/lean4/QuantumProofs/Generated/
# → …/Generated/MBQC/Bell_Pattern.lean
lake build QuantumProofs.Generated.MBQC.Bell_Pattern   # type-checks (sorry body)
```

This file `import`s `QuantumProofs.MBQC`, opens `namespace Exported.MBQC.<Name>`,
and emits the gate-model `circuit`, the compiled `Pattern` literal, and the
named obligation

```lean
theorem <name>_compiler_correct :
    ∃ c : ℂ, c ≠ 0 ∧ ∀ k, denote_pattern_plus pattern k = c * denoteOnPlus circuit k := by
  sorry
```

The claim is stated **up to a single global nonzero scalar** `c` — the `+`-branch
readout carries the accumulated `⟨+_φ|` normalisation `(1/√2)^{#meas}` and global
phase `∏ e^{-iφ/2}` (see the gadget/chain lemmas in `QuantumProofs.MBQC`), so an
exact `c = 1` equality would be false.

**For a recognised primitive single-gate circuit (`H`, `X`, `Z`, `S`, `T`, generic-angle `RZ`, and the two-qubit entangler `CZ`) the
emitted obligation is CLOSED sorry-free** — `:= by exact
QuantumProofs.MBQC.{h,x,z,s,t}_compiler_correct` — so `quantum spec extract
--mbqc-mathlib` generates a genuine *machine-checked* correctness proof
(`#print axioms` = the three standard axioms, no `sorryAx`). Measurement angles
are emitted as exact ℝ literals (`Real.pi` multiples, not Float approximations)
so the obligation is faithful and matches the lemma statement. The committed
`Generated/MBQC/{GH,GX,GZ,GS,GT,GRZ,GCZ}_Pattern.lean` are these closed proofs (CI stage
11b). For any other circuit the body is `exact sorry`: closing it is the deep
step-4 measurement-calculus correspondence (shared with `gflow_determinism`).
Mirroring `../fpga-meta-compiler`'s `src/lean4.rs` shape, the emitted file
type-checks — `lake build` of the module is CI stage 11b; the committed
`Generated/MBQC/Bell_Pattern.lean` is kept in sync with the emitter by a
`quantum-core` unit test. Because the module is *not* imported by the
`QuantumProofs` root, its `sorry` is a self-contained generated obligation and
does not enter the main library's proof budget.

The obligation is **discharged sorry-free for every single-qubit-gate circuit**
in `QuantumProofs.MBQC` — `{h,x,z,s,t,rz,cz}_compiler_correct` (with the matching
`denoteOnPlus_*` column evaluations): `H` (scalar `1/√2`, via `gadget_zero_is_H`),
`RZ θ`/`Z`/`S`/`T` (via `chain_realises_RZ`), and `X` (via
`denote_pattern_plus_chain2`) — plus the two-qubit entangler `cz_compiler_correct`
(`circuit_to_pattern [CZ]` is a bare graph-state edge, so its readout *is*
`CZ·|++⟩`, `c = 1`). These are concrete instances proved rather than stubbed.
(`Y`/`RY` → 4-gadget chains and `CX` → 16-dim pattern remain, pending bigger
readout lemmas.)

Remaining: closing `<name>_compiler_correct` for an *arbitrary* circuit (e.g.
the emitted `Bell_compiler_correct`, whose 32-dim graph state is intractable by
brute force) — the abstract correspondence induction / a Lean port of
`circuit_to_pattern`, the deep `gflow_determinism`-class residue.

## Adding a new algorithm

1. Author the Aria source under `examples/aria/<name>.aria` with
   `@assert` / `@prove` annotations describing the intended claim.
2. Run `quantum spec extract --aria … --out /tmp/`. Inspect the
   generated `<Name>.lean` to see the obligation skeleton.
3. Mirror the algorithm in `Generated_Closed.lean` using `Mat2/4/8`
   composition; close the headline `theorem` with `by native_decide`.
4. Add a one-line check in the `main` function of
   `Generated_Closed.lean` so the smoke output reports the new
   algorithm.
5. (Optional) Once mathlib is warm, also close the symbolic
   `Generated/<Name>.lean` obligations and add the file to the
   mathlib-backed lakefile target.
