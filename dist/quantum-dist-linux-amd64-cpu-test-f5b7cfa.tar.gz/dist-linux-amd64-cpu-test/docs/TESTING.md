# Testing & Development Guide

> **Audience.** This guide is written for AI coding agents and human
> engineers who need to bring a fresh machine to a green `./scripts/ci.sh`.
> Every step is a copy-pasteable shell block followed by a one-line
> verification. If a verification command returns non-zero, do **not**
> proceed — jump to [Troubleshooting](#troubleshooting).

> **Working rules (see `CLAUDE.md`).** This is the **manual testing
> manual**, and these rules are binding:
> - **No GUI. Numbers only.** Every step ends in a **numeric** check —
>   counts, expectations, probabilities, eigenvalues, parity deltas —
>   compared to a golden value within a stated tolerance. A step with no
>   numeric assertion does not belong here.
> - **CI is local** (`./scripts/ci.sh`) — **no GitHub / no CI service.**
> - **Commit often, never push.**
> - **The manual MUST be run against the binary-only dist artefact**
>   (§10.2) — not just `cargo run`. The point is to prove the *shipped
>   stripped binaries* produce the right numbers.
> - **After each build phase, run this manual end-to-end in a subagent**
>   and iterate until green. A failure means the *code* is wrong **or
>   this *doc* is wrong** — fix whichever is actually wrong and keep the
>   manual truthful.

## Contents

1. [Dependency matrix — which deps for which task](#1-dependency-matrix)
2. [One-shot bootstrap (the fast path)](#2-one-shot-bootstrap)
3. [Detailed install per OS](#3-detailed-install-per-os)
   - [macOS (Apple Silicon + Intel)](#31-macos-apple-silicon--intel)
   - [Ubuntu / Debian](#32-ubuntu--debian)
   - [Fedora / RHEL / Rocky](#33-fedora--rhel--rocky)
   - [Arch / Manjaro](#34-arch--manjaro)
4. [Verify install (one-line checks)](#4-verify-install)
5. [Test suites](#5-test-suites)
6. [CI pipeline (`./scripts/ci.sh`)](#6-ci-pipeline-scriptscish)
7. [Examples, benchmarks, WASM guests](#7-examples-benchmarks-wasm-guests)
8. [Formal proofs (Lean4 + Rocq)](#8-formal-proofs)
9. [Python wheel (PyO3 / maturin)](#9-python-wheel-pyo3--maturin)
10. [Release packaging](#10-release-packaging)
11. [Troubleshooting](#troubleshooting)

---

## 0. Guided demos (fast, self-verifying)

The quickest numeric end-to-end check is the two guided demo scripts — each step
prints a headline number and asserts it against a golden value (no GUI), then
exits non-zero on any mismatch. See [`docs/DEMO.md`](docs/DEMO.md) for the
narrated walkthrough.

```bash
source scripts/env.sh          # libtorch on path
./scripts/demo.sh              # breadth tour — expect "demo complete — 7/7 steps verified"
./scripts/demo-finance.sh      # real-XAUUSD trading story — expect "5/5 steps verified"
```

| Script | Pass line |
|---|---|
| `scripts/demo.sh` | `=== demo complete — 7/7 steps verified numerically ===` |
| `scripts/demo-finance.sh` | `=== finance demo complete — 5/5 steps verified numerically ===` |

These are a superset-narrative over the per-suite checks in §5 and the dist smoke
in §10; they are the recommended first thing to run on a fresh machine after §4.

---

## 1. Dependency matrix

| Task | Rust | libtorch | Python venv | Lean+mathlib | Rocq | WASM target | Node |
|------|:----:|:--------:|:-----------:|:------------:|:----:|:-----------:|:----:|
| `cargo test -p quantum-core` | ✅ | — | — | — | — | — | — |
| `cargo test -p quantum-macros` | ✅ | — | — | — | — | — | — |
| `cargo test -p quantum-qml` | ✅ | ✅ | — | — | — | — | — |
| `cargo build -p quantum-py` (link) | ✅ | ✅ | — | — | — | — | — |
| `maturin develop / build` (wheel) | ✅ | ✅ | ✅ | — | — | — | — |
| Lean4 standalone (stage 9, 23 thms) | — | — | — | Lean only | — | — | — |
| Lean4 mathlib (stage 11, opt-in) | — | — | — | ✅ + cache | — | — | — |
| Rocq stage 10 | — | — | — | — | ✅ | — | — |
| WASM guests (vqe / qaoa / ecc) | ✅ | — | — | — | — | ✅ | — |
| Editor-plugin smoke (stage 7d JS) | — | — | python3 | — | — | — | ✅ |
| Full `./scripts/ci.sh` | ✅ | ✅ | ✅ | ✅ + cache | ✅ | ✅ | ✅ |

**Minimum versions (verified in CI):**

| Tool | Pinned/expected version |
|------|-------------------------|
| Rust | 1.75+ (stable) — local dev uses 1.95 |
| libtorch | **2.7.0** (`scripts/setup-libtorch.sh` downloads this exact version; matches tch 0.20. CUDA variant is cu128 for sm_120/Blackwell) |
| Python | ≥ 3.8 for the wheel; ≥ 3.10 for full dev loop |
| Lean | `leanprover/lean4:v4.29.0` (pinned in `proofs/lean4/lean-toolchain`) |
| Rocq | 9.1.x (the `QLibCompat.v` shim does not need `coq-quantumlib`) |
| Node | any LTS — only used to `node --check` the tree-sitter `grammar.js` |
| WASM target | `wasm32-wasip1` (added via `rustup target add`) |

---

## 2. One-shot bootstrap

If `rustup`, a system Python ≥ 3.10, `curl`, `unzip`, and `git` are
already present, this brings a fresh checkout to green:

```bash
# 0. Clone (skip if you already have the repo)
git clone <repo-url> quantum && cd quantum

# 1. Rust toolchain + WASM target
rustup update stable
rustup target add wasm32-wasip1

# 2. libtorch 2.7.0 (cpu) — drops it at ./libtorch/
./scripts/setup-libtorch.sh                 # macOS / Linux CPU
# Linux + CUDA 12.8 (Blackwell): ./scripts/setup-libtorch.sh cu128

# 3. Source env (LIBTORCH + {DY,}LD_LIBRARY_PATH)
source scripts/env.sh

# 4. Lean toolchain (elan installs Lean per lean-toolchain pin)
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh -s -- -y --default-toolchain none
source "$HOME/.elan/env"

# 5. Mathlib precompiled oleans (~500 MB download, NO local rebuild)
#    Idempotent: re-runs are no-ops once the cache marker exists.
./scripts/setup-mathlib.sh

# 6. (Optional) Rocq for stage 10 — see per-OS section if not installed
#    macOS: brew install rocq-prover         (or opam install rocq-prover)
#    Linux: see §3.2 / §3.3 / §3.4

# 7. (Optional) Node for stage 7d editor-plugin smoke
#    macOS: brew install node          Linux: see per-OS section

# 8. Run the whole pipeline
./scripts/ci.sh
# Add QUANTUM_MATHLIB=1 ./scripts/ci.sh to also build mathlib-backed proofs
```

Expected last line: `=== CI completed in <N>s ===`.

---

## 3. Detailed install per OS

### 3.1 macOS (Apple Silicon + Intel)

> Tested on macOS 14+ (`Darwin 25.x`). Apple Silicon uses CPU libtorch
> (Metal goes through `tch::Device::Mps` — no separate libtorch download).

**Required: Xcode Command Line Tools** (compiler + `git` + `curl` + `unzip`):

```bash
xcode-select --install            # one-time; opens GUI if missing
# Verify:
xcode-select -p && cc --version | head -1
```

**Homebrew** (recommended — used by several optional deps):

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
# Verify:
brew --version
```

**Rust:**

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source "$HOME/.cargo/env"
rustup update stable
rustup target add wasm32-wasip1
# Verify:
rustc --version && cargo --version
rustup target list --installed | grep wasm32-wasip1
```

**libtorch 2.7.0** (auto-detects arm64 vs x86_64):

```bash
cd /path/to/quantum
./scripts/setup-libtorch.sh
source scripts/env.sh
# Verify:
ls "$LIBTORCH/lib/libtorch_cpu."*   # should list .dylib
echo "$DYLD_LIBRARY_PATH" | grep -q libtorch && echo "DYLD ok"
```

**Python venv** (per project convention — never system Python):

```bash
python3 -m venv .venv
source .venv/bin/activate
unset CONDA_PREFIX                  # if conda is active, maturin refuses
pip install --upgrade pip maturin
# Verify:
python3 --version && maturin --version
```

**Lean + elan + mathlib precompiled oleans:**

```bash
# elan installs Lean per project's lean-toolchain pin (4.29.0)
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh \
    | sh -s -- -y --default-toolchain none
source "$HOME/.elan/env"
# Trigger toolchain download by entering the proof dir (elan reads lean-toolchain):
(cd proofs/lean4 && lean --version)
# Precompiled mathlib oleans — NO local rebuild (~30 min saved).
# The script calls `lake exe cache get` which pulls .oleans from
# mathlib's Azure blob cache.
./scripts/setup-mathlib.sh
# Verify:
ls proofs/lean4/.lake/build/lib/Mathlib.olean
```

**Rocq 9.1.x** (only needed for stage 10):

```bash
brew install rocq-prover            # ships coqc + dune
# Verify:
coqc --version | head -1            # → "The Rocq Prover, version 9.1.x"
```

**Node** (only needed for stage 7d editor-plugin smoke):

```bash
brew install node
# Verify:
node --version                      # any LTS works
```

---

### 3.2 Ubuntu / Debian

> Tested on Ubuntu 22.04 LTS + Debian 12.

**System tooling:**

```bash
sudo apt update
sudo apt install -y build-essential pkg-config libssl-dev curl unzip git \
                    python3 python3-venv python3-pip
# Verify:
cc --version | head -1 && curl --version | head -1
```

**Rust:**

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source "$HOME/.cargo/env"
rustup update stable
rustup target add wasm32-wasip1
# Verify:
rustc --version && rustup target list --installed | grep wasm32-wasip1
```

**libtorch 2.7.0:**

```bash
cd /path/to/quantum
./scripts/setup-libtorch.sh           # CPU
# CUDA 12.8 build (Blackwell sm_120): ./scripts/setup-libtorch.sh cu128
#   (needs an NVIDIA driver ≥550 and CUDA 12.8 runtime; the libtorch zip
#    ships its own CUDA libs, but the driver must match. cu124 is retired —
#    it lacks sm_120 kernels and aborts ATen ops on Blackwell GPUs.)
source scripts/env.sh
# Verify:
ls "$LIBTORCH/lib/libtorch_cpu."*     # .so on Linux
echo "$LD_LIBRARY_PATH" | grep -q libtorch && echo "LD ok"
```

**Python venv:**

```bash
python3 -m venv .venv
source .venv/bin/activate
unset CONDA_PREFIX
pip install --upgrade pip maturin
# Verify:
python3 --version && maturin --version
```

**Lean + elan + mathlib oleans:**

```bash
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh \
    | sh -s -- -y --default-toolchain none
source "$HOME/.elan/env"
(cd proofs/lean4 && lean --version)
./scripts/setup-mathlib.sh            # downloads precompiled oleans
# Verify:
ls proofs/lean4/.lake/build/lib/Mathlib.olean
```

**Rocq 9.1.x** — Ubuntu's `coq` is older than 9.1; use opam:

```bash
sudo apt install -y opam
opam init --bare --disable-sandboxing -y
opam switch create rocq-9.1 --packages=ocaml-base-compiler.5.1.1
eval "$(opam env)"
opam install -y rocq-prover.9.1.1
# Verify:
coqc --version | head -1
```

**Node** (for stage 7d):

```bash
# NodeSource LTS — replace 20.x with current LTS if needed
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt install -y nodejs
# Verify:
node --version
```

---

### 3.3 Fedora / RHEL / Rocky

```bash
sudo dnf install -y gcc gcc-c++ pkgconf openssl-devel curl unzip git \
                    python3 python3-virtualenv python3-pip
# Rust — same rustup one-liner as §3.2
# libtorch — same ./scripts/setup-libtorch.sh as §3.2 (it auto-detects Linux)
# Python venv — same as §3.2
# Lean — same elan one-liner as §3.2
# Rocq — opam path (same as §3.2; replace `apt install opam` with `dnf install opam`)
# Node — sudo dnf install -y nodejs   (or NodeSource RPM repo for LTS)
```

---

### 3.4 Arch / Manjaro

```bash
sudo pacman -Syu --needed base-devel pkgconf openssl curl unzip git \
                          python python-virtualenv python-pip nodejs
# Rust:        pacman -S rustup && rustup default stable
# libtorch:    ./scripts/setup-libtorch.sh
# Python venv: python -m venv .venv && source .venv/bin/activate
# Lean:        elan one-liner from §3.2
# Rocq:        sudo pacman -S rocq-prover  (or opam if outdated)
```

---

## 4. Verify install

Run these **after** completing §3 for your OS. Every command should
print a version or path; non-zero exit means something is missing.

```bash
# Rust toolchain
rustc --version                       # → rustc 1.x
cargo --version
rustup target list --installed | grep -q wasm32-wasip1 && echo "wasm32-wasip1 ok"

# libtorch + env
source scripts/env.sh                 # idempotent — exports LIBTORCH
test -f "$LIBTORCH/lib/libtorch_cpu.dylib" || \
test -f "$LIBTORCH/lib/libtorch_cpu.so" && echo "libtorch ok"

# Python + maturin
python3 --version
maturin --version

# Lean
lean --version                        # any 4.x; toolchain auto-switches in proofs/lean4
lake --version
test -f proofs/lean4/.lake/build/lib/Mathlib.olean && echo "mathlib oleans ok"

# Rocq
coqc --version | head -1              # Rocq Prover 9.1.x

# Node (for editor-plugin JSON/JS smoke)
node --version

# Final sanity: compile the workspace without running tests
cargo check --workspace
```

Expected: `cargo check --workspace` finishes with `Finished dev profile`.

---

## 5. Test suites

### 5.1 quantum-core (no external deps)

```bash
cargo test -p quantum-core
```

| Module | Tests | What's covered |
|--------|-------|----------------|
| `ast::nodes` | 8 | Circuit construction, gate properties, composition, pipe, tensor, repeat, inverse, operators |
| `ast::builder` | 3 | Fluent builder API, bell/ghz/qft |
| `ast::qasm` | 2 | QASM 2.0 roundtrip, parametric gates |
| `ast::expr` | 6 | ParamExpr concrete/symbol/pi/arithmetic/fn_call/display |
| `ast::annotation` | 3 | Annotation display, resource bounds, probability |
| `ast::json` | 2 | JSON roundtrip, annotations serialization |
| `ast::opticqasm` | 2 | OPTICQASM roundtrip, Clements mesh parsing |
| `ast::export_lean` | 2 | Bell+unitary to Lean4, QFT+prove to Lean4 |
| `ast::export_rocq` | 2 | Bell+unitary to Rocq, Grover+prove to Rocq |
| `circuits::standard` | 3 | bell(), ghz(), qft_circuit() |
| `circuits::trotter` | 3 | H₂ Trotter, second order, Ising Hamiltonian |
| `circuits::photonic` | 3 | Clements mesh 4/6, Mach-Zehnder |
| `circuits::modules` | 3 | Registry, instantiate, custom module |
| `circuits::encoding` | 4 | Angle encoding, IQP, hardware-efficient ansatz, QML circuit |
| `circuits::lcu` | 3 | LCU 2-term, 4-term, 1-norm |
| `circuits::qsvt` | 4 | QSVT circuit, sign angles, inversion angles, resources |
| `optimizers::passes` | 5 | Identity removal, gate cancellation, rotation merging |
| `optimizers::pipeline` | 1 | Default pipeline convergence |
| `optimizers::commutation` | 2 | Disjoint qubit, Z-diagonal commutation |
| `optimizers::decomposition` | 4 | SWAP→3CX, CZ→H-CX-H, CCX→15 gates |
| `optimizers::tcount` | 5 | T-merge (T²=S), commuting Cliffords, H-blocked, t_count |
| `optimizers::tableau` | 6 | BitVec, XOR, Pauli commutation, tableau H, bb_merge |
| `optimizers::clifford_t` | 3 | .qc roundtrip, CliffordT optimizer, Toffoli export |
| `optimizers::fast_t_merge` | 3 | FastTMerge adjacent, through Z, different qubits |
| `optimizers::h_opt` | 3 | H-Z-H→X, H-X-H→Z, no-pattern |
| `optimizers::phase_poly` | 4 | PhasePoly proper, PhasePolyDedup drop/keep, kernel-search |
| `optimizers::tket` | 1 | Tket2 fallback to default pipeline |
| `backends::omega` | 2+ | Circuit→OmegaCircuitIR, parametric gates, conditional-gate bridge |
| `backends::ffi` | 2 | Circuit→FfiGateOp, repr(C) layout |
| `ecc::codes` (surface) | 1 | Surface code [[9,1,3]] properties + syndrome |
| `ecc::codes` (other) | 2 | Repetition code, Steane code |
| `ecc::mwpm` | 7 | Decoder: clean, boundary, direct pairing, d=5 fallback, Correction variants |
| `hdl::fpga_meta` | 3 | pseudo-IR parse, Lean4 spec extract, fpga-meta-compiler import |
| Macro tests (`circuit!`) | 4 | Bell, GHZ, parametric, Toffoli via proc-macro |
| Symbolic tests | 5 | Symbolic build, bind_params, unbound error, QASM, JSON roundtrip |
| `timebomb` | 1 | Build-time expiry (Active / Disabled path) |
| `server_smoke` | 5 | omega-server `/v1/quantum/execute` JSON IR dispatch smoke |
| `aria_examples` | 4 | **every `examples/aria/*.aria` (31) parses + instantiates** + a coverage guard (no file skips the gate) — incl. MBQC ghz/grover3/qft4/rotations/u3/clifford_opt (item 11 A1/A2/A4); + **`teleport.aria` → `circuit_to_pattern`** compiles end-to-end to 1 terminal output byproduct (X←m1, Z←m0 on Bob); + **`mbqc_feedforward.aria`** → 1 *internal* `x_corr_from` flow edge, fires-iff-source-1 ≤1e-12 over 48 seeds (A1.5 both conditional paths) |
| Integration tests | 6 | Build→optimize→export, decompose+optimize, QFT-iQFT, ECC, QASM, pipeline |

Total (verified 2026-06-04): **307** (lib + 6 integration + 7 macro + 5
symbolic + 5 server_smoke + 4 aria_examples + 1 doctest; MBQC A0 gflow +
A1/A2 + A3 resource estimator incl. A3.3 `compare_resource` + **B1 UBQC
typed state machine** + **B2 real UBQC server register** (`process_message`,
`plus_prob = cos²((θ−δ)/2)` ≤1e-12, BFK blind-but-correct single-qubit
recovery) + **B3 `Pattern::brickwork`** (linear-cluster + 2×9 structure +
gflow determinism + unit-norm simulate) + **gflow byproduct correction**
(`simulate_pattern_sampled` + `apply_gflow_correction`: random run +
correction == canonical +branch ≤1e-9 over 16 seeds × {line,Bell,GHZ})
+ **A2 `Pattern::optimize`** — Clifford pattern simplification, all
channel-preserving ≤1e-9: `canonicalize_edges` (`CZ²=I` 2 edges → 0) +
**A2.3 `eliminate_y_vertices`** (Pauli-Y local complementation; S-gadget drops
a vertex) + **A2.3 `eliminate_x_pivots`** (Pauli-X pivot; `H·H` wire collapses,
2 vertices/pivot) + `parallelize` (gflow depth: 2 rounds → 1)
+ **A2.1 `reduce_corrections`** (byproduct parity-reduction `X²=Z²=I`:
`x_corr_from=[0,0,0]→[0]`, `z_corr_from=[0,0]→[]`; channel-preserving —
identical sampled trajectory + branch probability ≤1e-12 over 32 seeds, and
**channel-identical at the `output_density_matrix` ρ level**)
+ **A2.1 `shift_signals`** (Danos–Kashefi `[S]`: forward-propagates a measurement
Z-dependency `s_i↦s_i⊕s_j` off the angle, then ρ is invariant ≤1e-12 via the
`output_density_matrix` oracle — exact channel over all branches; oracle itself
validated against the known graph state ½(|00⟩+|01⟩+|10⟩−|11⟩), trace=1, Hermitian)
+ **A1.5 conditional Pauli** (`circuit_to_pattern` lowers `when (c,1){X|Z q}`
to a byproduct link sourced from the bound `Measure q'->c` outcome; the
correction fires iff that outcome is 1 — matches off/hard-applied baselines
≤1e-12 over 48 seeds; non-Pauli / value≠1 rejected) + **A1.5 output byproduct**
(terminal-output target → `Pattern::output_corr`; `apply_output_correction`
applies X/Z iff source outcome 1, ≤1e-12 over 48 seeds, X and Z).
Acceptance: a 3-qubit Clifford circuit optimizes with **≥30% vertex reduction**
+ gflow preserved + **B4 `verify_traps`** (FK '17 verifiable UBQC: honest server
passes 8 traps deterministically, wrong-basis/flipped outcome detected),
finance_lab Phase 0, data-reuploading, all 24 .aria files parse-validated).
(The per-module rows above are indicative;
the runner totals are authoritative — re-run `cargo test -p quantum-core`.)

### 5.2 quantum-qml (requires libtorch)

```bash
source scripts/env.sh
cargo test -p quantum-qml -- --test-threads=1   # see note
```

> **Run qml tests single-threaded.** tch/libtorch uses one **global** RNG;
> running the RNG-seeded tests in parallel lets sibling tests race the
> generator, making seeded tests non-deterministic. `ci.sh` stage 4 already
> passes `--test-threads=1`. (Also: `ci.sh` re-exports `DYLD_LIBRARY_PATH`
> internally because macOS SIP strips it across the script's exec — so
> `./scripts/ci.sh` works even when your shell had it set.)

| Module | Tests | What's covered |
|--------|-------|----------------|
| `simulator` | 11 | H, Bell, X, parametric RX, expectation Z, mid-circuit measure/reset, **+ Phase-0 `SimConfig` default-is-Cpu + simulate_with_config parity** |
| `layers` | 5 | Forward pass, autograd gradient, train step, Phase-5 adjoint==parameter-shift ≤1e-6, **+ Phase-0.7 Readout (Probs sums to 1, ExpvalZZ in [-1,1])** |
| `cmaes` | 2 | Sphere convergence, Rosenbrock |
| `gradients` | 5 | Parameter-shift vs analytic, omega bridge (×2), **+ Phase-6 batched-vs-sequential parameter-shift ≤1e-10 (single + 8-param ansatz)** |
| `adjoint` | 2 | **GPU_PLAN Phase 5** — adjoint AD == analytic & == parameter-shift ≤1e-8 (3q/8-param ansatz, all observables) |
| `noise` | 4 | Bit-flip p0/p1, none, phase-flip Z |
| `surrogate` | 3 | SurrogateModel creation, SurrogateTrainer sampling |
| `tensor_sim` | 11 | **GPU_PLAN Phase 1** — tch device-aware statevector: H, Bell/GHZ/mixed cross-check vs ndarray ≤1e-10, X, RX(π), ⟨Z⟩, measure 0/1, reset, measure-reset-continue |
| `tests/pennylane_compat` | 5 | **finance_lab Phase 0** parity — amplitude_embedding ≤1e-12 (up to global phase), rot_zyz analytic, angle axis, probs marginals |
| `tests/papers` | 12 | **item 12** gate-model track COMPLETE (all 8 gate-model-origin papers) — qSSL (⟨Z⟩=cos(x)+trainable), QCNN classifier, HQNN hybrid sandwich, nn_embedding (class separation), QRKD (relational distillation), adversarial (FGSM optimal first-order attack), **QLSTM** (4 VQC LSTM gates learn a sine sequence), **QRNN** (recurrent VQC block learns a damped sequence), **HQPINN** (hybrid physics-informed ODE solver, rel-L2 vs analytic ≤0.42), **AA_study** (amplitude-encoding trace-distance collapse ≤0.01), **qLLM** (quantum adapter learns an XOR-structured classification, acc ≥0.85) |
| `tests/mbqc_verify` | 13 | **item 11 A1/A2/A4** — **frontier** deterministic MBQC simulator (bounded `2^width`, not `2^vertices` — fixes the Toffoli/QFT OOM): H/CX/CZ + X/Z/RZ/RX/RY/Y + mixed QML + **A1 wider gates S/Sdg/T/Tdg/SX/U3/CY/SWAP/RXX/RYY/RZZ/CP/CCX/CSWAP** + **A4 Aria round-trip (ghz/grover3/qft4-80-vertex + rotations/u3/clifford_opt)** all compile to the exact unitary (≤1e-9, up to global phase); **A2** `mbqc_clifford_opt.aria` pattern shrinks ≥30% under `optimize()`, channel-preserving. |

Total (verified 2026-05-31): **78 tests** + 1 ignored (default; lib +
integration; includes the 13 `mbqc_verify` frontier-simulator checks incl.
the A4 Aria round-trip + the A2 clifford-opt ≥30% reduction).
With `--features metal`
on a Darwin/MPS host: **66** (+3 `tensor_sim` MPS cross-checks at n≤4 and
+1 `adjoint` MPS check, tolerance ~1e-4/1e-5; self-skip if MPS
unavailable). Run the metal suite via
`cargo test -p quantum-qml --features metal -- --test-threads=1` (CI stage
4b does this on Darwin).

> **Metal (MPS) caveat.** Complex tensors on MPS were validated only at
> **n ≤ 4** (n≥6 aborted with a Metal buffer assertion on libtorch 2.4.0;
> not re-verified on 2.7.0). MPS is correctness-validated at small n; a
> scaled MPS path needs the interleaved-real float32 rework (deferred).
> See `docs/gpu-design.md` §4b.

#### 5.2c NVIDIA CUDA path (`--features cuda`, Linux/CUDA box)

CUDA runs **ComplexDouble** (unlike MPS), so the cross-checks hold to the
full **≤1e-12** tolerance. Requires a CUDA libtorch (**2.7.0/cu128** —
cu124/2.4.0 has no sm_120 Blackwell kernels and aborts ATen ops with "no
kernel image") and an NVIDIA GPU.

```bash
./scripts/setup-libtorch.sh cu128        # one-time; pins libtorch 2.7.0 cu128
source scripts/env.sh
cargo test -p quantum-qml --features cuda -- --test-threads=1   # CI stage 4c
# L0 hardware smoke (elementwise + matmul on the GPU, ≤1e-12):
cargo test -p quantum-qml --features cuda --test cuda_l0_smoke -- --ignored --nocapture
```

**Numeric checks (all self-skip if `cuda_available()` is false):**
- `t_cuda_bell_crosscheck`, `t_cuda_ghz_crosscheck`, `t_cuda_mixed_crosscheck`:
  statevector amplitudes vs the ndarray CPU reference **≤ 1e-12**.
- `t_cuda_expectation_and_measure`: ⟨Z⟩ on |0⟩ = +1, on X|0⟩ = −1 (≤1e-12);
  deterministic measure of |1⟩ = 1.
- `adjoint_on_cuda_matches_parameter_shift`: adjoint AD vs parameter-shift on
  a depth-2 ansatz, all 3 observable qubits, **≤ 1e-8**.
- `cuda_l0_smoke`: on-device f64 `zeros`+add sum = 1024; complex128 = 512;
  matmul max|gpu−cpu| ≤ 1e-12. (Proves Blackwell sm_120 kernels run.)

> **CUDA linking note.** The linker's `--as-needed` drops the unreferenced
> `libtorch_cuda.so`, leaving `Cuda::is_available()` false. `quantum-qml`'s
> `build.rs` (active only under `--features cuda`) forces it `DT_NEEDED`. If
> the cuda tests all *skip* on an NVIDIA box, check `readelf -d <testbin> |
> grep cuda` shows `libtorch_cuda.so`.

> **CUDA bench** (`cargo bench -p quantum-qml --features cuda --bench
> tensor_statevector_cuda`): forward-eval CPU vs CUDA, complex128. Measured
> on RTX PRO 6000 Blackwell: n=22 **6.4×**, n=24 **7.1×** (rising with n).
> Does **not** reach the ≥10× target on this fast CPU + reshape+matmul gate
> path — per-gate permute-copies dominate; the **fused in-place kernels**
> (`--features cuda-fused`, §5.2c′) are the route to ≥10×. Baseline:
> `docs/bench-baselines/statevector-linux-cuda.json`.

#### 5.2c′ Fused in-place CUDA statevector (`--features cuda-fused`, the ≥10× path)

The `cuda` path above evolves the state with `tch` reshape+matmul, paying a
`movedim().contiguous()` copy of the whole `2^n` buffer **per gate** — that
copy is what caps it at 6–7×. The `cuda-fused` feature is the ≥10× lever: a
`cudarc` + NVRTC `double2` (complex128) kernel path that mutates the
amplitudes **in place** (one thread per amplitude pair/quad, no transpose,
one host sync at the end). The kernels are precision ports of omega's
`apply_1q.cu`/`apply_2q.cu`. **Not cuStateVec** — cuStateVec is not installed
and omega's own CUDA backend uses cudarc+NVRTC, so we mirror that.

```bash
source scripts/env.sh
# Correctness — fused vs ndarray reference AND vs the tch-CUDA path, ≤1e-10:
cargo test -p quantum-qml --features "cuda cuda-fused" \
    --test cuda_fused_crosscheck -- --test-threads=1
```

**Numeric checks (all self-skip if `FusedCudaSim::new()` errors / no GPU):**
- `fused_bell_matches_reference`, `fused_ghz_matches_reference`,
  `fused_mixed_gates_match_reference`, `fused_deep_layers_match_reference`
  (8q HEA): fused statevector vs the ndarray CPU reference **≤ 1e-10**, and
  ‖ψ‖² = 1 ± 1e-10.
- `fused_parametric_override_matches_reference`: the `params`-override path
  (the QML trainer's path) vs reference **≤ 1e-10**.
- `fused_one_shot_helper_matches_reference`: the `simulate_statevector_cuda_fused`
  one-shot helper vs reference **≤ 1e-10**.
- `fused_matches_tch_cuda_path` (needs both features): fused vs tch-CUDA,
  device-vs-device **≤ 1e-10**.

> **Fused CUDA bench** (`cargo bench -p quantum-qml --features "cuda cuda-fused"
> --bench tensor_statevector_cuda_fused`): three arms — `cpu`, `cuda_tch`
> (6–7×), `cuda_fused`. Measured on RTX PRO 6000 Blackwell (depth-2 ansatz,
> complex128): fused vs tch-CPU **n=22 → 42×, n=24 → 46×**; fused vs the
> tch-CUDA arm **~10×** (n=22 10.3×, n=24 10.2×, n=26 10.2×). The fused arm
> clears the ≥10× target the tch path could not. Baseline:
> `docs/bench-baselines/statevector-linux-cuda-fused.json`.

#### 5.2d OpenCL delegation (`--features omega-http` + omega-server)

OpenCL is **not** an in-tree backend — we delegate to omega-server, which
routes Statevector through its OpenCL backend (GPU_PLAN Phase 4). The
`OmegaHttpExecutor` posts the JSON IR; the integration test asserts the
delegated results match an in-tree CPU statevector reference, numerically.

**1. Bring up an OpenCL omega-server** (sibling repo `../omega-functions`):

```bash
cd ../omega-functions
# libOpenCL.so for the linker lives in the CUDA lib dir on this box:
export LIBRARY_PATH="/usr/local/cuda-12.9/targets/x86_64-linux/lib:${LIBRARY_PATH:-}"
cargo build -p omega-server --features opencl
OMEGA_PORT=8137 OMEGA_DEVICE=opencl OMEGA_DB_PATH=/tmp/omega-test.db \
  LD_LIBRARY_PATH="/usr/local/cuda-12.9/targets/x86_64-linux/lib:${LD_LIBRARY_PATH:-}" \
  ./target/debug/omega-server --auth bearer-only --save-token-to /tmp/omega.token &
```

**2. Run the delegation test** (back in `quantum/`):

```bash
cd ../quantum && source scripts/env.sh
export OMEGA_SERVER_URL=http://localhost:8137 OMEGA_TOKEN="$(cat /tmp/omega.token)"
cargo test -p quantum-qml --features omega-http --test opencl_delegate -- --nocapture
```

**Numeric checks** (the test self-skips if `OMEGA_SERVER_URL` is unset):
- Bell forced through Statevector: `backend == "statevector"`, counts sum to
  4096, support ⊆ {`00`,`11`}.
- GHZ(4): support ⊆ {`0000`,`1111`}, sum 4096.
- 4-qubit VQE ansatz: empirical distribution vs the in-tree CPU statevector
  **TVD < 0.06** (observed ≈ 0.017 at 4096 shots).
- Server stderr logs `[quantum] statevector via OpenCL device` (one or more
  lines per `execute` call), confirming the OpenCL device ran the circuits
  rather than the CPU fallback.

A matching CI stage (4d) runs this when `OMEGA_SERVER_URL` is set; otherwise
it skips. Python: build the wheel `--features omega-http` and call
`quantum._rust.omega_execute(url, token, circuit, shots, force_statevector=True)`.

> **Phase 6 bench** (`cargo bench -p quantum-qml --bench batched_gradient`):
> batched vs sequential parameter-shift. On CPU batched is ~0.54× (slower —
> tch dispatch overhead); the batched win is a GPU effect validated on
> `Device::Mps` after Phase 2. Baseline:
> `docs/bench-baselines/gradient-arm64-darwin-m4.json`.

### 5.3 quantum-py (PyO3 — see §9 for full build)

```bash
source scripts/env.sh
cargo check -p quantum-py            # type-check only; needs libtorch on link path
```

### 5.4 quantum-data (finance_lab port Phase 1 — no libtorch, no Python)

Pure-Rust OHLCV loaders + copula/AR(1)/joint-histogram transforms. Every
transform is an exact port of finance_lab's `qcbm_utils.py`, checked against
committed golden fixtures (`crates/quantum-data/tests/golden/golden.json`,
generated once offline from the real Python helpers — **no Python is linked at
build or test time**).

```bash
cargo test -p quantum-data                       # unit + golden parity (9 tests)
cargo test -p quantum-data --features duckdb-lake # + DuckDB round-trip (10 tests)
```

9 tests without the feature (4 unit + 5 golden parity), 10 with `duckdb-lake`:

| Test | Kind | Tolerance | What's checked |
|------|------|-----------|----------------|
| `ndtri_known_quantiles` | unit | ≤1e-12 | inverse-normal CDF (Cephes port of `scipy.norm.ppf`) at 0.5/0.975/0.025 |
| `empirical_cdf_monotone_and_ranked` | unit | ≤1e-15 | rank → `(r+0.5)/(N+1)` mapping on a hand example |
| `joint_hist_sums_to_one` | unit | ≤1e-9 | base-K packing, Σp=1, known bin |
| `ar1_passthrough_rho_zero` | unit | ≤1e-15 | `use_copula=false, ρ=0` ⇒ ε = shifted series |
| `empirical_cdf_matches_python` | parity | ≤1e-12 | rank-based empirical CDF vs golden |
| `joint_hist_matches_python` | parity | ≤1e-12 | base-K joint histogram vs golden |
| `ar1_copula_matches_python` | parity | ρ ≤1e-12, ε ≤1e-5 | AR(1) innovations (copula+ppf, estimated ρ); ε at f32 (Python returns float32) |
| `ar1_fixed_rho_matches_python` | parity | ≤1e-5 | AR(1) with fixed ρ, no copula |
| `csv_loader_semicolon_and_dateslice` | parity | ≤1e-12 | `;`-CSV load + ISO date slice (XAUUSD format) |
| `duckdb_roundtrip` | parity *(feature)* | ≤1e-12 | build fixture lake → read OHLCV by ticker/freq/date |

**Numeric manual — the shipped-artefact check.** The deterministic
`pipeline_demo` example runs the full copula → AR(1) → joint-histogram path on a
fixed `(2,6,2)` dataset (no RNG). Its output is Python-verified; run it and
check each line against the golden value:

```bash
cargo run -q -p quantum-data --example pipeline_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `ndtri_0975` | `1.959963984540054` | ≤1e-12 |
| `u00` | `0.576923076923077` | ≤1e-12 |
| `u_min` | `0.115384615384615` | ≤1e-12 |
| `u_max` | `0.961538461538462` | ≤1e-12 |
| `rho` | `-0.367996928096713` | ≤1e-12 |
| `eps_dims` | `2 5 2` | exact |
| `eps000` | `-0.1318809` | ≤1e-5 (f32) |
| `hist_K` | `4` | exact |
| `hist_bins` | `16` | exact |
| `hist_sum` | `1.000000000000` | ≤1e-9 |
| `hist_argmax` | `2` | exact |
| `hist_pmax` | `0.166666666667` | ≤1e-9 |

> The binary-only **dist** artefact (item 0b) gains a finance entrypoint in
> Phase 9 (`quantum-finance` CLI); until then the Phase-1 numeric manual is
> driven through this example binary.

### 5.5 Finance models — QCBM (finance_lab port Phase 2, requires libtorch)

Quantum Circuit Born Machine: H-prelude + `StronglyEntanglingLayers` read out as
`qml.probs`, trained by Adam on cross-entropy against the Phase-1 copula joint
histogram. Lives in `quantum-qml::models::qcbm`; covered by CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::            -- --test-threads=1  # 4 unit
cargo test -p quantum-qml --test qcbm_compat                              # PennyLane parity
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `models::qcbm::tests::probs_sum_to_one_and_right_length` | ≤1e-9 | `p_model` is a length-`2ⁿ` distribution |
| `models::qcbm::tests::trains_toward_target_distribution` | KL <0.05 | Adam reduces cross-entropy; residual KL small |
| `models::qcbm::tests::sampling_in_unit_interval` | exact | Born samples land in (0,1)ᴰ |
| `models::qcbm::tests::target_hist_from_eps_sums_to_one` | ≤1e-9 | copula-target builder |
| `qcbm_probs_match_pennylane` (`tests/qcbm_compat.rs`) | ≤1e-10 | circuit `probs` vs PennyLane qnode, 3 cases (4q/2L, 2q/3L, 6q/1L) |

**Numeric manual — end-to-end convergence.** `qcbm_demo` builds a fixed series,
extracts AR(1) copula innovations, trains a 4-qubit/3-layer QCBM, and Born-samples.
Deterministic (seeded θ init + parameter-shift forward); check each line:

```bash
cargo run -q -p quantum-qml --example qcbm_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `rho` | `0.890003` | ≤1e-5 |
| `K` | `4` | exact |
| `target_bins` | `16` | exact |
| `n_qubits` | `4` | exact |
| `target_entropy` | `2.455606` | ≤1e-3 |
| `final_loss` | `2.455606` | ≤1e-3 |
| `final_kl` | `0.000000` | <1e-2 (converged: p_model→p_target) |
| `tvd_model_target` | `0.000000` | <1e-2 |
| `initial_loss` > `final_loss` | yes | — |
| `sample_mean0` | `0.5037` | ±0.05 |
| `sample_mean1` | `0.5000` | ±0.05 |

> Aria mirror: `examples/aria/qcbm_strongly_entangling.aria` (parses +
> instantiates in the `aria_examples` coverage gate).

### 5.6 Finance models — TimeGAN (finance_lab port Phase 3, requires libtorch)

Classical TimeGAN core: five GRU/LSTM→Linear→Sigmoid nets (Embedder, Recovery,
Generator, Supervisor, Discriminator) trained on the canonical three-phase
schedule (embedding → supervised → joint adversarial) with the finance_lab loss
terms. `quantum-qml::models::timegan`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::timegan -- --test-threads=1   # 2 tests
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `timegan_converges_basic` | E_loss0 ↓, moment_gap <0.25 | embedding autoencoder learns; generated moments near real |
| `timegan_save_load_roundtrip` | ≤1e-5 | `.ot` checkpoint reload regenerates identically |

**Numeric manual — three-phase convergence.** `timegan_demo` trains on a fixed
48×16×3 series and reports diagnostics + a generated-vs-real mean. Deterministic
(seeded init + splitmix batching); check each line:

```bash
cargo run -q -p quantum-qml --example timegan_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `e_loss0_initial` | `3.8505` | ±0.05 |
| `e_loss0_final` | `1.2023` | ±0.10 |
| `e_loss0_improved` | `1` | exact (must fall) |
| `g_loss_s_initial` | `0.135551` | ±0.02 |
| `g_loss_s_final` | `0.003403` | <0.02 (falls ≫10×) |
| `d_loss_final` | `2.7980` | ±0.5 |
| `moment_gap` | `0.0388` | <0.1 |
| `real_mean` | `0.5205` | ±1e-3 |
| `synth_mean` | `0.5094` | ±0.05 |
| `mean_abs_gap` | `0.0110` | <0.05 |
| `synth_dims` | `64 16 3` | exact |

> Full discriminative/predictive-score parity vs Python (within 10%) is a
> deeper check tracked under plan item 3.7; §5.6 is the basic-convergence gate.

### 5.7 Finance models — TimeGAN + QCBM hybrid (Phase 4, requires libtorch)

The "qcbm_pretrained" hybrid: a frozen QCBM (trained on the copula joint
histogram) replaces the Gaussian latent — Born-sample → `ndtri` Gaussianize →
`(B,T,input_dim)` latent carrying the QCBM-learned dependence. CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::timegan::tests::timegan_qcbm_hybrid_converges -- --test-threads=1
```

**Numeric manual.** `timegan_qcbm_demo` trains the QCBM, freezes it as the
latent source, trains the hybrid TimeGAN. Deterministic; check each line:

```bash
cargo run -q -p quantum-qml --example timegan_qcbm_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `rho` | `0.8300` | ±1e-3 |
| `qcbm_K` | `2` | exact |
| `qcbm_final_kl` | `0.000000` | <1e-2 (QCBM converged) |
| `noise_dim` | `3` | exact (= input_dim) |
| `e_loss0_initial` | `3.8505` | ±0.05 |
| `e_loss0_final` | `1.2023` | ±0.10 |
| `e_loss0_improved` | `1` | exact |
| `g_loss_s_final` | `0.003403` | <0.02 |
| `moment_gap` | `0.0552` | <0.12 |
| `real_mean` | `0.5205` | ±1e-3 |
| `synth_mean` | `0.5093` | ±0.05 |
| `mean_abs_gap` | `0.0112` | <0.05 |
| `synth_dims` | `64 16 3` | exact |

> "qcbm_joint" mode (QCBM θ in the same optimizer) and the conditional variant
> are tracked under plan items 4.3/4.4; §5.7 covers the pretrained hybrid.

### 5.8 Finance models — PQC classifier (Phase 5 rich ansatz, requires libtorch)

Market-regime classifier: encoder (Linear→ReLU→Linear) → quantum block
(AngleEmbedding-Y + L×[ring IsingZZ + Rot], ⟨Z_i⟩ readout) → head
(Linear→ReLU→Linear). The quantum block separates data angles from trainable
weights; parameter-shift gradients flow to both (encoder *and* ansatz).
`quantum-qml::models::qclassifier`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::qclassifier -- --test-threads=1   # 1 test
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `qclassifier_learns_three_classes` | acc >0.75, loss ↓ | end-to-end training on separable 3-class blobs |

**Numeric manual.** `qclassifier_demo` trains on separable 3-class blobs.
Deterministic (seeded init + deterministic blobs + parameter-shift); check:

```bash
cargo run -q -p quantum-qml --example qclassifier_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_qubits` | `4` | exact |
| `n_classes` | `3` | exact |
| `loss_initial` | `1.4486` | ±0.1 |
| `loss_final` | `0.0003` | <0.1 (converged) |
| `loss_improved` | `1` | exact |
| `train_acc` | `1.0000` | ≥0.9 |
| `acc_above_chance` | `1` | exact |

> Aria mirror: `examples/aria/qclassifier_rich.aria`. The QCNN / amplitude
> ansätze, Z+ZZ / Z₀ readouts, mid-circuit measure, and val-accuracy-within-5pp
> parity are Phase-5 follow-ups (plan items 5.1 QCNN/amplitude, 5.2, 5.3, 5.5).

### 5.9 Finance models — Quantum GAN discriminator (Phase 6, requires libtorch)

The reference's commented-out quantum discriminator, brought to life: GRU →
last step → Linear → tanh·π angles → quantum block (AngleEmbedding-Y + L×(RY,RZ),
⟨Z_i⟩) → Linear → Sigmoid. A sequence-level real/fake score.
`quantum-qml::models::qgan`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::qgan -- --test-threads=1   # 1 test
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `qdiscriminator_separates_real_from_noise` | AUC >0.6, loss ↓ | trains to distinguish smooth sequences from noise |

**Numeric manual.** `qgan_demo` trains the discriminator on real-vs-noise.
Deterministic; check each line:

```bash
cargo run -q -p quantum-qml --example qgan_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_qubits` | `3` | exact |
| `loss_initial` | `1.4170` | ±0.1 |
| `loss_final` | `0.0129` | <0.2 (converged) |
| `loss_improved` | `1` | exact |
| `auc_final` | `1.0000` | ≥0.6 (plan target) |
| `auc_above_0p6` | `1` | exact |

> No strict Python parity (the reference discriminator is commented out); §5.9
> is the plan's sanity gate (AUC > 0.6). Slotting into the full TimeGAN loop as
> a config-flag discriminator (plan 6.2) is structural / off by default.

### 5.10 Finance models — Architecture search (Phase 7, requires libtorch)

Optuna replacement: a deterministic random/grid search over PQC-classifier
hyperparameters (`n_qubits`, `n_layers`, `lr`) scored by validation accuracy,
with a per-trial step budget. `quantum-qml::models::archsearch`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::archsearch -- --test-threads=1   # 1 test
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `search_selects_a_good_config` | best ≥ mean, >0.6 | the search runs N trials and selects the best by val accuracy |

**Numeric manual.** `archsearch_demo` searches 4 trials over a train/val split:

```bash
cargo run -q -p quantum-qml --example archsearch_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_trials` | `4` | exact |
| `best_val_acc` | `1.0000` | ≥0.6 |
| `best_config` | `nq3 nl2 lr0.05` | exact (deterministic winner) |
| `best_ge_mean` | `1` | exact |
| `best_above_chance` | `1` | exact |

> TPE/argmin surrogate + macro-F1 walk-forward CV + results CSV are deeper
> follow-ups (plan items 7.1/7.3/7.5); §5.10 covers the search loop + selection.

### 5.11 quantum-backtest (finance_lab port Phase 8 — no libtorch, no Python)

Pure-Rust walk-forward backtest harness: rolling train/test windows, a
`Strategy` mapping regime predictions to positions, and PnL/Sharpe/max-drawdown.
CI stage 2 (no external deps).

```bash
cargo test -p quantum-backtest          # 3 unit tests
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `splitter_rolls_windows` | exact | rolling window index ranges |
| `backtest_known_series` | ≤1e-12 | equity/PnL/drawdown on a hand series (1→1.1→1.045, dd 5%) |
| `strategy_beats_buy_and_hold_on_regime_signal` | — | regime strategy PnL > B&H, lower drawdown |

**Numeric manual.** `backtest_demo` runs a regime strategy vs buy-and-hold on a
synthetic regime-labeled series. Deterministic:

```bash
cargo run -q -p quantum-backtest --example backtest_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_windows` | `4` | exact |
| `strat_pnl` | `0.4800` | ±1e-3 |
| `bh_pnl` | `0.1200` | ±1e-3 |
| `strat_beats_bh` | `1` | exact |
| `strat_sharpe` | `14.1393` | ±0.01 |
| `strat_max_dd` | `0.0000` | ≤1e-3 |
| `bh_max_dd` | `0.0584` | ±1e-3 |
| `strat_dd_le_bh` | `1` | exact |
| `final_equity` | `1.6126` | ±1e-3 |

> Python `lab/baseline_regime.ipynb` equity-within-1% parity (plan acceptance)
> needs the notebook's data fixture; §5.11 is the numeric harness check.

### 5.11b quantum-qpu (GPU_PLAN Phase 8.A — no libtorch, no Python)

Real-machine (QPU) **provider abstraction**: the `QpuProvider` trait
(`submit → poll → result`, accepting the same `OmegaCircuitIR` as the local-GPU
path) plus `SimulatorProvider` — the reference backend that executes the IR
through an in-tree statevector + seeded SplitMix64 shot-sampler (the
omega-functions runtime mirrored in pure Rust). Deterministic. CI stage 2.

```bash
cargo test -p quantum-qpu               # 6 integration tests + 1 doctest
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `bell_is_5050_entangled` | ±5% | Bell job → `{00,11}` each ≈0.5, `01`/`10` = 0 (≤1e-9) |
| `ghz_is_5050_three_qubit` | ±5% | GHZ-3 → `{000,111}` each ≈0.5, zero leakage |
| `ry_rotation_matches_born_rule` | ±5% | `Ry(π/3)` → `P(1)=sin²(θ/2)=0.25` (Born rule) |
| `same_seed_reproduces_counts` | exact | same seed ⇒ identical counts; different seeds differ |
| `job_lifecycle_and_not_ready` | exact | `Queued→Running→Done`; early `result` ⇒ `NotReady` |
| `submit_validates_inputs` | exact | `UnknownBackend`/`LimitExceeded`/`UnknownJob` rejects |
| `conditioned_gate_is_unsupported` | exact | classically-conditioned gate ⇒ `Unsupported` (no silent wrong answer) |

**Numeric manual.** `qpu_bell` submits a Bell circuit to `SimulatorProvider`,
polls to Done, and prints the shot split. Deterministic (fixed seed 2026):

```bash
cargo run -q -p quantum-qpu --example qpu_bell
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `bell_00` | `0.5001` | ±0.05 |
| `bell_11` | `0.4999` | ±0.05 |
| `bell_leak` | `0.000000` | ≤1e-9 |
| `bell_ok` | `1` | exact |

> Real cloud providers (IBM 8.B / IonQ 8.C / omega-server HTTP) are hardware-
> gated; they drop in as additional `QpuProvider` impls with the same numeric
> Bell acceptance (50/50 ±5%).

### 5.11c quantum-photonics (item 12 photonic batch — no libtorch, no Python)

Pure-Rust linear-optical **Fock/SLOS engine** (beam splitters + phase shifters →
mode-transfer unitary → output photon-number distribution via permanents), the
**four adaptive/temporal primitives** (`fockstate` partial-mode measurement +
adaptive feed-forward, `distinguishability` partial-distinguishability SLOS,
`reservoir` memristive temporal feedback), and the **full photonic
reproduced-paper set**. In-tree reference mirroring `omega-backend-photonics`.
Deterministic. CI stage 2.

```bash
cargo test -p quantum-photonics         # engine + primitives + papers (+ doctest)
```

Engine goldens (exact, ≤1e-12): Hong–Ou–Mandel dip (two photons on a 50:50
splitter ⇒ `P(1,1)=0`, `P(2,0)=P(0,2)=0.5`), single-photon Born rule, output
distribution normalised, permanent values, deterministic seeded sampler.
Primitive goldens: `FockKet.evolve` probabilities = SLOS distribution (≤1e-10),
measurement branches sum to 1, partial-distinguishability coincidence
`P(1,1)=0.5·(1−η)` exact, memristive memory bounded + τ-monotone.

**Numeric manual.** `photonic_papers` runs all nine and prints each headline
metric vs reference, PASS/FAIL:

```bash
cargo run -q -p quantum-photonics --example photonic_papers
```

| Paper | Output metric | Expected | Tol |
|-------|---------------|----------|-----|
| `fock_state_expr` | accessible Fock dim (3 photons,3 modes) | `10` (=`C(5,2)`) | exact |
| `nearest_centroids` | `max\|P(overlap) − (a·b)²\|` | `0` | ≤1e-10 |
| `DQNN` | distributed 2-photon interference visibility | `1.0` | ≥0.99 |
| `QORC` | reservoir+linear-readout NMSE, `g(x)=sin2x` | `≈0` | ≤0.05 |
| `photonic_QGAN` | generator→target distribution L2 | `≈0` | ≤1e-3 |
| `photonic_genmodel` | MMD-trained generator final MMD² | `≈0` | ≤0.05 |
| `photonic_QCNN` | BAS test accuracy (adaptive injection) | `1.0` | ≥0.85 |
| `photonic_kernels` | indistinguishable−distinguishable kernel alignment | `≈0.13` | ≥0.05 |
| `qrc_memristor` | memristive reservoir NMSE on NARMA2 | `≈0.037` | ≤0.10 |
| final line | `PHOTONIC PARITY OK — 9/9 within reference` | — | exit 0 |

> The four primitives that previously blocked the last three papers (adaptive
> injection, partial-mode measurement, distinguishability, stateful reservoir)
> were built 2026-06-04 in `omega-backend-photonics` (commit `89ec960`) and
> mirrored here — see `docs/reproduced-papers.md` § "Photonic gap — CLOSED".

#### Photonic generative model — Track B (no libtorch)

The photonic train-on-classical / deploy-on-quantum model (Gottlieb et al. 2026,
arXiv:2603.08793). A 4-mode beam-splitter mesh fed `|1,1,0,0⟩` is trained by
finite-difference gradient descent on the squared MMD to match a realizable
teacher's output photon-number distribution. The exact SLOS distribution is the
referee; **deployment is boson sampling** (classically hard at scale). CI stage 2
+ `photonic_papers` `photonic_genmodel`.

```bash
cargo run -q -p quantum-photonics --example photonic_genmodel_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `hom_p11` (HOM coincidence sanity) | `0.000000` | ≤1e-10 |
| `n_output_states` (2 photons, 4 modes ⇒ `C(5,3)`) | `10` | exact |
| `mmd_exact_vs_empirical` (20k shots vs exact dist) | `0.005152` | ≤1e-5 (golden); bar ≤1e-2 |
| `mmd_initial` | `0.407811` | ≤1e-5 (golden) |
| `mmd_final` | mac `0.002026` / linux `0.011927` | ≤1e-5 (per-OS golden); ratio ≤0.03 |
| `tv_to_target` | mac `0.063559` / linux `0.131076` | ≤1e-5 (per-OS golden); bar ≤0.2 |

> The finite-difference MMD training loop accumulates libm float drift, so the
> two **post-training** lines are per-OS goldens (each exact + deterministic on
> its platform); every pre-training line agrees bit-for-bit across mac + linux.

> The 4-mode mesh is universal over the 10-state Fock space, so unlike the
> truncated-MMD IQP case (§5.11e) the model fits the *full* distribution well
> (TV≈0.06). On the **RTX6000 Pro** box: 12-photon / 12-mode training run +
> wall-clock (32-thread permanents).

### 5.11d Surrogates & sketching — Track C (requires libtorch)

The classically-tractable side of the "scale QML to more qubits / more data"
program, each piece certified against the exact circuit (CI stage 4a-C +
`papers_runner` `classical_surrogate`, `data_sketching`):

1. **RFF ≈ RBF kernel** (Bochner) — random Fourier features approximate the exact
   kernel Gram matrix.
2. **Classical surrogate of a quantum model** (arXiv:2206.11740) — an RFF+ridge
   regressor reproduces a single-qubit data-reuploading `⟨Z₀⟩(x)` (a truncated
   Fourier series). A small fidelity gap *is* the dequantization point.
3. **Johnson–Lindenstrauss sketch → 10-qubit quantum kernel** — the runnable
   analogue of Babbush et al.'s oracle sketching (arXiv:2604.07639); the
   fault-tolerant oracle-sketch itself is out of scope. A JL projection
   compresses 256-dim data while preserving pairwise distances so a 10-qubit
   quantum-kernel classifier matches the full-dim classifier.

Everything is deterministic (SplitMix64 + Box–Muller), so the numbers are golden.

```bash
cargo run -q -p quantum-qml --example surrogate_sketch_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `rff_kernel_relerr` | `0.0212` | ≤1e-3 (golden); bar ≤0.10 |
| `surrogate_fidelity` | `0.0023` | ≤1e-3 (golden); bar ≤0.05 |
| `jl_distortion_k128` | `0.3646` | ≤1e-3 (golden); bar ≤0.50 |
| `jl_distortion_k10` | `1.8192` | ≤1e-3 (golden; k=qubit budget, looser) |
| `n_qubits` | `10` | exact |
| `acc_full` | `1.0000` | exact |
| `acc_sketched` | `1.0000` | exact |
| `acc_gap` | `0.0000` | exact |

> On the **RTX6000 Pro** box (`QUANTUM_SCALE=1`) the same pipeline runs at
> d=50k → k=64 sketch with an n=24-qubit kernel; report `acc_gap` and wall-clock.

### 5.11e IQP Born machine — Track A (requires libtorch)

Train-on-classical / deploy-on-quantum generative model (arXiv:2503.02934). A
1-D chain-IQP Born machine `|ψ⟩=H^⊗n·D(θ)·H^⊗n|0⟩` is trained to match a
realizable teacher target by gradient descent on the **truncated analytic MMD**
— a poly-time estimator (transfer-matrix `⟨Z_S⟩`) that never touches the 2ⁿ
statevector, so the same code scales to many qubits. Sampling `p_θ` is
classically hard (deploy on quantum); `sample_exact` is verification-only.

The load-bearing certificate: the full-Fourier analytic MMD **equals** the exact
statevector MMD to ≤1e-10 — i.e. the efficient training objective is exact at
this size. CI stage 4a-A + `papers_runner` `iqp_born`.

```bash
cargo run -q -p quantum-qml --example iqp_born_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `n_qubits` | `12` | exact |
| `mmd_analytic_vs_exact` | `1.05e-13` | ≤1e-10 (certificate) |
| `mmd_initial` | `0.117284` | ≤1e-5 (golden) |
| `mmd_final` | `0.001603` | ≤1e-5 (golden); ratio ≈0.014 |
| `loss_monotone` | `1` | exact |
| `tv_to_target` | `0.411620` | ≤1e-4 (golden) |
| `mmd_empirical_deploy` | `0.002215` | ≤1e-4 (golden) |

> **Honesty.** The headline is the ≤1e-10 certificate and the MMD collapse
> (×0.014). `tv_to_target≈0.41` is *expected and reported, not hidden*: a
> truncated low-order MMD matches the target's low-order moments, not the full
> 4096-dim distribution — exactly the trade-off that makes training poly-time.
> On the **RTX6000 Pro** box (`QUANTUM_SCALE=1`) the same `train` runs at n=256
> and a 1000-qubit smoke (loss collapse only; sampling would need a QPU), with
> the ≤1e-10 certificate re-checked at the largest affordable n (≈28, CUDA).

### 5.11f Quantum Oracle Sketching — Track D (no libtorch)

Emulation of Quantum Oracle Sketching (Zhao/Babbush/Huang 2026,
arXiv:2604.07639; reference code github.com/haimengzhao/quantum-oracle-sketching).
QOS instantiates a query oracle **from a stream of random classical samples**
(no QRAM); the qubit count is `⌈log₂ dim⌉` — polylog in the dataset size, the
memory-advantage framing. We port the authors' **expected-unitary** benchmarking
mode and certify the headline claim on a statevector: the infidelity to the
exact oracle obeys the `O(1/N²)` sample-complexity law. CI stage 2 +
`papers_runner` `qos`. This is an emulation at small n; the fault-tolerant
hardware claim, the QSVT linear-algebra step, interferometric classical-shadow
readout, and the real RNA-seq / sentiment experiments are explicitly out of scope.

```bash
cargo run -q -p quantum-core --example qos_sketch_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `dim` | `1024` | exact |
| `n_qubits` (= `⌈log₂ dim⌉`) | `10` | exact |
| `infidelity_N64` | `2.081e-6` | ≤1e-9 (golden) |
| `infidelity_N1024` | `8.135e-9` | ≤1e-11 (golden) |
| `infidelity_N16384` | `3.178e-11` | ≤1e-13 (golden) |
| `error_ratio_2x` (the O(1/N²) law) | `3.9999` | ±0.05 |
| `block_encoding_err` (Halmos round-trip) | `0.00e0` | ≤1e-12 |

> The clean `≈4×` infidelity drop per doubling of samples *is* the paper's
> sample-complexity scaling, reproduced exactly. On the **RTX6000 Pro** box the
> same emulation runs at larger `dim` (more index qubits) where the full
> statevector is still cheap because the QOS oracle is diagonal.

**Dist artefact (item 0b).** QOS is libtorch-free, so the **stripped dist
`quantum` binary** runs it directly — the first scaling-QML track exercised
through the shipped artefact, not just `cargo run`:

```bash
quantum qos            # same goldens as above
quantum qos --dim 4096 # 12 index qubits
```

Expect `n_qubits 10`, `error_ratio_2x 3.9999`, `block_encoding_err 0.00e0`.

### 5.12 quantum-finance CLI (finance_lab port Phase 9, requires libtorch)

The single finance entrypoint — one binary, model subcommands. Mirrors
finance_lab's per-model binaries; the dist's finance face (item 0b). CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- help            # subcommand list
cargo run -q -p quantum-finance -- qcbm            # final_kl 0.000000
cargo run -q -p quantum-finance -- regime-classify # train_acc 1.0000
cargo run -q -p quantum-finance -- arch-search     # best_config nq3 nl2 lr0.05
cargo run -q -p quantum-finance -- backtest        # strat_beats_bh 1, final_equity 1.6126
cargo run -q -p quantum-finance -- timegan         # e_loss0_improved 1
cargo run -q -p quantum-finance -- timegan-qcbm    # e_loss0_improved 1
```

| Subcommand | Key output line | Expected | Tol |
|------------|-----------------|----------|-----|
| `qcbm` | `final_kl` | `0.000000` | <1e-2 |
| `regime-classify` | `acc_above_chance` | `1` | exact |
| `arch-search` | `best_config` | `nq3 nl2 lr0.05` | exact |
| `backtest` | `strat_beats_bh` | `1` | exact |
| `backtest` | `final_equity` | `1.6126` | ±1e-3 |
| `timegan` | `e_loss0_improved` | `1` | exact |
| `timegan-qcbm` | `e_loss0_improved` | `1` | exact |
| `help` | lists `qcbm`…`backtest` | — | — |

> The subcommand outputs reuse the per-model logic validated in §5.5–§5.11.
> Bundling `quantum-finance` into the stripped binary-only dist
> (`scripts/release/build-dist.sh`, item 0b) is the remaining packaging step
> (plan 9.3); the per-OS dist build/test runs on its own box.

### 5.13 quantum-finance `xauusd` — real XAUUSD daily data (Phase 9, requires libtorch)

End-to-end on **real market data**: the committed lake-export fixture
`examples/data/xauusd_1d.csv` (XAUUSD daily, 5462 bars, the file finance_lab's
GAN models train on) is loaded by `CsvOhlcvLoader` (`;`-delimited,
`YYYY.MM.DD HH:MM` dates), a trend regime is derived from a 20/50-day SMA
crossover (no lookahead — the regime at the *start* of each step picks that
step's position), and a "long the uptrend, flat the downtrend" strategy is
backtested against buy-and-hold. Fully deterministic: real prices in, no RNG.
CI stage 2 (loader parity) + stage 4 (CLI). The pure-Rust loader parity test
also runs with **no libtorch**:

```bash
# Loader parity (no libtorch, no Python) — shape + exact close anchors:
cargo test -q -p quantum-data --test xauusd_fixture   # 2 passed

source scripts/env.sh
cargo run -q -p quantum-finance -- xauusd examples/data/xauusd_1d.csv
```

| Output line | Expected | Tol | Meaning |
|-------------|----------|-----|---------|
| `n_bars` | `5462` | exact | daily bars in the fixture |
| `close_first` | `384.100` | ±1e-3 | first bar Close (source value) |
| `close_last` | `4246.310` | ±1e-3 | last bar Close (2025-12-01) |
| `exposure` | `0.5691` | ±1e-3 | fraction of days long (in uptrend) |
| `bh_final_equity` | `11.0552` | ±1e-3 | buy-and-hold equity (gold ~11× over span) |
| `bh_max_dd` | `0.4464` | ±1e-3 | buy-and-hold max drawdown |
| `strat_final_equity` | `3.8512` | ±1e-3 | trend strategy equity |
| `strat_max_dd` | `0.3375` | ±1e-3 | trend strategy max drawdown |
| `strat_lower_dd` | `1` | exact | **trend strategy cuts drawdown vs B&H** |

> **Honest result, not a cherry-pick.** Over a secular gold bull (384 → 4246,
> ~11× buy-and-hold), a long/flat trend filter that sits out ~43% of days does
> **not** beat buy-and-hold on total return or Sharpe — but it materially
> **reduces max drawdown** (0.4464 → 0.3375). The committed gate asserts the
> true property (`strat_lower_dd 1`) plus the exact data anchors; it does not
> claim the strategy "wins". Swapping in a different CSV (e.g. an AAPL/GOOGL
> lake export) reuses the same path: `xauusd <other.csv>`.

### 5.14 Regime labeling — features + Gaussian HMM (Phase 13)

The first true-1:1 roadmap phase (FINANCE_LAB_PORT_PLAN §4b). Two layers:

**(a) Pure-Rust parity (no libtorch, no Python).** `quantum_data::features`
reproduces finance_lab's `input_features` (logret/range/atr/rv/mom, exact pandas
rolling semantics) and `quantum_data::hmm` ports the StandardScaler + full-cov
Gaussian-HMM labeler. Golden fixtures minted offline by
`tests/golden/gen_features_golden.py` and `gen_hmm_golden.py` (numpy/pandas +
hmmlearn). CI stage 2.

```bash
cargo test -q -p quantum-data --test features_parity   # 1 passed (≤1e-10 vs pandas)
cargo test -q -p quantum-data --test hmm_parity         # 1 passed (scaler exact + dist)
```

| Check | Expected | Tol |
|-------|----------|-----|
| feature rows kept (XAUUSD) | `5438` | exact |
| feature first/last row + col sums/means vs pandas | — | ≤1e-10 |
| StandardScaler mean/std vs sklearn | — | ≤1e-10 |
| regime population fractions vs hmmlearn | within `0.12` | — |
| per-step label agreement vs hmmlearn | `> 0.55` (≈0.60) | — |

> **Honest scope.** The scaler is **exact** and the regime *distribution*
> matches hmmlearn; per-step label agreement is ≈0.60 (vs 0.33 chance) because
> hmmlearn seeds means with sklearn-KMeans and lands a different EM optimum —
> mostly disagreeing on the ambiguous mid-vol regime. Exact-segmentation parity
> is a documented deferred gate (plan §4d), not a silent gap.

**(b) End-to-end CLI** (`quantum-finance`, requires libtorch). Deterministic
(seeded EM) regime labels + beliefs on real XAUUSD. CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- regime-gen examples/data/xauusd_1d.csv
cargo run -q -p quantum-finance -- regime-gen examples/data/xauusd_1d.csv out.csv  # writes labels+beliefs
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_rows` | `5438` | exact |
| `regime0_frac` (low vol) | `0.4994` | ±1e-3 |
| `regime1_frac` (mid vol) | `0.3174` | ±1e-3 |
| `regime2_frac` (high vol) | `0.1832` | ±1e-3 |

> Regime fractions are deterministic (seeded EM), so they double as exact
> regression anchors. Other `--method` choices (`pca_kmeans`, `vol_term`, `kde`,
> `spectral`, `autoencoder`) are registered as could-be-added in plan §4d.

### 5.15 Classifier ansätze — QCNN + readout modes (Phase 12)

Completes the QNN classifier circuit topologies (FINANCE_LAB_PORT_PLAN §4b
Phase 12). The **QCNN** classifier (`quantum_qml::QcnnClassifier`): encoder →
AngleEmbedding(Y) → `pool_steps` × [conv across adjacent pairs, pool away the
upper half] → readout on the surviving wires → head. Conv/pool are the shared
Phase-0.5 primitives, so the quantum block is **bit-identical** to the
standalone `qcnn_circuit` (PennyLane-parity-tested ≤1e-12). Readout modes
(`Readout` enum): `Z`, `Z+ZZ`, `Z0`.

```bash
source scripts/env.sh
cargo test -q -p quantum-qml --lib qcnn_classifier -- --test-threads=1        # 4 passed
cargo test -q -p quantum-qml --lib amplitude_classifier -- --test-threads=1   # 2 passed
cargo run -q -p quantum-qml --example qcnn_classifier_demo
cargo run -q -p quantum-qml --example amplitude_classifier_demo
```

| Check | Expected | Tol |
|-------|----------|-----|
| QCNN quantum block vs `qcnn_circuit` primitive (statevector) | identical | ≤1e-10 |
| survivors after `pool_steps` (n=8, steps=1) | `[0,2,4,6]` | exact |
| `Readout` output counts (Z / Z+ZZ / Z0 on 4 wires) | `4 / 7 / 1` | exact |
| demo: QCNN learns 3-class blobs | `loss_improved 1`, `acc_above_chance 1` (train_acc 1.0) | — |
| Amplitude: zero-weight readout vs pure amplitude-embedded state | identical | ≤1e-10 |
| demo: amplitude classifier learns 3-class blobs (n_qubits 3, 24 weights) | `loss_improved 1`, `acc_above_chance 1` (train_acc 1.0) | — |

> **Honest scope.** Wired: the **QCNN** ansatz (12.1), the `Readout` enum
> `{Z, Z+ZZ, Z0}` (12.3), and the **amplitude-embedding** classifier (12.2 —
> Möttönen `AmplitudeEmbedding` → ring IsingZZ+Rot → Z+ZZ → head; data baked as
> concrete amplitudes, ansatz weights baked + param-shifted per eval). The
> mid-circuit-measure path (12.4) and wiring the CLI `qnn-pqc`/`qnn-amp` choices
> to these ansätze (a Phase-17 trait-object on the regime-classify QNN branch)
> are registered as could-be-added (§4d).

### 5.16 Regime classifier — supervised DNN / QNN (Phase 14)

The supervised classifier surface (FINANCE_LAB_PORT_PLAN §4b Phase 14). Trains a
classical **DNN** (or the **QNN** rich-ansatz classifier) on the regime labels
from §5.14, with a train-only StandardScaler (no leakage), causal
train/val/test split, accuracy + macro-F1 metrics, and class-weighted CE.

**(a) Pure-Rust building blocks (no libtorch).** `quantum_data::metrics`
(`accuracy`, `confusion_matrix`, `macro_f1` — sklearn `zero_division=0`
convention) and `quantum_data::split` (`time_ordered_split`, `stratified_split`,
`balance_train`). CI stage 2.

```bash
cargo test -q -p quantum-data --lib metrics   # macro_f1 vs hand-computation ≤1e-8
cargo test -q -p quantum-data --lib split      # causal/stratified/balance invariants
```

**(b) End-to-end CLI + cross-language parity** (`quantum-finance`, libtorch).
The DNN must land within **5 percentage points** of a scikit-learn
`MLPClassifier(128,128)` golden, and the pure-Rust GBDT within 5pp of a
`GradientBoostingClassifier(100,d3)` golden — same labeled fixture, same split,
same scaler. Goldens minted offline by `tests/golden/gen_classifier_golden.py`
(sklearn) → `golden_classifier.json` + `golden_boosting.json`; **zero Python at
test time**. CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- regime-classify train --model dnn
cargo run -q -p quantum-finance -- regime-classify train --model gbdt   # xgb/lightgbm alias
cargo run -q -p quantum-finance -- regime-classify train --model qnn-rich --qnn-max-rows 200
cargo test -q -p quantum-finance --test regime_classify_parity   # 2 passed (DNN + GBDT, within 5pp)
```

| Output line / check | Expected | Tol |
|---------------------|----------|-----|
| `n_train n_val n_test` (causal split) | `3806 / 544 / 1088` | exact |
| DNN `val_acc` / `test_acc` / `test_macro_f1` | `0.9210 / 0.9393 / 0.9033` (golden `0.9063 / 0.9375 / 0.9181`) | within 5pp |
| GBDT `val_acc` / `test_acc` / `test_macro_f1` | `0.9026 / 0.9366 / 0.9116` (golden `0.9026 / 0.9393 / 0.9158`) | within 5pp |
| DNN / GBDT determinism (seeded) | identical across runs | exact |

> **Honest scope.** Wired: `dnn`, `qnn{,-toy,-rich,-pqc}`, and boosting
> `gbdt`/`xgb`/`lightgbm` (a pure-Rust Friedman GBDT — *not* bit-exact to
> XGBoost/LightGBM, but a faithful functional 1:1, gated within 5pp of sklearn's
> GBDT). The QNN presets share the Phase-5 rich ansatz (distinct toy/QCNN/
> amplitude *circuits* are Phase 12); the param-shift forward is heavy, so QNN
> runs cap rows (`--qnn-max-rows`, reported never silent). Quantum-feature
> boosting (`pqc_*`/`qfeat_*`) is pending the QNN→GBDT feature wiring (§4d);
> `catboost` → "unsupported (no Rust backend)"; `tabpfn*` → "unsupported
> (pending Rust lib; `tabpfn` Cargo feature)" (§4c). Walk-forward CV objective is
> the Phase-16 surface.

**GPU (Phase 18.1).** The DNN is device-wired — build `--features cuda` and pass
`--device cuda` to run on `Device::Cuda(0)`; CI stage 4c2 gates it (GPU box).
The `bench-device` subcommand measures CPU vs CUDA (CPU 5.1× faster at the
finance size, CUDA 2.27× at large → `benchmarks/finance-device.md`), so CPU is
the measured-correct default.

```bash
cargo build -p quantum-finance --features cuda
./target/debug/quantum-finance regime-classify train --model dnn --device cuda   # device Cuda(0)
./target/release/quantum-finance bench-device --out benchmarks/finance-device.md
```

### 5.17 TimeGAN post-hoc metric nets (Phase 15)

Hardens the soft TimeGAN convergence gates (plan 2.4/3.7/4.5). Two post-hoc
metric nets (`quantum_qml::models::{discriminative_score, predictive_score}`),
faithful ports of `Conditional_TimeGAN_Pytorch/metrics/`:
* **Discriminative** — GRU(D→D/2)→Linear→sigmoid real/synthetic classifier
  (BCE, Adam 1e-3); score = `|0.5 − test_acc|`, **lower = better**.
* **Predictive (TSTR)** — GRU(D−1→D/2)→Linear(1) one-step predictor trained on
  **synthetic**, MAE on **real**; **lower = better**.

The hard gate: the TimeGAN's synthetic output must beat a noise baseline under
**both** metrics. Deterministic (seeded init + seeded batch sampler).

```bash
source scripts/env.sh
cargo test -q -p quantum-qml --lib metric_nets -- --test-threads=1   # 2 passed (separability)
cargo run  -q -p quantum-qml --example timegan_eval_demo
cargo run  -q -p quantum-finance -- timegan-eval                     # shipped binary
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `disc_synth` (TimeGAN) vs `disc_noise` | `0.2000` < `0.5000` | exact (seeded) |
| `pred_synth` (TimeGAN) vs `pred_noise` | `0.0372` < `0.2683` | exact (seeded) |
| `synth_beats_noise` | `1` (better on both metrics) | exact |
| unit: identical-data disc score | `< 0.25` | property |
| unit: noise-trained predictive MAE > real-trained | true | property |

> **Honest scope.** The metric nets + the synthetic-beats-noise hard gate are
> wired and deterministic. Exact cross-language **within-10%** value parity vs a
> committed Python (torch/TF) reference run (plan 15.4) is registered as a
> deferred deeper gate (§4d) — it needs a torch+tensorflow reference env, and
> the extreme-case scores (≈0.5 noise, ≈0 identical) are the robust anchors. The
> `{train,generate,eval}` sub-verb layout is Phase 17; here the metric is reached
> via `timegan-eval` + the library API.

### 5.18 Architecture search — TPE + walk-forward macro-F1 (Phase 16)

The full hyperparameter-search surface (FINANCE_LAB_PORT_PLAN §4b Phase 16).
A pure-Rust **categorical TPE** sampler (`quantum_data::TpeSampler`, the Optuna
replacement) drives `arch-search finetune`; the objective is **macro-F1**
averaged over an **expanding walk-forward** CV of the regime dataset. Model
axes: `mlp` (Phase-14 DNN) and `gbdt`/`xgb` (pure-Rust GBDT). CSV trial dump.

**(a) TPE sampler (pure Rust, no libtorch).** CI stage 2.

```bash
cargo test -q -p quantum-data --lib tpe   # 3 passed
```

| Check | Expected | Tol |
|-------|----------|-----|
| TPE locates the peak region on a 4×4 objective | best score ≥ −1 | property |
| TPE hits the exact optimum across seeds | ≥6/8 seeds | property |
| TPE mean trial score > random search | true | property |
| TPE deterministic (seeded) | identical | exact |

**(b) End-to-end CLI** (`quantum-finance`, libtorch). CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- arch-search finetune --model gbdt \
    --n-trials 6 --walk-folds 2 --max-rows 1200 --out-csv arch.csv
cargo run -q -p quantum-finance -- arch-search trainonce --model gbdt
cargo run -q -p quantum-finance -- arch-search finetune --model mlp --n-trials 4
```

| Output line / check | Expected | Tol |
|---------------------|----------|-----|
| `selected` (best ≥ mean) | `1` | exact |
| GBDT `best_macro_f1` | `0.8830` (≥ 0.85) | exact (seeded) |
| GBDT `best_params` | `n_estimators=80 max_depth=2 lr=0.2` | exact (seeded) |
| CSV rows | `--n-trials` | exact |
| determinism (rerun) | identical best | exact |

> **Honest scope.** Wired: TPE finetune + trainonce over `mlp`/`gbdt`, macro-F1
> walk-forward, CSV dump. `qnn` (param-shift search too costly), `res`,
> `catboost`, `tabpfn*` are surfaced as pending/unsupported (§4c/§4d). The
> `--study-name`/`--eval-seeds`/`--qubits {sweep,fix}` knobs are registered as
> could-be-added (§4d).

### 5.19 Conditional TimeGAN — `ctimegan` (Phase 11, part 1)

The conditional-generator core (FINANCE_LAB_PORT_PLAN §4b Phase 11). Faithful
port of `Conditional_TimeGAN_Pytorch/networks.py`'s `LearnableAlphaBeta` +
`ConditionalGenerator`, plus regime conditioning (`regime_vec_proj`):
the generator takes a per-sequence regime condition `c` and forms
`Zc = [α·Z ‖ β·c_rep]` (`α=softplus(a)+ε`, `β=softplus(b)+ε`, learnable) →
`sigmoid(fc(GRU(Zc)))`. Trained on the TimeGAN three-phase schedule.

```bash
source scripts/env.sh
cargo test -q -p quantum-qml --lib ctimegan -- --test-threads=1   # 1 passed
cargo run  -q -p quantum-finance -- ctimegan                      # shipped binary
cargo run  -q -p quantum-finance -- ctimegan-qcbm                 # QCBM-latent hybrid (11.6)
```

| Output line / check | Expected | Tol |
|---------------------|----------|-----|
| `e_loss0_improved` (autoencoder) | `1` | exact |
| `alpha_beta_positive` (softplus + ε) | `1` (α≈1.60, β≈0.37) | exact |
| `conditioning_effect` | `0.4418` (> 1e-3) | exact (seeded) |
| `gen_mean_regime0` vs `gen_mean_regime1` | `0.3935` vs `0.7033` (tracks data bases 0.30 / 0.65) | exact (seeded) |
| `conditioning_works` | `1` | exact |
| `ctimegan-qcbm`: `noise_dim` + `conditioning_works` (QCBM latent, 11.6) | `3`, `1` | exact |

> **Honest scope.** Part 1 wires `LearnableAlphaBeta` (11.1), the
> `ConditionalGenerator` (11.3), and regime conditioning via `regime_vec_proj`
> (subset of 11.2). Deferred (§4d): the full conditioning surface
> (`logret_proj`/`cond_sim`/`cond_norm`/`cond_drop`/`z_diversity`), the
> boundary-continuity losses (11.4), and scenarios/fan-chart numeric artifacts +
> `self_baseline`/Brownian baseline (11.5) — later Phase-11 parts. The
> `ctimegan_qcbm` QCBM-latent hybrid (11.6) is wired (`ctimegan-qcbm`); the
> cached-Z reuse schedule (`fix_z`/`z_refresh_*`) is a §4d follow-up.

### 5.20 finance run scripts + migration (Phase 17.3 / 17.4 / 17.5)

The 1:1 swap-in for finance_lab's `run_*.sh`, driving the shipped Rust CLI
(`examples/finance/`). The orchestrator `run_all.sh` runs each workflow with
numeric assertions and prints `RUN OK`. CI stage 4.

```bash
source scripts/env.sh
QF_BIN="$PWD/target/debug/quantum-finance" bash examples/finance/run_all.sh   # fast → RUN OK
QF_BIN="$PWD/target/debug/quantum-finance" RUN_FULL=1 bash examples/finance/run_all.sh  # + training
```

| Check | Expected | Tol |
|-------|----------|-----|
| `run_all.sh` (fast: qcbm + xauusd + regime) | `RUN OK:` | — |
| `run_xauusd.sh` | `FIN OK: xauusd` (n_bars 5462, close_last 4246.310) | exact |
| `run_regime.sh` | `FIN OK: regime` (n_rows 5438, val_acc ≥ 0.88) | numeric |
| `run_timegan.sh` (RUN_FULL) | `FIN OK: timegan` (synth_beats_noise 1) | exact |
| `run_ctimegan.sh` (RUN_FULL) | `FIN OK: ctimegan` (conditioning_works 1) | exact |
| `run_archsearch.sh` (RUN_FULL) | `FIN OK: arch-search` (best_f1 ≥ 0.85) | numeric |

The 1:1 command mapping (Python → Rust, flag-by-flag) + the unsupported/deferred
list is [`docs/finance-lab-migration.md`](../docs/finance-lab-migration.md).

**Dist bundling (17.4).** `scripts/release/build-dist.sh` ships
`bin/quantum-finance` + `examples/data/xauusd_1d.csv` + `examples/finance/*.sh`
+ the migration doc **when `LIBTORCH` is set** (the variant pairs with one); the
bundled `run.sh` then runs the `xauusd` numeric anchor (degrading to a skip if
libtorch is not on the verify host's path). The libtorch-free core dist builds
and verifies unchanged.

> **Honest scope.** Phase 17 wires the run scripts (17.3), the migration doc
> (17.5), and dist bundling of the finance binary (17.4). The `{train,generate,
> eval}` sub-verb *nesting* (17.1) and notebook rendering (17.6) are registered
> as could-be-added (§4d) — the current flat subcommands expose the same compute
> 1:1, and the migration table maps each Python command to them.

---

## 6. CI pipeline (`./scripts/ci.sh`)

Single command runs all 11 stages. Stages without their tool installed
print `⊘ skipped` (yellow) instead of failing red.

```bash
./scripts/ci.sh                       # stages 1–10
QUANTUM_MATHLIB=1 ./scripts/ci.sh     # also stage 11 (mathlib build)
```

> **Activate the project venv first.** Stage 5 (`quantum-py`) links PyO3,
> which rejects Python newer than 3.13. A bare shell whose `python3` is a
> newer system/Homebrew Python (e.g. 3.14) fails stage 5. Use the project
> `.venv` (Python ≤3.13) per §2/§3.1 — `source .venv/bin/activate` — before
> `./scripts/ci.sh`. (ci.sh self-configures libtorch/DYLD, but not the venv.)

| Stage | What | Required dep |
|-------|------|--------------|
| 1 | `cargo fmt --all --check` | Rust |
| 2 | `cargo test -p quantum-core` | Rust |
| 3 | `cargo test -p quantum-core --test macro_test` | Rust |
| 4 | `cargo test -p quantum-qml` | libtorch |
| 5 | `cargo check -p quantum-py` | libtorch |
| 6 | WASM guests `vqe/qaoa/ecc` (`cargo build --target wasm32-wasip1`) | wasm32-wasip1 target |
| 7 | Rust example smoke (41 examples) + bench compile + Lean spec-extract CLI smoke + editor-plugin JSON/JS smoke | Rust (+ node for 7d) |
| 8 | `cargo clippy` (warnings allowed, non-fatal) | Rust |
| 9 | Lean4 standalone (`Standalone.lean` → 23 thms; `Generated_Closed.lean` → Bell/DJ/GHZ) | Lean |
| 10 | Rocq (`QLibCompat.v`, `Gates.v`, `QFT.v`, `Grover.v`) | Rocq |
| 11 | Lean4 mathlib (`lake build QuantumProofs`) — opt-in, needs `QUANTUM_MATHLIB=1` | Lean + mathlib oleans |

**Stage 9 expected output:**

```
✓ 23 Lean4 theorems verified
✓ Generated_Closed: bell + DJ + GHZ closed-form proofs verified
```

**Stage 11 expected output:** `mathlib-backed proofs compile (sorries expected)`.
The 8 known sorries are tracked in `TODO.md` §1b/2/3.

---

## 7. Examples, benchmarks, WASM guests

### 7.1 Rust examples

```bash
# No libtorch:
cargo run -p quantum-core --example shor
cargo run -p quantum-core --example qft_qpe
cargo run -p quantum-core --example block_encoding

# Needs libtorch:
source scripts/env.sh
cargo run -p quantum-qml --example qml_classifier
```

Selected expected outputs (sanity checks):

| Example | Expect |
|---------|--------|
| `shor` | `15 = 3 x 5`, `21 = 3 x 7`, `35 = 7 x 5` |
| `qft_qpe` | QFT QASM output, QPE circuit for T gate |
| `qml_classifier` | Training accuracy ~94% |
| `vqe` | H₂ ground-state energy → −1.137 Ha |
| `aria_grover` | 2q 100%, 3q 95% success; Lean4 export header |
| `aria_qft` | QFT(n) >> QFT(n).inverse() gate counts before/after optimizer |
| `shor_ecdlp` | Gate counts ≥ 100 000, depth ~50 000 |
| `shor_ecdlp_secp256k1` | ~5M physical qubits at code distance 35 |

#### 7.1a MBQC resource comparison (item 11 A3.3 — numeric)

Gate-model vs measurement-pattern resource side-by-side for Bell, GHZ(3),
QFT(4), Toffoli. Every `SUMMARY` field is checked against a golden value.

```bash
OUT=$(cargo run -q -p quantum-core --example mbqc_resource_compare)
echo "$OUT" | grep -q "SUMMARY Bell: gates=2 qubits=2 | vertices=5 edges=4 layers=3 meas=3 nonclifford=0"    && echo "bell ok"
echo "$OUT" | grep -q "SUMMARY GHZ(3): gates=3 qubits=3 | vertices=8 edges=7 layers=5 meas=5 nonclifford=0"   && echo "ghz ok"
echo "$OUT" | grep -q "SUMMARY QFT(4): gates=12 qubits=4 | vertices=80 edges=94 layers=76 meas=76 nonclifford=18" && echo "qft ok"
echo "$OUT" | grep -q "SUMMARY Toffoli: gates=1 qubits=3 | vertices=31 edges=34 layers=28 meas=28 nonclifford=7"  && echo "toffoli ok"
```

**Expect:** `bell ok`, `ghz ok`, `qft ok`, `toffoli ok` (4 lines). The
vertex/edge/measurement counts are the exact `circuit_to_pattern` output;
`nonclifford` is the count of non-(π/2-multiple) measurement angles (the
MBQC T-count analogue).

#### 7.1b MBQC CLI (item 11 B6 — numeric)

`quantum mbqc <input>` compiles a circuit to an MBQC pattern and prints the
resource, the `optimize()`d resource, the deterministic-sim output norm, and
the UBQC δ-lattice invariant. Golden run on a Bell circuit:

```bash
printf 'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[2];\nh q[0];\ncx q[0],q[1];\n' > /tmp/bell.qasm
OUT=$(cargo run -q -p quantum-core --bin quantum -- mbqc /tmp/bell.qasm)
echo "$OUT" | grep -q "pattern vertices=5 edges=4 layers=3 measurements=3 nonclifford=0" && echo "pattern ok"
echo "$OUT" | grep -q "optimized vertices=3 layers=1 measurements=1"                     && echo "optimize ok"
echo "$OUT" | grep -q "output_norm=1.000000"                                             && echo "norm ok"
echo "$OUT" | grep -q "ubqc_on_lattice=3/3"                                              && echo "ubqc ok"
```

**Expect:** `pattern ok`, `optimize ok`, `norm ok`, `ubqc ok` (4 lines).
Bell compiles to 5 pattern vertices; `optimize()` cuts it to 3 (40%
reduction); the deterministic output is normalized; and all 3 UBQC δ angles
sit on the {kπ/4} lattice (Clifford circuit).

#### 7.1c MBQC conditional gates / teleportation (item 11 A1.5 — numeric)

`mbqc_conditional_demo` compiles a teleportation circuit (mid-circuit `Measure`
+ classically-conditioned Pauli corrections; Aria form `examples/aria/teleport.aria`)
to an MBQC pattern. The conditional Paulis on the terminal output become
`Pattern::output_corr` byproducts — A1.5 "classical control becomes a flow edge".

```bash
OUT=$(cargo run -q -p quantum-core --example mbqc_conditional_demo)
echo "$OUT" | grep -q "1 output byproduct(s)" && echo "byproduct ok"
echo "$OUT" | grep -q "^RUN OK: A1.5"          && echo "run ok"
```

**Expect:** `byproduct ok`, `run ok` (2 lines). The demo asserts internally
(non-zero exit on failure, so CI stage 7 gates it): over 64 sampled
trajectories the X/Z output Pauli fires **iff** its source measurement outcome
is 1, matching hand-applied `X^{s}`/`Z^{s}` on the output qubit ≤1e-12.

#### 7.1d MBQC Lean-spec export (item 11 C4.1/C4.2 — numeric)

`mbqc_spec_export` emits the Lean circuit↔pattern obligation for Bell + GHZ via
`spec::render_pattern_proof` (the `PatternD` literal + `U|+⟩^n` expected vector
from `simulate_pattern_deterministic` + the `native_decide` theorem).

```bash
OUT=$(cargo run -q -p quantum-core --example mbqc_spec_export)
echo "$OUT" | grep -q "def bell_pattern : PatternD"                     && echo "bell literal ok"
echo "$OUT" | grep -q "theorem ghz_pattern_correct : ghz_pattern_ok"    && echo "ghz theorem ok"
echo "$OUT" | grep -q "^RUN OK: MBQC pattern Lean export"               && echo "run ok"
```

**Expect:** `bell literal ok`, `ghz theorem ok`, `run ok` (3 lines). The example
asserts each emission is well-formed with a normalized `U|+⟩^n`; the emitted
`bell_pattern`/`ghz_pattern` literals match the CI-verified hand-written
obligations in `Generated_Closed.lean` (§8.1, stage 9b).

#### 7.1e Networked UBQC client/server (item 11 B6 follow-on — numeric)

The BFK '09 blind client and the executing server can run in **two processes**
over a socket (not just in-process). `quantum-server` gained stateful
`ubqc.reset`/`ubqc.message` methods; `quantum mbqc … --remote <addr>` drives the
client against it. The server only ever sees blinded `δ` angles.

```bash
printf 'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[2];\nh q[0];\ncx q[0],q[1];\n' > /tmp/bell.qasm
SOCK="/tmp/quantum-ubqc-$$.sock"
cargo run -q -p quantum-core --bin quantum-server -- --listen unix:"$SOCK" &
SRV=$!
for n in $(seq 1 50); do [ -S "$SOCK" ] && break; sleep 0.1; done
OUT=$(cargo run -q -p quantum-core --bin quantum -- mbqc /tmp/bell.qasm --remote unix:"$SOCK")
kill $SRV 2>/dev/null; rm -f "$SOCK"
echo "$OUT" | grep -q "ubqc_remote_on_lattice=3/3 recovered=3" && echo "remote ubqc ok"
```

**Expect:** `remote ubqc ok` (1 line). The networked run reproduces the
in-process δ-lattice invariant (§7.1b `ubqc_on_lattice=3/3`): all 3 blinded
angles land on `{kπ/4}` over the wire and all 3 outcomes `s = b ⊕ r` are
recovered. The hermetic TCP-loopback equivalent (no external process) is the
`ubqc_net` integration test in CI stage 2 (`cargo test -p quantum-core`).

#### 7.1f CV-MBQC cluster + GKP grid states (item 11 C2 / C2.4 — numeric)

The continuous-variable track is verified by unit tests in CI stage 2. To run
just those numeric checks:

```bash
cargo test -q -p quantum-core --lib -- mbqc::cv mbqc::gkp 2>&1 | tail -3
```

**Expect:** `test result: ok.` with **8 tests** (3 CV + 5 GKP). The CV tests
assert a cluster's nullifier variances equal `e^{−2r}/2` (≤1e-9) and vanish as
the squeezing `r→∞`; the GKP tests assert the finite-energy `|0⟩/|1⟩/|±⟩` grid
states are L²-normalised (≤1e-6), the position stabiliser `⟨cos(2√π q̂)⟩` matches
`e^{−πΔ²}` (≤5e-3) and → 1 as Δ→0, the logical `Ẑ = ⟨cos(√π q̂)⟩` separates the
sublattices (`+`/`−`/`≈0` on `|0⟩`/`|1⟩`/`|±⟩`), and `|+⟩` is a period-`√π` comb.

#### 7.1g Verifiable UBQC + blind end-to-end + rotation merge (item 11 A2.2 / B2.3 / B4.4 — numeric)

The verifiable-UBQC trap weaving (B4.4), the blind multi-vertex output recovery
(B2.3), and the A2.2 rotation-merge optimization are verified by unit tests in
CI stage 2. To run just those numeric checks:

```bash
cargo test -q -p quantum-core --lib -- mbqc::verify mbqc::ubqc::tests::blind mbqc::pattern::tests::merge mbqc::flow::tests::optimize_merges 2>&1 | tail -3
```

**Expect:** `test result: ok.` covering the FK '17 dotted-graph guarantees
(trap `+`-probability ∈ {0,1} ≤1e-9 inside the entangled register; honest pass
over 64 seeds on `D(K₅)`; measured-`δ` uniform within 15% across 400 rounds with
every lattice bin role-mixed; graph role-independent; orthogonal-basis cheat
caught deterministically; random-basis cheat caught ≈½/round), the blind
end-to-end recovery (`blind_execute` output = `simulate_pattern_deterministic` =
`U|+⟩` ≤1e-9 up to global phase over 24 secret/Born draws × {line, Bell, GHZ};
secret-independent), and the rotation merge (consecutive `Rz` fuse, ρ invariant
≤1e-12, `optimize()` beats the Clifford-only baseline).

### 7.2 Aria DSL files

Every Rust `aria_*.rs` example has an `.aria` companion under
`examples/aria/`. See `examples/aria/README.md` for the surface syntax
and parser roadmap. Mapping table:

| Aria file | Rust counterpart |
|-----------|------------------|
| `bell.aria` | `aria_style.rs` (section 1) |
| `grover3.aria` | `aria_grover.rs`, `grover.rs` |
| `qft.aria` | `aria_qft.rs`, `qft_qpe.rs` |
| `vqe_ansatz.aria` | `aria_vqe.rs`, `vqe.rs` |
| `teleport.aria` | `teleportation.rs` |
| `deutsch_jozsa.aria` | `deutsch_jozsa.rs` |
| `bernstein_vazirani.aria` | `bernstein_vazirani.rs` |
| `simon.aria` | `simon.rs` |
| `superdense.aria` | `superdense.rs` |
| `swap_test.aria` | `swap_test.rs` |
| `qpe.aria` | `qft_qpe.rs` |
| `qaoa_maxcut.aria` | `qaoa_maxcut.rs` |
| `shor_ecdlp.aria` | `shor_ecdlp.rs`, `shor_ecdlp_secp256k1.rs` |
| `qml_classifier.aria` | `qml_classifier.rs` (in quantum-qml) |
| `qgan.aria` | `qgan.rs` (in quantum-qml) |
| `quantum_kernel.aria` | `quantum_kernel.rs` (in quantum-qml) |
| `hhl.aria`, `qsvt_invert.aria`, `qsvd.aria` | `linalg_solve.rs`, `qsvd.rs` |
| `mbqc_bell.aria`, `mbqc_rotation.aria` | `mbqc_demo.rs` |
| `mbqc_ghz.aria`, `mbqc_grover3.aria`, `mbqc_qft4.aria`, `mbqc_rotations.aria`, `mbqc_u3.aria`, `mbqc_clifford_opt.aria` | `mbqc_verify.rs` (A1/A2/A4 round-trip, ≤1e-9; clifford_opt ≥30% optimize) |
| `teleport.aria`, `mbqc_feedforward.aria` | `aria_examples.rs` (A1.5 conditional→byproduct: terminal `output_corr` vs internal `x_corr_from`, fires-iff-source-1 ≤1e-12) |

### 7.3 CLI tool

```bash
cargo run -p quantum-core --bin quantum -- info     circuit.qasm
cargo run -p quantum-core --bin quantum -- optimize circuit.qasm -o optimized.qasm
cargo run -p quantum-core --bin quantum -- compile  circuit.qasm --format ffi -o circuit.bin
cargo run -p quantum-core --bin quantum -- spec extract \
    --aria examples/aria/bell.aria --instantiate "Bell" --out /tmp/lean-out
```

#### 7.3a Surface-code error correction (`quantum ecc` — numeric, multi-backend)

`quantum ecc` builds a rotated surface code `[[d²,1,d]]`, injects a Pauli error,
extracts the stabilizer syndrome on a selectable simulator backend
(`statevector` / `stabilizer`|`pauli` / `mps`), minimum-weight (MWPM) decodes,
and reports the result numerically. It requires the `omega-sim` feature (the
omega-functions statevector/stabilizer/MPS backends); the **stripped dist build
links it in** (see §0b — `build-dist.sh` adds `--features omega-sim` on native
builds). Source build:

```bash
cargo run -p quantum-core --features omega-sim --bin quantum -- ecc --distance 3 --backend stabilizer
```

**Run against the stripped dist artefact** (the manual's source of truth):

```bash
QBIN="$QUANTUM_DIST/bin/quantum"          # from a build-dist.sh tarball
"$QBIN" ecc --distance 3 --backend stabilizer
"$QBIN" ecc --distance 3 --backend statevector
"$QBIN" ecc --distance 3 --backend mps
"$QBIN" ecc --distance 3 --backend stabilizer --p 0.01 --shots 8000 --seed 7
```

Expected output (deterministic; the default error is an X on the centre qubit):

| Line | Expected | Tolerance |
|------|----------|-----------|
| `clean_syndrome_weight` | `0` | exact |
| `z_syndrome` (X@4, d=3) | `1,1,0,0` | exact |
| `correction_x` | `4` | exact |
| `residual_syndrome_weight` | `0` | exact |
| `logical_failure` | `0` | exact |
| `backend_agreement` | `1` (statevector = stabilizer = mps = pauliprop, bit-for-bit) | exact |
| `backends_checked` (d=3) | `statevector,stabilizer,mps,pauliprop` (4-way) | exact |
| `single_error_decode` | `18/18` (all single X & Z errors corrected) | exact |
| `suppressed` (p=0.01, seed 7) | `1` (logical_rate `0.0032` < physical `0.01`) | logical_rate ≤ 0.006 |

The `backend_agreement 1` line is the headline numeric: the exact statevector,
the MPS tensor-network and the Clifford stabilizer simulators return identical
syndromes. The Rust twin is the `ecc_surface` example
(`cargo run -p quantum-core --features omega-sim --example ecc_surface`), and the
dist demo is `quantum-examples/demo/12-ecc/run.sh`.

> If the dist was built without `omega-sim` (a `cross`/Docker Linux build, where
> the sibling `../omega-functions` path is not mounted), `quantum ecc` prints a
> rebuild hint and exits 2 — by design; the rest of the dist is unaffected.

##### Distance 5 `[[25,1,5]]` — scalable backends only (the RAM-safe path)

At `--distance 5` each CSS sector is a **37-qubit** circuit
(`25` data `+ 12` checks). A *dense statevector* of 37 qubits is `2³⁷ ≈ 1.37e11`
complex amplitudes `≈ 2 TB` — it will exhaust RAM and be OOM-killed. `quantum
ecc` therefore **refuses** the statevector backend past `ECC_STATEVECTOR_MAX_QUBITS
= 26` and runs only the simulators that scale: the **Clifford stabilizer**
(`stabilizer`/`pauli`, an Aaronson–Gottesman tableau, O(n²)) and the **MPS**
tensor network (bond-capped). Both run d=5 in **< 5 MB**.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
"$QBIN" ecc --distance 5 --backend stabilizer
"$QBIN" ecc --distance 5 --backend mps
"$QBIN" ecc --distance 5 --backend statevector            # must refuse, exit 2
"$QBIN" ecc --distance 5 --backend stabilizer --p 0.05 --shots 2000 --seed 7
```

Expected (default error is an X on the centre data qubit, index 12):

| Line | Expected | Tolerance |
|------|----------|-----------|
| header | `ecc surface d=5 [[25,1,5]] data=25 x_checks=12 z_checks=12` | exact |
| `z_syndrome` (X@12) | `0,0,1,0,0,1,0,0,0,0,0,0` | exact |
| `correction_x` / `mwpm_weight` | `12` / `1` | exact |
| `residual_syndrome_weight` / `logical_failure` | `0` / `0` | exact |
| `backend_agreement` | `1` (stabilizer = mps = pauliprop, bit-for-bit) | exact |
| `backends_checked` | `stabilizer,mps,pauliprop` (statevector skipped) | exact |
| `single_error_decode` | `50/50` (all `2·25` single X & Z errors corrected) | exact |
| `suppressed` (p=0.05, seed 7) | `1` (logical_rate `0.044` < physical `0.05`) | logical_rate ≤ 0.05 |
| statevector run | exits **2**, prints `infeasible for distance 5 (37 qubits)` | exact |
| peak RSS (stabilizer or mps) | a few MB | `< 100 MB` |

> **Why this matters for the dist artefact.** The statevector gate
> (`ecc_backend_feasible`) lives in `quantum.rs`; a binary built *before* it
> existed runs the 2 TB statevector at d=5 and is OOM-killed (`exit 137`). The
> manual is run against the **freshly built** stripped dist binary precisely so a
> stale build cannot pass.

##### Distance 7 `[[49,1,7]]` and beyond — Pauli propagation (`pauliprop`)

The measurement backends key their syndrome on a 64-bit `Counts` integer, so a
73-qubit d=7 sector is refused (`exit 2`). The **`pauliprop`** backend (Pauli
propagation — a Heisenberg-picture tree of weighted Pauli strings,
[arXiv:2505.21606](https://arxiv.org/abs/2505.21606); engine in
`../omega-functions/crates/omega-backend-pauliprop`) reads each check's
**expectation value** `⟨C⟩ = ±1` on the bare data state — no ancilla, no
measurement key — so it is exact and `O(MB)` for the Clifford syndrome at *any*
distance.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
"$QBIN" ecc --distance 7 --backend pauliprop
"$QBIN" ecc --distance 7 --backend stabilizer                    # must refuse, exit 2
"$QBIN" ecc --distance 7 --backend pauliprop --p 0.03 --shots 1500 --seed 7
"$QBIN" ecc --distance 9 --backend pauliprop                     # [[81,1,9]]
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| header (d=7) | `ecc surface d=7 [[49,1,7]] data=49 x_checks=24 z_checks=24` | exact |
| `syndrome_weight` (X@24) | `2` | exact |
| `logical_failure` | `0` | exact |
| `backends_checked` (d=7) | `pauliprop` (sole feasible backend) | exact |
| `single_error_decode` (d=7) | `98/98` | exact |
| `single_error_decode` (d=9) | `162/162` | exact |
| `suppressed` (d=7, p=0.03, seed 7) | `1` (logical_rate `0.008` < physical `0.03`) | logical_rate ≤ 0.03 |
| stabilizer/mps/statevector at d=7 | exit **2**, message points to `pauliprop` | exact |
| peak RSS (pauliprop d=7) | a few MB | `< 100 MB` |

> The `pauliprop` agreement is the strongest cross-check in the suite: at d=3 it
> is the **fourth** backend in `backends_checked` and reproduces the
> statevector/stabilizer/mps syndrome bit-for-bit, then carries the *same* code
> to distances no other backend can simulate.

#### 7.3b Pauli-propagation expectation values (`quantum expect`)

`quantum expect <circuit> --observable "Z0,Z1Z2" [--backend B] [--truncate C]`
computes `⟨O⟩` for Pauli observables. The headline backend is **`pauliprop`**
(Pauli propagation — a Heisenberg-picture Pauli-string tree): exact and
width-unbounded for Clifford circuits, a `--truncate`-tunable approximation for
non-Clifford ones (`statevector`/`mps` are the dense cross-checks). Like `ecc`
it needs `omega-sim`; the expectation backend gets the larger ECC qubit cap, the
dense backends the general cap.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend pauliprop  --observable "Z0,Z2,Z0Z5,Z1Z2Z3"
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend statevector --observable "Z0,Z2,Z0Z5,Z1Z2Z3"
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend pauliprop  --observable "Z2" --truncate 1e-2
"$QBIN" expect demo/13-pauliprop/ghz24.qasm         --backend pauliprop  --observable "Z0Z23,Z0"
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `observable …` (pauliprop) vs (statevector) on the Ising circuit | identical for every observable | exact (≤ 1e-9) |
| `dropped_mass` (Ising, `--truncate 1e-2`) | `> 0`, and `|approx − exact| ≤ dropped_mass` | exact bound |
| `observable Z0Z23` / `Z0` (24-qubit GHZ, pauliprop) | `1.0000000000` / `0.0000000000` | exact |
| statevector on the 24-qubit GHZ | refused under the eval cap (exit 2) — or, uncapped, equals pauliprop | exact |

The Rust twin is `omega-backend-pauliprop`'s `tests/expectation.rs` (8 checks);
the dist demo is `demo/13-pauliprop/run.sh` (5 checks). The same backend is
selectable in `omega-run --backend pauliprop --expectation "<Pauli>"`.

### 7.4 Benchmarks (criterion)

```bash
# Compile check only (fast):
cargo bench -p quantum-core --bench optimizer   --no-run
cargo bench -p quantum-core --bench statevector --no-run

# Full run (slow — statistical sampling):
cargo bench -p quantum-core --bench optimizer
```

Coverage:
- `optimizer` — `default_pipeline`, `fast_t_merge`, `phase_poly_dedup`, `internal_h_opt` on Clifford+T at 4q/64g, 6q/128g, 8q/256g; `qft_roundtrip_optimize` for n ∈ {3,5,7}
- `statevector` — CPU baseline for n ∈ {12,14,16,18} (GPU baseline for the item-8 doc)

### 7.4b QML benchmark matrix + regression gate (GPU_PLAN Phase 9)

Times forward eval + three gradient methods per `{device, n}` on a
data-reuploading circuit, emits JSON, and gates on regression vs a committed
per-host baseline. Requires libtorch (`source scripts/env.sh`).

```bash
# Print the bench matrix as JSON:
cargo run -q -p quantum-qml --example bench_matrix

# Regenerate this host's baseline (only when intentionally re-baselining):
./scripts/bench-compare.sh --regen

# Run the regression gate against the committed baseline (what CI stage 12 does):
./scripts/bench-compare.sh ; echo "exit=$?"
```

**Numeric checks** (macos-aarch64 baseline, `docs/bench-baselines/macos-aarch64.json`):
- Gate exit code is **0** (no metric ≥ 1.5× its baseline). Re-run 2–3×: stays 0.
- The scaling signature holds on every run: **`adjoint_ms_per_param` is roughly
  flat in `n`** (~0.04–0.06 ms at n=4,6,8) while **`param_shift_ms_per_param`
  grows steeply** (~0.43 → ~2.0 → ~10 ms at n=4,6,8) — adjoint is one reverse
  sweep, param-shift is `2k` full simulations. So
  `param_shift_ms_per_param(n=8) / adjoint_ms_per_param(n=8) > 100`.
- `batched_ms_per_param < param_shift_ms_per_param` at every `n` (batching the
  `2k` shifted vectors beats sequential evaluation).
- Strict 20% gate on a quiesced host: `QUANTUM_BENCH_FACTOR=1.20
  ./scripts/bench-compare.sh` also exits 0.

> **No GitHub CI.** GPU_PLAN Phase 9.4 (`gpu-ci.yml`) is intentionally **not**
> created — per the project rule, CI is the local `scripts/ci.sh` only. The
> gate runs as ci.sh **stage 12**, opt-in via `QUANTUM_BENCH=1`.

### 7.4c Reproduced-papers parity runner (item 12b)

Runs each ported gate-model paper and reports a headline metric vs a reference
with PASS/FAIL (`docs/reproduced-papers.md`). Requires libtorch.

```bash
source scripts/env.sh
cargo run -q -p quantum-qml --example papers_runner ; echo "exit=$?"
cargo run -q -p quantum-qml --example papers_runner -- qSSL     # single paper
```

**Numeric checks:**
- Final line is `PAPERS PARITY OK — 12/12 within reference`, exit code **0**.
- Analytic metrics hit their closed form exactly: qSSL `max|⟨Z_i⟩−cos(x_i)| ≈ 0`
  (≤ 1e-10), data_reuploading `|⟨Z⟩ − cos(w₁)| ≈ 0` (≤ 1e-10), adversarial FGSM
  optimality margin `≥ 0`, QCNN `|⟨Z⟩| ≤ 1`, AA_study trace distance ≤ 0.01.
- Training-bar metrics clear their bars: HQNN loss ratio ≤ 0.8, nn_embedding
  separation gain ≥ 1.2, QRKD loss ratio ≤ 0.5, QLSTM/QRNN sequence loss ratio
  ≤ 0.6, HQPINN rel-L2 vs the analytic damped-oscillator solution ≤ 0.42,
  qLLM quantum-adapter accuracy ≥ 0.85 on an XOR task (all deterministic under
  `tch::manual_seed(0)`).
- These are also gated as unit tests: `cargo test -p quantum-qml --test papers -- --test-threads=1` → `12 passed`.

### 7.5 WASM guests

```bash
# All three:
for g in vqe qaoa ecc; do
  (cd examples/wasm-guests/$g && cargo build --release --target wasm32-wasip1)
done

# Sizes (expected):
ls -lh examples/wasm-guests/*/target/wasm32-wasip1/release/*.wasm
# vqe.wasm  ~90 KB,  qaoa.wasm similar, ecc.wasm uses omega_execute_shots
```

The ECC guest uses `omega_execute_shots` + repetition-code majority
vote across 5 physical-error probabilities; confirm with:

```bash
grep -n omega_execute_shots examples/wasm-guests/ecc/src/main.rs
```

---

## 8. Formal proofs

### 8.1 Lean4 — standalone (no mathlib, in CI stage 9)

23 Float-level theorems covering Pauli self-inverse, H² = I, HXH = Z,
HZH = X, XZ anti-commutation, S² = Z, Grover probability bounds,
DFT = Hadamard up to sign, CX/CZ correctness, QPE phase accuracy.

```bash
cd proofs/lean4
lean --run Standalone.lean | tail -2
# Expected trailing line: ✓ All quantum theorems verified (23 total)
```

Also: `lean --run Generated_Closed.lean` runs the closed-form Bell /
Deutsch-Jozsa / GHZ proofs (extracted from Aria via `spec extract`,
then hand-finished with `native_decide`) **plus the MBQC C4 circuit↔pattern
correspondence for Bell and GHZ** — `mbqc_cx_correct` (the gadget `(I⊗H)·CZ·(I⊗H)`
= CNOT), `bell_mbqc_correct` (Bell via MBQC primitives = (|00⟩+|11⟩)/√2),
`mbqc_ghz_gadgets_correct` (both CX gadgets = CX(0,1)/CX(1,2)), and
`ghz_mbqc_correct` (GHZ via primitives = (|000⟩+|111⟩)/√2), all `native_decide`
— **plus the general `denote_pattern` obligations** `bell_pattern_correct` /
`ghz_pattern_correct` (`denote_pattern` of the actual `circuit_to_pattern`
output = the circuit on the |+⟩ input, for Bell n=5 and GHZ n=8 patterns).
Expect six extra `✓ MBQC: …` lines before `All Generated_Closed proofs verified`.

### 8.2 Lean4 — mathlib-backed (opt-in, CI stage 11)

**Use the precompiled olean cache — never let lake rebuild from source.**
`./scripts/setup-mathlib.sh` calls `lake exe cache get` which pulls the
~500 MB of compiled `.olean` files from mathlib's Azure blob storage.

```bash
./scripts/setup-mathlib.sh             # idempotent; --force to re-resolve

# Then build the project's proofs (links against the cached oleans):
(cd proofs/lean4 && lake build QuantumProofs)
```

`Mathlib.olean` lands at `proofs/lean4/.lake/build/lib/Mathlib.olean`.
The setup script also smoke-tests `QFT.lean` to verify the pin resolves
before declaring success.

Current sorry counts — **11 deliberate** (item-13 layer tracked in
`TODO.md` §1b/2/3; MBQC/UBQC layer tracked in `MBQC_PLAN.md` Track C3):

| File | Sorries | Status |
|------|---------|--------|
| `BlockEncoding.lean` | 0 | ✓ closed |
| `CircuitSemantics.lean` | 1 | `shifted_qubit_rest_two` Nat helper |
| `QFT.lean` | 1 | `qft_correct` step (Cooley–Tukey assembly) |
| `QPE.lean` | 2 | Dirichlet kernel lower bound |
| `Grover.lean` | 4 | 2D-subspace rotation + main theorems |
| `MBQC.lean` | 1 | abstract determinism stub (`MBQC_PLAN.md` C-track) |
| `UBQC.lean` | 2 | `marginal_independence_of_phi` + `ubqc_blindness` (`MBQC_PLAN.md` C3.3/C3.4) |

**C5 mathlib `denote_pattern` layer (`MBQC_PLAN.md` §C5 steps 1–3 + 4a) —
sorry-free.** `MBQC.lean` now carries the deep mathlib-`Matrix` MBQC
denotation: the `Pattern` IR, `graphState = (∏ CZ_edges)·H^⊗n`, the `+`-branch
measurement projector `plusProj` (proved an orthogonal projector:
`plusProj_idem` ∧ `plusProj_herm`), `measLayer`, the raw operator
`denote_pattern_plus_raw`, and the output-restricted readout
`denote_pattern_plus`. Three concrete readout validations close
`native_decide`-free: `denote_pattern_plus_one_plus` (1-vertex `|+⟩` = `1/√2`),
`denote_pattern_plus_measured` (`+`-basis measure ⇒ `⟨+|+⟩ = 1`), and
`denote_pattern_plus_two_graph` (2-qubit graph state on edge `(0,1)` =
`½(|00⟩+|01⟩+|10⟩−|11⟩)`). The only `MBQC.lean` sorry remains
`gflow_determinism`. Numeric check (after `lake build QuantumProofs` succeeds):

```bash
M=proofs/lean4/QuantumProofs/MBQC.lean
grep -cE '^[[:space:]]+sorry[[:space:]]*$' "$M"                        # 1  (gflow_determinism only)
grep -cE 'theorem (plusProj_idem|plusProj_herm|denote_pattern_plus_one_plus|denote_pattern_plus_measured|denote_pattern_plus_two_graph)' "$M"  # 5
grep -cE '^(noncomputable )?def (graphState|measLayer|plusProj|denote_pattern_plus|denote_pattern_plus_raw|measBraWeight|vbit|outMatch|hadamardLayer|czLayer)' "$M"  # 10
```

### 8.3 Rocq 9.1.x — `QLibCompat` shim (CI stage 10)

Compiles **without** `coq-quantumlib` installed (the shim provides the
naming). Migration path documented in §"To migrate to real coq-quantumlib".

```bash
cd proofs/rocq
coqc -Q . QuantumProofs QLibCompat.v
coqc -Q . QuantumProofs Gates.v
coqc -Q . QuantumProofs QFT.v
coqc -Q . QuantumProofs Grover.v
```

Files:
- `Gates.v` — σ{x,y,z} self-inverse, XZ anti-commute, S² = Z
- `QFT.v` — 1-qubit QFT structural lemmas (off-diagonal symmetric, top row uniform)
- `Grover.v` — success probability ∈ [0, 1] via `SIN_bound` + `nra`

To migrate to real `coq-quantumlib` once it ships for Rocq 9.x: update
`proofs/rocq/dune` to `(theories QuantumLib Coq)` and delete
`QLibCompat.v` — every other file already uses QuantumLib-compatible naming.

---

## 9. Python wheel (PyO3 / maturin)

Mixed maturin layout: `crates/quantum-py/python/quantum_py/`
(pure-Python facade + bundled `quantum_py.client` socket client) +
compiled Rust extension `quantum_py._rust`. Python ≥ 3.8.

### 9.1 Editable dev loop

```bash
python3 -m venv .venv
source .venv/bin/activate
unset CONDA_PREFIX                      # if conda is active
source scripts/env.sh
pip install maturin
cd crates/quantum-py && maturin develop --release && cd ../..
python python/examples/demo.py
```

### 9.2 Binary-only wheel

```bash
cd crates/quantum-py && maturin build --release --strip && cd ../..
pip install --force-reinstall --no-deps target/wheels/quantum_py-*.whl

# Smoke-test the installed wheel
DYLD_LIBRARY_PATH=$LIBTORCH/lib python3 -c "
import quantum_py
c = quantum_py.bell(False)
print(quantum_py.recommended_backend(c))          # Stabilizer
obs = quantum_py.Observable.z(0).scale(0.5)
print(obs.n_terms())                              # 1
print(quantum_py.to_omega_ir(c)[:80], '...')
print(quantum_py.decode_mwpm(3, [1,0,0,0,0,0,0,0]))
print(quantum_py.client.Client)                   # socket client class
"
```

On Linux, use `LD_LIBRARY_PATH` instead of `DYLD_LIBRARY_PATH`.

### 9.3 Python smoke checklist

- [ ] `python3 -c "import quantum_py; print(quantum_py.__version__)"` → `0.1.0`
- [ ] `Observable.z(0).add(Observable.x(1)).scale(0.5).n_terms() == 2`
- [ ] `quantum_py.recommended_backend(bell(False)) == "Stabilizer"`
- [ ] `to_omega_ir(bell(False))` starts with `{"num_qubits":2,...`
- [ ] `optimize_with_passes(c, ["adjacent","adjoint"], 2)` drops identity/adjoint pairs
- [ ] `decode_mwpm(3, [0]*8) == ([], [], 0)`
- [ ] `decode_mwpm(3, [1,0,0,0,0,0,0,0])` → non-empty `x_flips`, weight 1
- [ ] `from quantum_py.client import Client` imports from the wheel
- [ ] `python python/examples/demo.py` and `full_demo.py` run unchanged

---

## 10. Release packaging

See `scripts/release/README.md` for full usage. TL;DR:

```bash
# Current machine, CPU, 90-day timebomb (default)
./scripts/release/build-host-cpu.sh

# 7-day evaluation bundle
QUANTUM_EXPIRY_DAYS=7 ./scripts/release/build-host-cpu.sh

# Cross-compile all CPU targets (skip missing toolchains)
SKIP_MISSING=1 ./scripts/release/build-all-cpu.sh

# GPU builds
LIBTORCH=/opt/libtorch-macos-arm64       ./scripts/release/build-host-gpu.sh
LIBTORCH_CUDA=/opt/libtorch-cu121        ./scripts/release/build-all-gpu.sh cuda
```

Fast end-to-end smoke:

```bash
rm -rf dist
QUANTUM_EXPIRY_DAYS=7 ./scripts/release/build-host-cpu.sh
tar -tzf dist/quantum-*-cpu.tar.gz | head -20
./dist/stage-*-cpu/bin/quantum --help
```

Expected:
- Tarball in `dist/`
- Contains `bin/quantum`, `examples/aria/*.aria`, `examples/rust/*.rs`,
  `examples/wasm-guests/*/src/main.rs`, `docs/README.md`, `docs/TESTING.md`
- `./bin/quantum --help` prints usage + 7-day expiry banner on stderr

### 10.1 Timebomb checklist

- `QUANTUM_EXPIRY_DAYS=7` → warning + CLI runs
- `QUANTUM_EXPIRY_UNIX=1` (past) → "expired" message, exit code 2
- `QUANTUM_EXPIRY_DAYS=0` → no banner, silent run

### 10.1a Evaluation bundle — qubit caps (`QUANTUM_TEST=1`)

The customer eval bundle (`QUANTUM_TEST=1`, the `*-test` tarball shipped with
`demo/`) bakes **two** independent qubit caps:

- `QUANTUM_MAX_QUBITS` — general circuit cap (default **12**). Refuses any
  general `info`/`compile`/simulation over the cap.
- `QUANTUM_ECC_MAX_QUBITS` — separate cap for `quantum ecc` (default **64** in
  test mode). The surface-code demo needs 13 qubits at d=3, 37 at d=5, 49 at
  d=7, so it gets its own ceiling while general simulation stays capped at 12.
  Defaults to `QUANTUM_MAX_QUBITS` when unset; `0` = unlimited (normal builds).

Numeric checks against a `QUANTUM_TEST=1` bundle (`QUANTUM_MAX_QUBITS=12`,
`QUANTUM_ECC_MAX_QUBITS=64`):

| Command | Expected |
|---|---|
| `quantum ecc --distance 7 --backend pauliprop` | runs, `single_error_decode 98/98` (49 ≤ ecc cap 64) |
| `quantum ecc --distance 9 --backend pauliprop` | refused: `limited to 64 qubit(s); refusing a 81-qubit circuit` (exit 2) |
| `quantum info <13-qubit.qasm>` | refused: `limited to 12 qubit(s)` (general cap; exit 2) |
| `cat $DIST/TEST-BUILD.txt` | `Qubit cap : 12 qubits general / 64 qubits for 'quantum ecc'` |

### 10.1b Cross-built Linux bundles — `ecc` is inert (skips)

`quantum ecc` links the `omega-functions` backends, which only compile in a
**native** build. A `cross` (Docker) Linux build ships `ecc` inert (it prints a
rebuild hint and exits 2), so `demo/12-ecc` **skips cleanly** there. Because the
omega backends are *optional path deps in a sibling workspace*, the cross
container must mount it for lockfile resolution — `Cross.toml` exposes
`OMEGA_FUNCTIONS_DIR`, which `build-dist.sh` sets automatically for cross builds.

```bash
# from the mac box: cross-build the Linux eval bundles (ecc inert)
QUANTUM_TARGET=x86_64-unknown-linux-gnu  QUANTUM_TEST=1 ./scripts/release/build-dist.sh cpu
QUANTUM_TARGET=aarch64-unknown-linux-gnu QUANTUM_TEST=1 ./scripts/release/build-dist.sh cpu
# on the Linux/CUDA box: amd64 is NATIVE (ecc live, finance bundlable); only
# arm64 goes through cross — rootless docker needs the engine flag or the
# container trips on the /target mount ("Permission denied … .cargo-build-lock"):
CROSS_ROOTLESS_CONTAINER_ENGINE=1 QUANTUM_TARGET=aarch64-unknown-linux-gnu \
  QUANTUM_TEST=1 ./scripts/release/build-dist.sh cpu
# verify in a stock container (numbers only): all demos pass; 03/06-08 skip.
# Cross-built bundles additionally skip 12/13 (ecc inert); a NATIVE amd64
# bundle (built on the Linux box) runs 12/13 live in the same container.
docker run --rm --platform linux/amd64 -v "$PWD/dist":/qx:ro debian:bookworm-slim bash -c '
  mkdir -p /tmp/q && tar xzf /qx/quantum-dist-linux-amd64-cpu-test-*.tar.gz -C /tmp/q
  export QUANTUM_DIST="$(ls -d /tmp/q/dist-*)" && bash "$QUANTUM_DIST/demo/run-all.sh"'
# -> ALL DEMOS PASSED  (03 skips: no cargo; 06-08: no libtorch)
```

### 10.2 Binary-only dist — numeric manual test (REQUIRED)

> This is the **canonical** way to run this manual: against the shipped,
> stripped, source-free distribution — not `cargo run`. Numbers only.
> Landed 2026-05-30 (item 0b): `scripts/release/build-dist.sh` +
> `verify-dist.sh`.

**Dist variants we ship (item 0b).** Four artefacts. **Mac variants are
built & tested on the mac dev box; Linux variants (`linux-cpu` +
`linux-cuda`) are built & tested on the Linux/CUDA box** (no cross-compile
of libtorch-linked binaries; see `LINUX_GPU_PLAN.md`). Run this manual on
the host that matches the variant you built.

| Variant | OS | Accel | Script | Build host |
|---|---|---|---|---|
| `mac-metal`  | macOS (Apple Silicon) | Metal (MPS) | `build-dist.sh metal`| mac dev box |
| `mac-cpu`    | macOS (Apple Silicon) | CPU only    | `build-dist.sh cpu`  | mac dev box (sanity) |
| `linux-cpu`  | Linux x86_64          | CPU only    | `build-dist.sh cpu`  | Linux/CUDA box |
| `linux-cuda` | Linux x86_64          | CUDA        | `build-dist.sh cuda` | Linux/CUDA box (NVIDIA) |
| `linux-gpu`  | Linux x86_64          | CUDA (vendor-neutral tag) | `build-dist.sh gpu` | Linux/CUDA box (NVIDIA) |
| `*-delegate-opencl` | either         | OpenCL via delegation | `build-dist.sh delegate-opencl` | either (CPU binaries + `OMEGA_SERVER_URL` doc) |

> **`gpu` arg + finance CUDA.** `build-dist.sh gpu` is the host GPU build under
> a vendor-neutral tag (Linux ⇒ cuda build, Darwin ⇒ metal build). On Linux,
> any cuda-kind build with `LIBTORCH` set compiles the bundled `quantum-finance`
> `--features cuda` (force-links `libtorch_cuda.so`; `--device cuda` ⇒
> `Device::Cuda(0)`; pair with the cu128 libtorch 2.7.0). Setting
> `QUANTUM_TARGET` to the **host triple** keeps the build native (finance +
> omega-sim ecc enabled) and opts into the arch-tagged name the
> quantum-examples repo ships, e.g. `linux-amd64-gpu`.

`delegate-opencl` (GPU_PLAN Phase 10.3) ships the same libtorch-free binaries
as `cpu`; OpenCL is reached at runtime via `OMEGA_SERVER_URL` delegation (see
`docs/OPENCL-DELEGATE.md` inside the bundle). Verify it exactly like the others:

```bash
SOURCE_DATE_EPOCH=1700000000 ./scripts/release/build-dist.sh delegate-opencl
./scripts/release/verify-dist.sh dist/quantum-dist-*-delegate-opencl-*.tar.gz
# Expect: manifest sha256 OK, 0 source files, run.sh "RUN OK ... Qubits=2, H-count=1".
# Bundle includes docs/OPENCL-DELEGATE.md (≈1.6 KB larger than the cpu tarball).
```

Build the variant for the current host, then verify through the unpacked
binaries. The commands below derive the variant tag from the OS so they
work verbatim on either host (`mac-cpu` on Darwin, `linux-cpu` on Linux):

```bash
# 0. Variant tag for THIS host (Darwin -> mac, Linux -> linux).
case "$(uname -s)" in Darwin) V=mac-cpu ;; Linux) V=linux-cpu ;; esac

# 1. Build the binary-only dist for THIS host's build type.
./scripts/release/build-dist.sh cpu          # CPU-only  -> dist/quantum-dist-$V-<sha>.tar.gz
# ./scripts/release/build-dist.sh metal      # macOS GPU  (V=mac-metal)
# ./scripts/release/build-dist.sh cuda        # Linux + NVIDIA (V=linux-cuda)

# 2. Verify: manifest sha256s + no-source guard + numeric run.sh end-to-end.
#    (Pin the freshest tarball — the glob can match several if dist/ has stale ones.)
./scripts/release/verify-dist.sh "$(ls -t dist/quantum-dist-$V-*.tar.gz | head -1)"   # exit 0
```

> **Linux tar note (item 0b).** The reproducible tar step branches on `$OS`:
> GNU tar (Linux) uses `--owner=0 --group=0`; bsdtar (macOS) uses
> `--uid 0 --gid 0`. GNU tar rejects `--uid` (exit 64 → empty 20-byte
> tarball), so this branch is what makes `linux-cpu`/`linux-cuda` package
> correctly. If a future tarball comes out ~20 bytes, that branch regressed.

`verify-dist.sh` unpacks, re-checks every file's sha256 against
`MANIFEST.txt`, asserts **no source leaked**, then runs the bundled
`run.sh`. You can also run `run.sh` by hand:

```bash
case "$(uname -s)" in Darwin) V=mac-cpu ;; Linux) V=linux-cpu ;; esac
D=$(mktemp -d); tar xzf "$(ls -t dist/quantum-dist-$V-*.tar.gz | head -1)" -C "$D"
ROOT="$D/dist-$V"
"$ROOT/run.sh"          # starts packaged server, pings it, checks Bell stats
```

**Numeric checks (no GUI), all asserted by `verify-dist.sh` / `run.sh`:**
- `verify-dist.sh` exits `0` and prints `manifest: N files, sha256 OK` +
  `0 source files found`.
- `run.sh` starts `bin/quantum-server`, pings it (the server returns
  `{"pong": <build_unix>}`), then runs `bin/quantum info examples/bell.qasm`
  and asserts the **exact** statistics: **Qubits = 2, H-count = 1**. It
  prints `RUN OK …` on success and exits non-zero otherwise.
- (The standalone server does ping/info/parse/optimize/compile — circuit
  *execution*/counts is the omega-server's job, out of this bundle. The
  numeric contract here is the deterministic CLI statistics, not sampled
  counts.)

Two builds with the same `SOURCE_DATE_EPOCH` produce **identical sha256**
for the tarball (verified: `ci.sh` `QUANTUM_DIST=1` re-runs the build and
diffs the sha). MANIFEST per-file sha256 is the primary reproducibility
contract.

---

## Troubleshooting

### libtorch / tch-rs

| Symptom | Cause | Fix |
|---------|-------|-----|
| `libtorch not found` | `LIBTORCH` unset | `source scripts/env.sh` |
| `tch version mismatch` | Wrong libtorch version | `./scripts/setup-libtorch.sh` pulls the pinned 2.7.0 (matches tch 0.20) |
| CUDA tests all *skip* on an NVIDIA box | `libtorch_cuda.so` not `DT_NEEDED` (linker `--as-needed`) | rebuild `--features cuda` (build.rs forces it); check `readelf -d <testbin> \| grep cuda` |
| `CUDA error: no kernel image` | cu124/2.4.0 libtorch on a Blackwell GPU | reinstall with `setup-libtorch.sh cu128` (2.7.0) |
| `dyld: Library not loaded` (macOS) | `DYLD_LIBRARY_PATH` missing | `source scripts/env.sh` re-exports it |
| `cannot find -ltorch` (Linux) | `LD_LIBRARY_PATH` missing | `source scripts/env.sh` |
| `CXX11 ABI mismatch` (Linux) | Wrong libtorch variant | Use the `cxx11-abi` zip — `setup-libtorch.sh` already does this |
| `wrong architecture` (macOS) | Intel libtorch on Apple Silicon | Re-run `./scripts/setup-libtorch.sh` (auto-detects arm64) |
| Slow first build | torch-sys C++ compile | Normal — ~30s one-time |

### Python / maturin

| Symptom | Fix |
|---------|-----|
| `VIRTUAL_ENV + CONDA_PREFIX` warning | `unset CONDA_PREFIX` before `maturin develop` |
| `PyO3 link error` | Use `maturin develop`, **not** `cargo build -p quantum-py` |
| `ModuleNotFoundError: quantum_py._rust` | Re-run `maturin develop --release` from `crates/quantum-py/` |
| `pip install fails on wheel` (Linux) | Set `LD_LIBRARY_PATH=$LIBTORCH/lib` before `pip install` |

### Lean / mathlib

| Symptom | Fix |
|---------|-----|
| `lake: command not found` | Install elan: `curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh \| sh` |
| `Mathlib.olean missing` | `./scripts/setup-mathlib.sh` (pulls precompiled oleans) |
| `lake exe cache get` is slow | Normal — ~500 MB download; runs once |
| Toolchain version mismatch | The proof dir has its own `lean-toolchain`; `cd proofs/lean4 && lean --version` triggers elan to install the pin |
| Stage 11 fails with new sorries | Check `TODO.md` §1b/2/3 + `MBQC_PLAN.md` C3 — **11 sorries are deliberate** (8 item-13 + MBQC 1 + UBQC 2); anything else is regression |

### Rocq

| Symptom | Fix |
|---------|-----|
| `coqc: command not found` | macOS: `brew install rocq-prover`; Linux: opam path in §3.2 |
| `Cannot find QuantumLib` | Should not happen — proofs use `QLibCompat.v` shim, not real QuantumLib. Re-check you ran `coqc QLibCompat.v` first |
| Version < 9.1 | The shim targets Rocq 9.1; older versions need opam upgrade |

### WASM

| Symptom | Fix |
|---------|-----|
| `wasm32-wasip1 target not installed` | `rustup target add wasm32-wasip1` |
| `.wasm size > 1 MB` | Re-run with `--release`; debug builds are large |

### CI script (`./scripts/ci.sh`)

| Symptom | Fix |
|---------|-----|
| Stage 4 skipped | `LIBTORCH` unset — `source scripts/env.sh` then re-run |
| Stage 7 example failure | Run the failing example directly: `cargo run -p quantum-core --example <name>` to see real error |
| Stage 9 fails | `lean --run Standalone.lean` — should print "23 total" |
| Stage 10 skipped | `coqc` not installed |
| Stage 11 skipped | Not opt-in — set `QUANTUM_MATHLIB=1 ./scripts/ci.sh` |

---

## Adding tests

- Unit tests → `#[cfg(test)] mod tests` inside each source file
- Integration tests → `crates/<crate>/tests/`
- Single test: `cargo test -p quantum-core <test_name>`
- With output: `cargo test -- --nocapture`
- Lean test: add a `#guard` or `example : … := by …` line; CI stage 9 runs the file
- Rocq test: add a `Lemma/Theorem`; stage 10 will compile it

When adding a new example, append its name to the `EXAMPLES` array in
`scripts/ci.sh` (stage 7) so it runs in CI.
