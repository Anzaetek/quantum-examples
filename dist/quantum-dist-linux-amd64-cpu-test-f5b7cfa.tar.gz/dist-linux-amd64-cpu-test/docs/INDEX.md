# quantum dist (linux-amd64-cpu-test) — docs index

- [README.md](README.md) — toolkit overview
- [SERVER.md](SERVER.md) — quantum-server JSON protocol
- [TESTING.md](TESTING.md) — manual testing guide (numbers only)
- [gpu-acceleration.md](gpu-acceleration.md) — per-algorithm GPU verdicts
- [gpu-design.md](gpu-design.md) — GPU design decisions + MPS status
- [spec-extraction.md](spec-extraction.md) — Aria -> Lean spec extraction

Run `./run.sh` for a numeric end-to-end smoke test (server + CLI).
