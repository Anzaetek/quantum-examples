# GPU acceleration — algorithm-by-algorithm verdict

Decision matrix for which quantum-toolkit hot-paths benefit from GPU
offload, which backend to use on each platform, and the expected
speedup tier. Companion to TODO item 8.

`tch-rs` (libtorch) is already a project dependency, so CUDA and Apple
Metal Performance Shaders (MPS) are reachable today via
`Tensor::to(Device::Cuda(0))` / `Device::Mps`. **ROCm/AMD is out of
scope** (no ROCm libtorch arm, no HIP shim). OpenCL is reached by
*delegation* to omega-server, not an in-tree backend (see
"Delegate vs in-tree" below).

> **Measured (2026-05-30, RTX PRO 6000 Blackwell sm_120, libtorch
> 2.7.0/cu128, complex128).** Statevector forward-eval, two CUDA paths:
> - **tch reshape+matmul** (`--features cuda`): **6.4× @ n=22, 7.1× @ n=24**
>   over tch-CPU, rising with n but **below** the ≥10× tier — the per-gate
>   `movedim().contiguous()` permute-copies dominate.
> - **fused in-place kernels** (`--features cuda-fused`, cudarc+NVRTC
>   `double2`): **42× @ n=22, 46× @ n=24** over tch-CPU (and ~10× over the
>   tch-CUDA path), clearing the ≥10× tier. This is the path that earns the
>   "10–100× with fused kernels" tier below — **achieved with cudarc+NVRTC,
>   not cuStateVec** (which is not installed; the kernels are double-precision
>   ports of omega's `apply_1q.cu`/`apply_2q.cu`).
>
> CUDA cross-checks pass ≤1e-12 (tch) / ≤1e-10 (fused, vs reference *and* vs
> tch-CUDA); adjoint AD on CUDA ≤1e-8. OpenCL delegation verified: 4q-VQE
> distribution vs CPU reference TVD=0.017. Baselines: `docs/bench-baselines/`.
> **cu124 has no sm_120 kernels — cu128 (libtorch 2.7) is required on Blackwell.**

## Decision matrix

Columns: CUDA (in-tree tch / cuStateVec), Metal (MPS, tch), OpenCL
(**delegated** to omega-server), wgpu (future pure-Rust), ROCm (**out of
scope** — omitted). "measured" marks a verdict backed by a committed
baseline, not an estimate.

| Algorithm                               | CUDA        | Metal (MPS) | OpenCL    | wgpu       | Verdict                                        |
|-----------------------------------------|-------------|-------------|-----------|------------|------------------------------------------------|
| Statevector evolution                   | tch ✓6–7×; fused ✓42–46× | tch::Mps (n≤4) | delegate ✓ | shader | **Strong** — primary target. Crossover ≈ n=14. *measured.* |
| MPS contraction                         | cutensornet | tch::Mps    | (skip)    | (no)       | **Strong** for bond ≥ 64; CPU wins for ≤ 16.   |
| Pauli-string propagation (batched)      | tch batch   | tch::Mps    | (skip)    | (maybe)    | Medium — best as a Trotter-step batch.         |
| Stabilizer / Clifford (F₂ tableau)      | (skip)      | (skip)      | (skip)    | (skip)     | **Weak** until n ≥ 1000; not worth it now.     |
| Variational gradient sweeps             | tch batch   | tch::Mps    | (skip)    | (maybe)    | **Strong via batching** — top win for VQE/QAOA.|
| Photonic Fock-space evolution           | tch         | tch::Mps    | (skip)    | shader     | **Strong** (same shape as statevector).        |
| MWPM surface-code decoder               | cuDecoder*  | (no)        | (no)      | (no)       | Weak — sequential matching is GPU-hostile.     |
| PhasePoly F₂ Gaussian elim              | tch (raw)   | (skip)      | (skip)    | (maybe)    | Medium — only at gate counts ≥ 1000.           |
| ECC syndrome extraction (WASM guests)   | n/a         | n/a         | n/a       | n/a        | Use GPU only for *host-side* shot aggregation. |

\* cuDecoder is NVIDIA's GPU MWPM in cuQuantum; Rust binding is
non-trivial. Tracked as a future port.

## Per-algorithm notes

### Statevector evolution `|ψ⟩ → U|ψ⟩`

Dominant cost in `crates/quantum-core/src/backends/omega.rs::Statevector`.
Each gate is an in-place rank-2 update on `2^n` complex amplitudes —
embarrassingly parallel, `O(2^n)` work per gate. **Best GPU fit.**

- **NVIDIA, fused (shipped)**: `cudarc` + NVRTC runtime-compiled `double2`
  kernels that mutate the state in place — no per-gate copy. Modelled on
  omega's `apply_1q.cu`/`apply_2q.cu`. This is `--features cuda-fused`.
- **NVIDIA, cuStateVec (not used)**: cuQuantum's cuStateVec is also
  purpose-built, but it is not installed here and the cudarc+NVRTC path
  already clears the target, so no `cuquantum`/C++-shim dependency was taken.
- **Cross-platform**: `tch::Tensor` reshape + `einsum` — works on
  CUDA / MPS / CPU with one code path (`--features cuda`).
- **Pure-Rust portable**: `wgpu` compute shader (no Python; CUDA /
  Metal / Vulkan / DX12).

Expected speedup: 10–100× *with fused kernels*. **Measured (complex128,
Blackwell):** tch reshape+matmul **6.4× @ n=22, 7.1× @ n=24** (permute-copy
per gate caps it below the fused tier); fused in-place kernels **42× @ n=22,
46× @ n=24** (≥10× target cleared). Crossover is around `n = 14` (gate
dispatch cost dominates below).

### MPS contraction

`backends::mps` (in the omega path) does sequential SVDs + tensor
contractions. cuTENSOR / cutensornet are CUDA-only and purpose-built
for this; `tch::Tensor::svd` already routes to cuSOLVER on CUDA. **Strong
GPU fit** for bond dim ≥ 64. Below 16 the kernel-launch overhead loses
to vectorized CPU MKL/Accelerate.

### Pauli-string propagation

`optimizers::phase_poly` and `omega::PauliBackend` evolve sums of Pauli
strings. Each commutator and BCH-truncation is a sparse op, so per-
string GPU acceleration is limited; **batches** (Trotter steps in a
chemistry sim, or the simultaneous Pauli updates of a VQE energy
estimation) are amenable to GPU SIMD. Best path: encode each Trotter
step as a `tch::Tensor` of shape `[n_strings, n_qubits, 2]` and update
all strings at once.

### Stabilizer / Clifford simulation

Bit-matrix updates over `2n × 2n` tableaux. F₂ XOR-row operations help
on GPU only at very large `n` (≥ 1000+ qubits) where memory bandwidth
dominates. **De-prioritize** for typical sizes.

### Variational / gradient sweeps

`crates/quantum-qml/src/{simulator,gradients}.rs` parameter-shift
evaluates the same circuit at `2k` shifted parameter sets. **Strong GPU
fit via batching**: pack all `2k` circuits into a single batched
statevector evolution. This is where torch+CUDA earns the most for VQE
/ QAOA / QSVD work (item 5).

### Photonic Fock-space evolution

`backends::photonics` works in truncated Fock space — large dense
matrix-vector products on complex amplitudes. **Strong GPU fit**, same
shape as statevector with Fock cutoff replacing `2^n`.

### MWPM surface-code decoder

`crates/quantum-core/src/ecc/mwpm.rs` is graph matching. Blossom-style
matching has sequential dependencies that are *hard* to GPU. cuDecoder
(in cuQuantum, via PyMatching v3) is the only mature GPU implementation.
**Weak/medium GPU fit**; cite for completeness, capture as future work.

### PhasePoly F₂ Gaussian elimination

`optimizers::phase_poly::kernel_search_general` does Gaussian
elimination over GF(2). **Medium GPU fit** for very large gate counts
(≥ 1000); below that CPU wins on launch overhead.

### ECC syndrome extraction (WASM guests)

WASM guests can't see GPU directly. The host-side aggregation across
many shots IS GPU-batchable — wire that as a separate optimization
(currently CPU-bound in `omega_execute_shots`).

## Per-backend implementation notes

### CUDA path

Two paths. **(1) tch** via `Device::Cuda(0)` (the `cuda` feature; libtorch
2.7.0/cu128 on sm_120 Blackwell — cu124 lacks the kernels): measured 6–7×
over CPU; the per-gate permute-copies cap it below the 10× target. Linker
note: a `quantum-qml/build.rs` force-links `libtorch_cuda.so`
(`--no-as-needed`) so `Cuda::is_available()` is true. **(2) fused** (the
`cuda-fused` feature; `crates/quantum-qml/src/cuda_fused.rs`): cudarc + NVRTC
runtime-compiled `double2` `apply_1q`/`apply_2q` kernels that evolve the
state **in place** — no permute-copy. Measured **42–46×** over tch-CPU
(≥10× cleared), ~10× over the tch path; cross-checks the tch-CUDA path and
the ndarray reference to ≤1e-10. This is the route taken to ≥10×
(GPU_PLAN Phase 3.5) — chosen over cuStateVec because cuStateVec is not
installed and omega's own CUDA backend already proves the cudarc+NVRTC
approach, so no `cuquantum`/C++-shim dependency was needed. cudarc is
target-gated to Linux/Windows so the feature stays green on macOS.
**ROCm/AMD is out of scope.**

### Metal path

`tch-rs` `Device::Mps` works today on Apple Silicon. The dev box runs
darwin25, so this is the easiest target to validate locally. Accept
that no Apple-specific stabilizer or MWPM kernels exist; rely on
torch's matrix ops.

### OpenCL path — delegate, don't reimplement

OpenCL is **not** an in-tree backend and is **not** a shipped dist tarball.
We delegate: `quantum_qml::OmegaHttpExecutor` (the `omega-http` feature)
serializes the circuit to `OmegaCircuitIR` JSON and POSTs it to
`omega-server /v1/quantum/execute`; that server, built `--features opencl`
and run with `OMEGA_DEVICE=opencl`, routes Statevector through its mature,
hand-tuned `omega-backend-statevector-opencl` (the `ocl` crate). Verified
end-to-end on the NVIDIA OpenCL ICD: 4q-VQE distribution matches the CPU
statevector reference (TVD=0.017). The "OpenCL release" is just the
`linux-cpu` bundle plus an `OMEGA_SERVER_URL` pointer.

### Delegate vs in-tree tch

- **In-tree tch (`Device::Cpu`/`Mps`/`Cuda`)** — use for anything needing
  **gradients** (adjoint AD lives here) or tight CPU/GPU cross-checks, and
  for the common VQE/QAOA training loop. One code path, float64 on
  CPU/CUDA.
- **Delegate to omega-server (OpenCL, or remote QPUs later)** — use for
  one-shot *sampling* execution on hardware we don't bind in-tree
  (OpenCL devices, non-NVIDIA accelerators). No gradients over the wire;
  the JSON IR is the contract. Bring up omega's tuned kernels for free
  instead of re-porting them.

### wgpu path

If a future "no libtorch" mode is desired, `wgpu` compute shaders give
CUDA / Metal / Vulkan / DX12 portability — but reimplements primitives.
Stretch goal.

## End-to-end QASM → GPU → result

The full surface-syntax path: an OpenQASM 2.0 file is parsed to a `Circuit`,
lowered to the `OmegaCircuitIR`, then fanned out across **every backend present
at build/run time** and reduced to one comparison table. This is the
`crates/quantum-qml/examples/qasm_gpu_roundtrip.rs` example (GPU_PLAN Phase 7).

```text
  QASM 2.0 file
        │  from_qasm()                         (quantum_core::ast)
        ▼
     Circuit ──────── n_qubits, instructions
        │  to_omega_ir()                       (quantum_core::backends::omega)
        ▼
  OmegaCircuitIR (JSON-serializable)
        │
        ├──────────────────────┬───────────────────────┬─────────────────────┐
        ▼                      ▼                       ▼                     ▼
  in-tree tch            in-tree tch             omega delegate       cuStateVec shim
  Device::Cpu            Device::Mps/Cuda        (OpenCL via JSON)    (not installed)
  (float64 ref)          (metal / cuda feat)     (omega-http feat)    cuda-fused instead
        │                      │                       │                     │
  simulate_statevector_tensor()                  OmegaHttpExecutor      (documented note)
        │                      │                  .execute(ir, shots)        │
        └──────────────────────┴───────────────────────┴─────────────────────┘
                                       │
                                       ▼
                     per-bitstring probabilities / counts  →  one table
                                       │
                                       ▼
       numeric acceptance: cpu_prob_sum=1, Bell P(00)=P(11)=0.5,
       max_abs_diff_vs_cpu ≤ tol (1e-10 Cuda / 1e-4 Mps), remote_min_tvd ≤ 0.06
```

Cpu is always present and is the float64 reference; the other columns light up
only when their feature is built **and** the device/server is available, so the
same example runs unchanged on a laptop (Cpu, or Cpu+Mps under `--features
metal`) and on the Linux/CUDA box (`--features cuda`, plus `--remote` for the
OpenCL delegate). cuStateVec is not installed — the in-house `cuda-fused`
double-precision NVRTC kernel already clears the ≥10× target (see below). Wired
into `ci.sh` stage 4 (Bell default, Cpu) and exercised on Mps locally.

## Implementation status

- ✅ **Decision matrix** (this doc).
- ✅ **CPU baseline benchmark scaffolding**:
  `crates/quantum-core/benches/statevector.rs` runs statevector
  evolution for `n ∈ {12, 14, 16, 18}` on CPU. The `compile-only`
  CI check (`cargo bench --no-run`) verifies it builds; full runs
  are operator-driven via `cargo bench -p quantum-core --bench
  statevector`.
- ✅ **Device-aware tch statevector**: `quantum-qml::TensorState` +
  `simulate_statevector_tensor(circuit, params, SimDevice)` (GPU_PLAN
  Phase 1). CPU forward baseline n ∈ {12..22} committed
  (`docs/bench-baselines/tensor-forward-arm64-darwin-m4.json`).
- ⚠️ **Metal (MPS) verdict (measured 2026-05-30, M4 / libtorch 2.4.0)**:
  MPS has **no float64** (use ComplexFloat) and the **complex-on-MPS path
  aborts at n ≥ 6** (`MPSNDArray buffer` Metal assertion). MPS is
  correctness-validated only at **n ≤ 4**. A scaled MPS path needs the
  **interleaved-real float32** rework — deferred, because Metal loses to
  CPU below n≈16 anyway (omega data). So the original "MPS trivial
  drop-in" expectation was **wrong**: it is not a drop-in. See
  `docs/gpu-design.md` §4b.
- ✅ **CUDA (measured 2026-05-30, Blackwell sm_120 / libtorch 2.7.0/cu128)**:
  `cuda` feature wires `SimDevice::Cuda → Device::Cuda(0)`, ComplexDouble,
  cross-checks ≤1e-12, adjoint AD ≤1e-8 (`ci.sh` stage 4c). Forward-eval
  **6.4× @ n=22, 7.1× @ n=24** vs CPU (`docs/bench-baselines/
  statevector-linux-cuda.json`); below the ≥10× target. cu124 retired (no
  sm_120 kernels).
- ✅ **OpenCL (measured 2026-05-30, via omega-server delegation)**:
  `OmegaHttpExecutor` (`omega-http` feature) + `tests/opencl_delegate.rs`.
  4q-VQE distribution vs CPU reference **TVD=0.017**; `ci.sh` stage 4d
  (opt-in via `OMEGA_SERVER_URL`). Not an in-tree backend, not a dist
  tarball.
- ✅ **Fused CUDA fast path (measured 2026-05-30, Blackwell sm_120)**:
  `cuda-fused` feature (`cuda_fused.rs`) — cudarc + NVRTC in-place `double2`
  kernels. Forward-eval **42× @ n=22, 46× @ n=24** vs tch-CPU (~10× vs the
  tch-CUDA path), **≥10× target cleared**; cross-checks the reference and the
  tch-CUDA path ≤1e-10 (`ci.sh` stage 4c, `--features "cuda cuda-fused"`).
  Baseline `docs/bench-baselines/statevector-linux-cuda-fused.json`. Chosen
  over cuStateVec (not installed; cudarc+NVRTC already clears the target).
- ✅ **End-to-end QASM → GPU roundtrip (GPU_PLAN Phase 7)**:
  `crates/quantum-qml/examples/qasm_gpu_roundtrip.rs` + Aria mirror
  `examples/aria/qasm_gpu.aria`. Parses a QASM file (default: Bell), runs it
  through the in-tree tch sim on every available device + the OpenCL delegate,
  prints one comparison table, and self-verifies numerically. `ci.sh` stage 4
  runs the Bell default on Cpu (`cpu_prob_sum=1`, `bell_p00=bell_p11=0.5`,
  `ROUNDTRIP OK`); Cpu+Mps cross-check ≤1e-8 locally on M4.

## Reading list

- NVIDIA cuQuantum SDK (cuStateVec, cutensornet, cuDecoder).
- `tch-rs` device-management docs:
  https://github.com/LaurentMazare/tch-rs/blob/main/src/wrappers/device.rs
- PyMatching v3 GPU MWPM.
- Childs, Kothari, Somma — "Quantum algorithm for systems of linear
  equations with exponentially improved dependence on precision"
  (arXiv:1511.02306) — the QSVT-degree heuristic in
  `linalg::solver::quantum_solve_circuit` cites this paper.
