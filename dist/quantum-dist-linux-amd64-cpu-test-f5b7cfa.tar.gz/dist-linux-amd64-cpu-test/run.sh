#!/usr/bin/env bash
# End-to-end NUMERIC smoke for the binary-only dist. No GUI, numbers only.
# Starts quantum-server, pings it, and checks `quantum info` statistics on
# the bundled Bell circuit against known-exact values.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOCK="$(mktemp -u /tmp/quantum-dist-XXXXXX.sock)"
fail() { echo "RUN FAIL: $1" >&2; exit 1; }

# 1. Server starts + responds to ping (pong carries the build unix time).
"$HERE/bin/quantum-server" --listen "unix:$SOCK" &
SRV=$!
trap 'kill $SRV 2>/dev/null || true; rm -f "$SOCK"' EXIT
for _ in $(seq 1 50); do [ -S "$SOCK" ] && break; sleep 0.1; done
[ -S "$SOCK" ] || fail "server socket not created"
# The shipped quantum-client binary speaks the length-prefixed JSON-RPC natively —
# no python/jq/nc on the host (clients/client.sh is an optional shell fallback).
PONG="$("$HERE/bin/quantum-client" --socket "unix:$SOCK" ping 2>/dev/null || true)"
echo "ping -> $PONG"
echo "$PONG" | grep -q 'pong' || fail "server did not pong"

# 2. CLI info on the Bell circuit — exact deterministic statistics.
INFO="$("$HERE/bin/quantum" info "$HERE/examples/bell.qasm")"
echo "$INFO"
QUBITS="$(echo "$INFO" | awk '/Qubits:/ {print $2}')"
HCOUNT="$(echo "$INFO" | awk '/H-count:/ {print $2}')"
[ "$QUBITS" = "2" ] || fail "expected Qubits=2, got $QUBITS"
[ "$HCOUNT" = "1" ] || fail "expected H-count=1, got $HCOUNT"

# 2b. Quantum Oracle Sketching through the stripped CLI — the scaling-QML work
# ships in the libtorch-free binary. Checks the O(1/N^2) sample-complexity law.
# Small dim (6 index qubits) so the smoke also passes under a capped dist-test.
QOS="$("$HERE/bin/quantum" qos --dim 64)"
echo "$QOS" | grep -E '^(n_qubits|error_ratio_2x|block_encoding_err) '
echo "$QOS" | grep -q "^n_qubits 6$"             || fail "qos n_qubits"
echo "$QOS" | grep -q "^error_ratio_2x 3.9999$"  || fail "qos O(1/N^2) law"
echo "$QOS" | grep -q "^block_encoding_err 0.00e0$" || fail "qos block-encoding"

# 3. Finance CLI (libtorch-linked) — SYNTHETIC backtest numeric anchor, when the
# binary is bundled AND a paired libtorch is loadable. Degrades to a skip
# (never a failure) so the core dist verifies without libtorch on the path.
if [ -x "$HERE/bin/quantum-finance" ]; then
    FIN="$(QF_BIN="$HERE/bin/quantum-finance" DATA_DIR="$HERE/examples/data" \
        bash "$HERE/examples/finance/run_backtest.sh" 2>/dev/null || true)"
    if echo "$FIN" | grep -q "FIN OK: backtest"; then
        echo "finance: synthetic backtest anchor OK"
    else
        echo "finance: skipped (quantum-finance present, libtorch not on path)"
    fi
fi

echo "RUN OK: server pong + Bell info (Qubits=2, H-count=1) + QOS O(1/N^2) verified numerically"
