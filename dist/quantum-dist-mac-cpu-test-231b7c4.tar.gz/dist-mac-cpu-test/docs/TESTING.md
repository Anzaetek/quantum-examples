# Testing & Development Guide

> **Audience.** This guide is written for AI coding agents and human
> engineers who need to bring a fresh machine to a green `./scripts/ci.sh`.
> Every step is a copy-pasteable shell block followed by a one-line
> verification. If a verification command returns non-zero, do **not**
> proceed — jump to [Troubleshooting](#troubleshooting).

> **Working rules (see `CLAUDE.md`).** This is the **manual testing
> manual**, and these rules are binding:
> - **No GUI. Numbers only.** Every step ends in a **numeric** check —
>   counts, expectations, probabilities, eigenvalues, parity deltas —
>   compared to a golden value within a stated tolerance. A step with no
>   numeric assertion does not belong here.
> - **CI is local** (`./scripts/ci.sh`) — **no GitHub / no CI service.**
> - **Commit often, never push.**
> - **The manual MUST be run against the binary-only dist artefact**
>   (§10.2) — not just `cargo run`. The point is to prove the *shipped
>   stripped binaries* produce the right numbers.
> - **After each build phase, run this manual end-to-end in a subagent**
>   and iterate until green. A failure means the *code* is wrong **or
>   this *doc* is wrong** — fix whichever is actually wrong and keep the
>   manual truthful.

## Contents

1. [Dependency matrix — which deps for which task](#1-dependency-matrix)
2. [One-shot bootstrap (the fast path)](#2-one-shot-bootstrap)
3. [Detailed install per OS](#3-detailed-install-per-os)
   - [macOS (Apple Silicon + Intel)](#31-macos-apple-silicon--intel)
   - [Ubuntu / Debian](#32-ubuntu--debian)
   - [Fedora / RHEL / Rocky](#33-fedora--rhel--rocky)
   - [Arch / Manjaro](#34-arch--manjaro)
4. [Verify install (one-line checks)](#4-verify-install)
5. [Test suites](#5-test-suites)
6. [CI pipeline (`./scripts/ci.sh`)](#6-ci-pipeline-scriptscish)
7. [Examples, benchmarks, WASM guests](#7-examples-benchmarks-wasm-guests)
8. [Formal proofs (Lean4 + Rocq)](#8-formal-proofs)
9. [Python wheel (PyO3 / maturin)](#9-python-wheel-pyo3--maturin)
10. [Release packaging](#10-release-packaging)
11. [Troubleshooting](#troubleshooting)

---

## 0. Guided demos (fast, self-verifying)

The quickest numeric end-to-end check is the two guided demo scripts — each step
prints a headline number and asserts it against a golden value (no GUI), then
exits non-zero on any mismatch. See [`docs/DEMO.md`](docs/DEMO.md) for the
narrated walkthrough.

```bash
source scripts/env.sh          # libtorch on path
./scripts/demo.sh              # breadth tour — expect "demo complete — 7/7 steps verified" (7 ✓ checks over 6 numbered sections)
./scripts/demo-finance.sh      # SYNTHETIC (rescaled+noised) XAUUSD-shaped daily series, see demo/data/README.md — expect "5/5 steps verified"
```

| Script | Pass line |
|---|---|
| `scripts/demo.sh` | `=== demo complete — 7/7 steps verified numerically ===` |
| `scripts/demo-finance.sh` | `=== finance demo complete — 5/5 steps verified numerically ===` |

These are a superset-narrative over the per-suite checks in §5 and the dist smoke
in §10; they are the recommended first thing to run on a fresh machine after §4.

---

## 1. Dependency matrix

| Task | Rust | libtorch | Python venv | Lean+mathlib | Rocq | WASM target | Node |
|------|:----:|:--------:|:-----------:|:------------:|:----:|:-----------:|:----:|
| `cargo test -p quantum-core` | ✅ | — | — | — | — | — | — |
| `cargo test -p quantum-macros` | ✅ | — | — | — | — | — | — |
| `cargo test -p quantum-qml` | ✅ | ✅ | — | — | — | — | — |
| `cargo build -p quantum-py` (link) | ✅ | ✅ | — | — | — | — | — |
| `maturin develop / build` (wheel) | ✅ | ✅ | ✅ | — | — | — | — |
| Lean4 standalone (stage 9, 23 thms) | — | — | — | Lean only | — | — | — |
| Lean4 mathlib (stage 11, opt-in) | — | — | — | ✅ + cache | — | — | — |
| Rocq stage 10 | — | — | — | — | ✅ | — | — |
| WASM guests (vqe / qaoa / ecc) | ✅ | — | — | — | — | ✅ | — |
| Editor-plugin smoke (stage 7d JS) | — | — | python3 | — | — | — | ✅ |
| Full `./scripts/ci.sh` | ✅ | ✅ | ✅ | ✅ + cache | ✅ | ✅ | ✅ |

**Minimum versions (verified in CI):**

| Tool | Pinned/expected version |
|------|-------------------------|
| Rust | 1.75+ (stable) — local dev tracks current stable (1.97.1 verified 2026-08-29). After every stable bump re-add `wasm32-wasip1` to the *active* toolchain (§2 step 1) |
| libtorch | **2.7.0** (`scripts/setup-libtorch.sh` downloads this exact version; matches tch 0.20. CUDA variant is cu128 for sm_120/Blackwell) |
| Python | ≥ 3.8 for the wheel; ≥ 3.10 for full dev loop |
| Lean | `leanprover/lean4:v4.29.0` (pinned in `proofs/lean4/lean-toolchain`) |
| Rocq | 9.1.x (the `QLibCompat.v` shim does not need `coq-quantumlib`) |
| Node | any LTS — only used to `node --check` the tree-sitter `grammar.js` |
| WASM target | `wasm32-wasip1` (added via `rustup target add`) |

---

## 2. One-shot bootstrap

If `rustup`, a system Python ≥ 3.10, `curl`, `unzip`, and `git` are
already present, this brings a fresh checkout to green:

```bash
# 0. Clone (skip if you already have the repo)
git clone <repo-url> quantum && cd quantum

# 1. Rust toolchain + WASM target
rustup update stable
rustup target add wasm32-wasip1

# 2. libtorch 2.7.0 (cpu) — drops it at ./libtorch/
./scripts/setup-libtorch.sh                 # macOS / Linux CPU
# Linux + CUDA 12.8 (Blackwell): ./scripts/setup-libtorch.sh cu128

# 3. Source env (LIBTORCH + {DY,}LD_LIBRARY_PATH)
source scripts/env.sh

# 4. Lean toolchain (elan installs Lean per lean-toolchain pin)
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh -s -- -y --default-toolchain none
source "$HOME/.elan/env"

# 5. Mathlib precompiled oleans (~500 MB download, NO local rebuild)
#    Idempotent: re-runs are no-ops once the cache marker exists.
./scripts/setup-mathlib.sh

# 6. (Optional) Rocq for stage 10 — see per-OS section if not installed
#    macOS: brew install rocq-prover         (or opam install rocq-prover)
#    Linux: see §3.2 / §3.3 / §3.4

# 7. (Optional) Node for stage 7d editor-plugin smoke
#    macOS: brew install node          Linux: see per-OS section

# 8. Run the whole pipeline
./scripts/ci.sh
# Add QUANTUM_MATHLIB=1 ./scripts/ci.sh to also build mathlib-backed proofs
```

Expected last line: `=== CI completed in <N>s ===`.

---

## 3. Detailed install per OS

### 3.1 macOS (Apple Silicon + Intel)

> Tested on macOS 14+ (`Darwin 25.x`). Apple Silicon uses CPU libtorch
> (Metal goes through `tch::Device::Mps` — no separate libtorch download).

**Required: Xcode Command Line Tools** (compiler + `git` + `curl` + `unzip`):

```bash
xcode-select --install            # one-time; opens GUI if missing
# Verify:
xcode-select -p && cc --version | head -1
```

**Homebrew** (recommended — used by several optional deps):

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
# Verify:
brew --version
```

**Rust:**

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source "$HOME/.cargo/env"
rustup update stable
rustup target add wasm32-wasip1
# Verify:
rustc --version && cargo --version
rustup target list --installed | grep wasm32-wasip1
```

**libtorch 2.7.0** (auto-detects arm64 vs x86_64):

```bash
cd /path/to/quantum
./scripts/setup-libtorch.sh
source scripts/env.sh
# Verify:
ls "$LIBTORCH/lib/libtorch_cpu."*   # should list .dylib
echo "$DYLD_LIBRARY_PATH" | grep -q libtorch && echo "DYLD ok"
```

**Python venv** (per project convention — never system Python):

```bash
python3 -m venv .venv
source .venv/bin/activate
unset CONDA_PREFIX                  # if conda is active, maturin refuses
pip install --upgrade pip maturin
# Verify:
python3 --version && maturin --version
```

**Lean + elan + mathlib precompiled oleans:**

```bash
# elan installs Lean per project's lean-toolchain pin (4.29.0)
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh \
    | sh -s -- -y --default-toolchain none
source "$HOME/.elan/env"
# Trigger toolchain download by entering the proof dir (elan reads lean-toolchain):
(cd proofs/lean4 && lean --version)
# Precompiled mathlib oleans — NO local rebuild (~30 min saved).
# The script calls `lake exe cache get` which pulls .oleans from
# mathlib's Azure blob cache.
./scripts/setup-mathlib.sh
# Verify:
ls proofs/lean4/.lake/packages/mathlib/.lake/build/lib/lean/Mathlib.olean
# Warm-cache re-run must be an OFFLINE no-op: the script checks content
# (olean tree complete, lakefile `@ "<tag>"` == manifest inputRev, EVERY
# .lake/packages/<pkg> HEAD == its lake-manifest.json rev, toolchain
# match) — not mtimes — and must not call `lake update`.
# Expect exactly 1 / 0 / 0:
./scripts/setup-mathlib.sh 2>&1 | grep -c 'mathlib cache up to date'   # 1
./scripts/setup-mathlib.sh >/dev/null 2>&1; echo $?                      # 0
./scripts/setup-mathlib.sh 2>&1 | grep -c 'Resolving mathlib pin'       # 0
# Pin consistency the script relies on (both print the same 40-hex rev):
(cd proofs/lean4 && git -C .lake/packages/mathlib rev-parse HEAD)
./scripts/setup-mathlib.sh --print-pin
# `--check` runs ONLY the offline content check (never `lake update`).
# Warm cache: rc 0, no stale line. Expect 0 / 0:
./scripts/setup-mathlib.sh --check >/dev/null 2>&1; echo $?                       # 0
./scripts/setup-mathlib.sh --check 2>&1 >/dev/null | grep -c 'cache stale:'       # 0
# Negative check — drift the lakefile pin, the check must REFUSE and name
# the reason (this is what would otherwise trigger a network `lake update`).
# Expect 1 / 1, then the restore leaves git clean (0):
sed -i.bak 's/@ "v4\.29\.0"/@ "v9.99.9"/' proofs/lean4/lakefile.lean
./scripts/setup-mathlib.sh --check >/dev/null 2>&1; echo $?                       # 1
./scripts/setup-mathlib.sh --check 2>&1 >/dev/null | grep -c 'cache stale: lakefile.lean pins mathlib @ "v9.99.9"'   # 1
mv proofs/lean4/lakefile.lean.bak proofs/lean4/lakefile.lean
git status --porcelain proofs/lean4/lakefile.lean | wc -l | tr -d ' '            # 0
```

**Rocq 9.1.x** (only needed for stage 10):

```bash
brew install rocq-prover            # ships coqc + dune
# Verify:
coqc --version | head -1            # → "The Rocq Prover, version 9.1.x"
```

**Node** (only needed for stage 7d editor-plugin smoke):

```bash
brew install node
# Verify:
node --version                      # any LTS works
```

---

### 3.2 Ubuntu / Debian

> Tested on Ubuntu 22.04 LTS, Ubuntu 24.04 LTS + Debian 12.

**System tooling:**

```bash
sudo apt update
sudo apt install -y build-essential pkg-config libssl-dev curl unzip git \
                    python3 python3-venv python3-pip
# Verify:
cc --version | head -1 && curl --version | head -1
```

**Rust:**

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source "$HOME/.cargo/env"
rustup update stable
rustup target add wasm32-wasip1
# Verify:
rustc --version && rustup target list --installed | grep wasm32-wasip1
```

**libtorch 2.7.0:**

```bash
cd /path/to/quantum
./scripts/setup-libtorch.sh           # CPU
# CUDA 12.8 build (Blackwell sm_120): ./scripts/setup-libtorch.sh cu128
#   (needs an NVIDIA driver ≥550 and CUDA 12.8 runtime; the libtorch zip
#    ships its own CUDA libs, but the driver must match. cu124 is retired —
#    it lacks sm_120 kernels and aborts ATen ops on Blackwell GPUs.)
source scripts/env.sh
# Verify:
ls "$LIBTORCH/lib/libtorch_cpu."*     # .so on Linux
echo "$LD_LIBRARY_PATH" | grep -q libtorch && echo "LD ok"
```

**Python venv:**

```bash
python3 -m venv .venv
source .venv/bin/activate
unset CONDA_PREFIX
pip install --upgrade pip maturin
# Verify:
python3 --version && maturin --version
```

**Lean + elan + mathlib oleans:**

```bash
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh \
    | sh -s -- -y --default-toolchain none
source "$HOME/.elan/env"
(cd proofs/lean4 && lean --version)
./scripts/setup-mathlib.sh            # downloads precompiled oleans
# Verify:
ls proofs/lean4/.lake/packages/mathlib/.lake/build/lib/lean/Mathlib.olean
```

**Rocq 9.1.x** — Ubuntu's `coq` is older than 9.1; use opam:

```bash
sudo apt install -y opam
opam init --bare --disable-sandboxing -y
opam switch create rocq-9.1 --packages=ocaml-base-compiler.5.1.1
eval "$(opam env)"
opam install -y rocq-prover.9.1.1
# Verify:
coqc --version | head -1
```

**Node** (for stage 7d):

```bash
# NodeSource LTS — replace 20.x with current LTS if needed
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt install -y nodejs
# Verify:
node --version
```

---

### 3.3 Fedora / RHEL / Rocky

```bash
sudo dnf install -y gcc gcc-c++ pkgconf openssl-devel curl unzip git \
                    python3 python3-virtualenv python3-pip
# Rust — same rustup one-liner as §3.2
# libtorch — same ./scripts/setup-libtorch.sh as §3.2 (it auto-detects Linux)
# Python venv — same as §3.2
# Lean — same elan one-liner as §3.2
# Rocq — opam path (same as §3.2; replace `apt install opam` with `dnf install opam`)
# Node — sudo dnf install -y nodejs   (or NodeSource RPM repo for LTS)
```

---

### 3.4 Arch / Manjaro

```bash
sudo pacman -Syu --needed base-devel pkgconf openssl curl unzip git \
                          python python-virtualenv python-pip nodejs
# Rust:        pacman -S rustup && rustup default stable
# libtorch:    ./scripts/setup-libtorch.sh
# Python venv: python -m venv .venv && source .venv/bin/activate
# Lean:        elan one-liner from §3.2
# Rocq:        sudo pacman -S rocq-prover  (or opam if outdated)
```

---

## 4. Verify install

Run these **after** completing §3 for your OS. Every command should
print a version or path; non-zero exit means something is missing.

```bash
# Rust toolchain
rustc --version                       # → rustc 1.x
cargo --version
rustup target list --installed | grep -q wasm32-wasip1 && echo "wasm32-wasip1 ok"

# libtorch + env
source scripts/env.sh                 # idempotent — exports LIBTORCH
test -f "$LIBTORCH/lib/libtorch_cpu.dylib" || \
test -f "$LIBTORCH/lib/libtorch_cpu.so" && echo "libtorch ok"

# Python + maturin — OPTIONAL: only §5.3 / §9 (the PyO3 wheel) need these, and
# maturin lives in the venv from §2/§3, never in system Python. Everything
# else in this manual runs without them.
python3 --version
(. .venv/bin/activate 2>/dev/null && maturin --version) || \
    echo "maturin absent — §5.3 and §9 will be skipped"

# Lean
lean --version                        # any 4.x; toolchain auto-switches in proofs/lean4
lake --version
test -f proofs/lean4/.lake/packages/mathlib/.lake/build/lib/lean/Mathlib.olean && echo "mathlib oleans ok"

# Rocq
coqc --version | head -1              # Rocq Prover 9.1.x

# Node (for editor-plugin JSON/JS smoke)
node --version

# Final sanity: compile the workspace without running tests
cargo check --workspace
```

Expected: `cargo check --workspace` finishes with ``Finished `dev` profile [unoptimized + debuginfo] target(s) in …`` (cargo ≥ 1.97 backticks the profile name — check for `Finished` and `profile` on the same line, not the literal `Finished dev profile`).

---

## 5. Test suites

### 5.1 quantum-core (no external deps)

```bash
cargo test -p quantum-core
```

| Module | Tests | What's covered |
|--------|-------|----------------|
| `ast::nodes` | 8 | Circuit construction, gate properties, composition, pipe, tensor, repeat, inverse, operators |
| `ast::builder` | 3 | Fluent builder API, bell/ghz/qft |
| `ast::qasm` | 2 | QASM 2.0 roundtrip, parametric gates |
| `ast::expr` | 6 | ParamExpr concrete/symbol/pi/arithmetic/fn_call/display |
| `ast::annotation` | 3 | Annotation display, resource bounds, probability |
| `ast::json` | 2 | JSON roundtrip, annotations serialization |
| `ast::opticqasm` | 2 | OPTICQASM roundtrip, Clements mesh parsing |
| `ast::export_lean` | 2 | Bell+unitary to Lean4, QFT+prove to Lean4 |
| `ast::export_rocq` | 2 | Bell+unitary to Rocq, Grover+prove to Rocq |
| `circuits::standard` | 3 | bell(), ghz(), qft_circuit() |
| `circuits::trotter` | 3 | H₂ Trotter, second order, Ising Hamiltonian |
| `circuits::photonic` | 3 | Clements mesh 4/6, Mach-Zehnder |
| `circuits::modules` | 3 | Registry, instantiate, custom module |
| `circuits::encoding` | 4 | Angle encoding, IQP, hardware-efficient ansatz, QML circuit |
| `circuits::lcu` | 3 | LCU 2-term, 4-term, 1-norm |
| `circuits::qsvt` | 4 | QSVT circuit, sign angles, inversion angles, resources |
| `optimizers::passes` | 5 | Identity removal, gate cancellation, rotation merging |
| `optimizers::pipeline` | 1 | Default pipeline convergence |
| `optimizers::commutation` | 2 | Disjoint qubit, Z-diagonal commutation |
| `optimizers::decomposition` | 4 | SWAP→3CX, CZ→H-CX-H, CCX→15 gates |
| `optimizers::tcount` | 5 | T-merge (T²=S), commuting Cliffords, H-blocked, t_count |
| `optimizers::clifford_t` | 4 | .qc roundtrip + **refusal of non-Clifford+T**, CliffordT optimizer, Toffoli export |
| `optimizers::h_opt` | 3 | H-Z-H→X, H-X-H→Z, no-pattern |
| `optimizers::equivalence_fuzz` | 3 | every pass vs the statevector on 60 random circuits × 2 input states, plus per-pass coverage. **Gated on `omega-sim`; ran in CI for the first time 2026-08-14** — no stage had enabled that feature for it. Mutation-scored 9/9 by `scripts/mutation-battery.py` (9 mutations across 6 of the passes). Covers all **thirteen** passes plus the composed `default_pipeline` — incl. the §17 paper passes `FastTMerge` / `BBMerge` / `InternalHOpt` / `FastTODD` since 2026-09-11: before that they were not in the fuzz and their front-end refused every fuzz circuit (one conditioned gate each), so `InternalHOpt` transformed **0/60** and the coverage assertion went red. Fixed by `optimizers::map_unitary_segments` (conditioned / `Measure` / `Reset` / `Barrier` are hard boundaries; the pass runs per unitary run). Coverage now InternalHOpt 60, FastTMerge 59, BBMerge 59, FastTODD 60 of 60; case (5) of `conditional_gates_are_opaque_to_every_pass` pins `T; if(c) T; T` (conditioned T survives, no merge across it, state Δ < 1e-9) |
| `optimizers::tket` | 1 | Tket2 fallback to default pipeline |
| `backends::omega` | 2+ | Circuit→OmegaCircuitIR, parametric gates, conditional-gate bridge |
| `backends::ffi` | 2 | Circuit→FfiGateOp, repr(C) layout |
| `ecc::codes` (surface) | 1 | Surface code [[9,1,3]] properties + syndrome |
| `ecc::codes` (other) | 2 | Repetition code, Steane code |
| `ecc::mwpm` | 7 | Decoder: clean, boundary, direct pairing, d=5 fallback, Correction variants |
| `hdl::fpga_meta` | 3 | pseudo-IR parse, Lean4 spec extract, fpga-meta-compiler import |
| Macro tests (`circuit!`) | 4 | Bell, GHZ, parametric, Toffoli via proc-macro |
| Symbolic tests | 5 | Symbolic build, bind_params, unbound error, QASM, JSON roundtrip |
| `timebomb` | 1 | Build-time expiry (Active / Disabled path) |
| `server_smoke` | 5 | omega-server `/v1/quantum/execute` JSON IR dispatch smoke |
| `aria_examples` | 5 (6 with `omega-sim`) | **every `examples/aria/*.aria` (39) parses + instantiates** + a coverage guard (no file skips the gate) — incl. MBQC ghz/grover3/qft4/rotations/u3/clifford_opt (item 11 A1/A2/A4); + **`teleport.aria` → `circuit_to_pattern`** compiles end-to-end to 1 terminal output byproduct (X←m1, Z←m0 on Bob); + **`mbqc_feedforward.aria`** → 1 *internal* `x_corr_from` flow edge, fires-iff-source-1 ≤1e-12 over 48 seeds (A1.5 both conditional paths) |
| Integration tests | 6 | Build→optimize→export, decompose+optimize, QFT-iQFT, ECC, QASM, pipeline |
| `ubqc_net` | 2 | UBQC client↔server round-trip over the network layer (`tests/ubqc_net.rs`) |

Total (verified 2026-09-24, Linux): **700** lib with `--features omega-sim`, **617** without (was 649/566 on 2026-09-04, 646/563 on 2026-09-03, 610/541 on 2026-08-29, 561/507 on 2026-08-15). That 83-test difference is feature-gated, and 27 of them (all of `logical::run`, `logical::algo`, `logical::precision`, `logical::star`) ran in **no** CI stage until 2026-08-14 — ci.sh stage 2 now runs the whole lib under the feature rather than an `ecc::` / `logical::transversal` slice. (+ 6 integration + 7 macro + 5
symbolic + 5 server_smoke + aria_examples 6 under `omega-sim` / 5 without + 2
ubqc_net + 1 doctest — 32 / 31 outside the lib, so 732 / 648 all-in; MBQC A0 gflow +
A1/A2 + A3 resource estimator incl. A3.3 `compare_resource` + **B1 UBQC
typed state machine** + **B2 real UBQC server register** (`process_message`,
`plus_prob = cos²((θ−δ)/2)` ≤1e-12, BFK blind-but-correct single-qubit
recovery) + **B3 `Pattern::brickwork`** (linear-cluster + 2×9 structure +
gflow determinism + unit-norm simulate) + **gflow byproduct correction**
(`simulate_pattern_sampled` + `apply_gflow_correction`: random run +
correction == canonical +branch ≤1e-9 over 16 seeds × {line,Bell,GHZ})
+ **A2 `Pattern::optimize`** — Clifford pattern simplification, all
channel-preserving ≤1e-9: `canonicalize_edges` (`CZ²=I` 2 edges → 0) +
**A2.3 `eliminate_y_vertices`** (Pauli-Y local complementation; S-gadget drops
a vertex) + **A2.3 `eliminate_x_pivots`** (Pauli-X pivot; `H·H` wire collapses,
2 vertices/pivot) + `parallelize` (gflow depth: 2 rounds → 1)
+ **A2.1 `reduce_corrections`** (byproduct parity-reduction `X²=Z²=I`:
`x_corr_from=[0,0,0]→[0]`, `z_corr_from=[0,0]→[]`; channel-preserving —
identical sampled trajectory + branch probability ≤1e-12 over 32 seeds, and
**channel-identical at the `output_density_matrix` ρ level**)
+ **A2.1 `shift_signals`** (Danos–Kashefi `[S]`: forward-propagates a measurement
Z-dependency `s_i↦s_i⊕s_j` off the angle, then ρ is invariant ≤1e-12 via the
`output_density_matrix` oracle — exact channel over all branches; oracle itself
validated against the known graph state ½(|00⟩+|01⟩+|10⟩−|11⟩), trace=1, Hermitian)
+ **A1.5 conditional Pauli** (`circuit_to_pattern` lowers `when (c,1){X|Z q}`
to a byproduct link sourced from the bound `Measure q'->c` outcome; the
correction fires iff that outcome is 1 — matches off/hard-applied baselines
≤1e-12 over 48 seeds; non-Pauli / value≠1 rejected) + **A1.5 output byproduct**
(terminal-output target → `Pattern::output_corr`; `apply_output_correction`
applies X/Z iff source outcome 1, ≤1e-12 over 48 seeds, X and Z).
Acceptance: a 3-qubit Clifford circuit optimizes with **≥30% vertex reduction**
+ gflow preserved + **B4 `verify_traps`** (FK '17 verifiable UBQC: honest server
passes 8 traps deterministically, wrong-basis/flipped outcome detected),
finance_lab Phase 0, data-reuploading, all 39 .aria files parse-validated).
(The per-module rows above are indicative;
the runner totals are authoritative — re-run `cargo test -p quantum-core`.)

### 5.2 quantum-qml (requires libtorch)

```bash
source scripts/env.sh
cargo test -p quantum-qml -- --test-threads=1   # see note
```

> **Run qml tests single-threaded.** tch/libtorch uses one **global** RNG;
> running the RNG-seeded tests in parallel lets sibling tests race the
> generator, making seeded tests non-deterministic. `ci.sh` stage 4 already
> passes `--test-threads=1`. (Also: `ci.sh` re-exports `DYLD_LIBRARY_PATH`
> internally because macOS SIP strips it across the script's exec — so
> `./scripts/ci.sh` works even when your shell had it set.)

| Module | Tests | What's covered |
|--------|-------|----------------|
| `simulator` | 11 | H, Bell, X, parametric RX, expectation Z, mid-circuit measure/reset, **+ Phase-0 `SimConfig` default-is-Cpu + simulate_with_config parity** |
| `layers` | 5 | Forward pass, autograd gradient, train step, Phase-5 adjoint==parameter-shift ≤1e-6, **+ Phase-0.7 Readout (Probs sums to 1, ExpvalZZ in [-1,1])** |
| `cmaes` | 2 | Sphere convergence, Rosenbrock |
| `gradients` | 5 | Parameter-shift vs analytic, omega bridge (×2), **+ Phase-6 batched-vs-sequential parameter-shift ≤1e-10 (single + 8-param ansatz)** |
| `adjoint` | 2 | **GPU_PLAN Phase 5** — adjoint AD == analytic & == parameter-shift ≤1e-8 (3q/8-param ansatz, all observables) |
| `noise` | 4 | Bit-flip p0/p1, none, phase-flip Z |
| `surrogate` | 3 | SurrogateModel creation, SurrogateTrainer sampling |
| `tensor_sim` | 11 | **GPU_PLAN Phase 1** — tch device-aware statevector: H, Bell/GHZ/mixed cross-check vs ndarray ≤1e-10, X, RX(π), ⟨Z⟩, measure 0/1, reset, measure-reset-continue |
| `tests/pennylane_compat` | 5 | **finance_lab Phase 0** parity — amplitude_embedding ≤1e-12 (up to global phase), rot_zyz analytic, angle axis, probs marginals |
| `tests/papers` | 13 | **item 12** gate-model track COMPLETE (all 8 gate-model-origin papers) — qSSL (⟨Z⟩=cos(x)+trainable), QCNN classifier, HQNN hybrid sandwich, nn_embedding (class separation), QRKD (relational distillation), adversarial (FGSM optimal first-order attack), **QLSTM** (4 VQC LSTM gates learn a sine sequence), **QRNN** (recurrent VQC block learns a damped sequence), **HQPINN** (hybrid physics-informed ODE solver, rel-L2 vs analytic ≤0.42), **AA_study** (amplitude-encoding trace-distance collapse ≤0.01), **qLLM** (quantum adapter learns an XOR-structured classification, acc ≥0.85) |
| `tests/mbqc_verify` | 13 | **item 11 A1/A2/A4** — **frontier** deterministic MBQC simulator (bounded `2^width`, not `2^vertices` — fixes the Toffoli/QFT OOM): H/CX/CZ + X/Z/RZ/RX/RY/Y + mixed QML + **A1 wider gates S/Sdg/T/Tdg/SX/U3/CY/SWAP/RXX/RYY/RZZ/CP/CCX/CSWAP** + **A4 Aria round-trip (ghz/grover3/qft4-80-vertex + rotations/u3/clifford_opt)** all compile to the exact unitary (≤1e-9, up to global phase); **A2** `mbqc_clifford_opt.aria` pattern shrinks ≥30% under `optimize()`, channel-preserving. |

Total (verified 2026-09-24): **180 tests** + 1 ignored (default; lib 147 +
integration `mbqc_verify` 13 + `papers` 13 + `pennylane_compat` 5 +
`qcbm_compat` 1 + `qpe_phase_recovery` 1 — was 179/146 on 2026-08-29, 156 on
2026-07-31). The 13
`mbqc_verify` frontier-simulator checks include the A4 Aria round-trip + the
A2 clifford-opt ≥30% reduction.
With `--features metal`
on a Darwin/MPS host: **160** (+3 `tensor_sim` MPS cross-checks and +1
`adjoint` MPS check; self-skip if MPS unavailable). Run the metal suite via
`cargo test -p quantum-qml --features metal -- --test-threads=1` (CI stage
4b does this on Darwin).

> **The `--features metal` steps below (and §5.2b) are N/A on Linux** — the
> Linux/CUDA equivalent is §5.2c/§5.2c′. On the Linux box the CUDA counterpart
> of this suite is `cargo test -p quantum-qml --features cuda --
> --test-threads=1` → **152** lib tests (147 + 4 `tensor_sim` + 1 `adjoint`),
> with **0 device skips** (verified 2026-09-24; was 151 = 146+5 on 2026-08-29).

**The MPS tests self-skip silently and still count as passed**, so a green
suite does not prove the device ran. Assert the skip count is zero:

```bash
cargo test -q -p quantum-qml --features metal --lib 2>/dev/null \
    -- --test-threads=1 --nocapture mps 2>/tmp/mps_err.txt
grep -c "MPS unavailable" /tmp/mps_err.txt      # expected: 0
```

#### 5.2b Complex-on-MPS width ceiling (`mps_probe`)

Where the MPS statevector path actually stops. The failure is a **catchable
panic** (exit 101), so a shell loop can walk n; each width runs in its own
process because the historical failure mode was an uncatchable abort.

```bash
source scripts/env.sh
cargo build -q -p quantum-qml --features metal --example mps_probe
for n in 2 4 8 12 15 16 17; do
  out=$(./target/debug/examples/mps_probe $n 2>/dev/null); rc=$?
  printf "n=%-3s rc=%-4s %s\n" "$n" "$rc" \
      "$(echo "$out" | grep -E 'mps_max_abs_diff|mps_ok' | tr '\n' ' ')"
done
```

| n | Expected | Tol |
|---|---|---|
| 2, 4, 8 | `rc=0`, `mps_ok 1`, diff ≈ 2.1e-8 … 1.5e-8 | ≤2e-3 |
| 12, 15, 16 | `rc=0`, `mps_ok 1`, diff ≈ 5.1e-9, 2.6e-9, 1.5e-9 | ≤2e-3 |
| **17** | `rc=101`, stderr `MPS supports tensors with dimensions <= 16, but got 17` | — |

> **Metal (MPS) ceiling — re-measured 2026-07-31 on libtorch 2.7.0 / M4.**
> This section previously said complex-on-MPS was validated only at **n ≤ 4**
> and aborted at n ≥ 6 with a Metal buffer assertion (measured on libtorch
> 2.4.0, never re-checked). **Both numbers were stale.** The path is correct
> to **n = 16**, agreeing with the CPU statevector to ≤2.1e-8 — far tighter
> than the ~1e-5 previously assumed for float32.
>
> The n = 17 stop is a **tensor-rank** limit, not a buffer one:
> `TensorState` gives each qubit its own axis, so an n-qubit state is a
> rank-n tensor and MPS refuses rank > 16. This means the deferred
> **interleaved-real float32 rework would not lift it** — that rework
> targets float64/complex-op support, which already works. Raising the
> ceiling needs a *layout* change (flat `[2^n]` or grouped axes).
> See `docs/gpu-design.md` §4b and `GPU_PLAN.md` Phase 2.2.

#### 5.2c NVIDIA CUDA path (`--features cuda`, Linux/CUDA box)

CUDA runs **ComplexDouble** (unlike MPS), so the cross-checks hold to the
full **≤1e-12** tolerance. Requires a CUDA libtorch (**2.7.0/cu128** —
cu124/2.4.0 has no sm_120 Blackwell kernels and aborts ATen ops with "no
kernel image") and an NVIDIA GPU.

```bash
./scripts/setup-libtorch.sh cu128        # one-time; pins libtorch 2.7.0 cu128
source scripts/env.sh
cargo test -p quantum-qml --features cuda -- --test-threads=1   # CI stage 4c
# L0 hardware smoke (elementwise + matmul on the GPU, ≤1e-12):
cargo test -p quantum-qml --features cuda --test cuda_l0_smoke -- --ignored --nocapture
```

**Numeric checks (all self-skip if `cuda_available()` is false):**
- `t_cuda_bell_crosscheck`, `t_cuda_ghz_crosscheck`, `t_cuda_mixed_crosscheck`:
  statevector amplitudes vs the ndarray CPU reference **≤ 1e-12**.
- `t_cuda_expectation_and_measure`: ⟨Z⟩ on |0⟩ = +1, on X|0⟩ = −1 (≤1e-12);
  deterministic measure of |1⟩ = 1.
- `adjoint_on_cuda_matches_parameter_shift`: adjoint AD vs parameter-shift on
  a depth-2 ansatz, all 3 observable qubits, **≤ 1e-8**.
- `cuda_l0_smoke`: on-device f64 `zeros`+add sum = 1024; complex128 = 512;
  matmul max|gpu−cpu| ≤ 1e-12. (Proves Blackwell sm_120 kernels run.)

> **CUDA linking note.** The linker's `--as-needed` drops the unreferenced
> `libtorch_cuda.so`, leaving `Cuda::is_available()` false. `quantum-qml`'s
> `build.rs` (active only under `--features cuda`) forces it `DT_NEEDED`. If
> the cuda tests all *skip* on an NVIDIA box, check `readelf -d <testbin> |
> grep cuda` shows `libtorch_cuda.so`.

> **CUDA bench** (`cargo bench -p quantum-qml --features cuda --bench
> tensor_statevector_cuda`): forward-eval CPU vs CUDA, complex128. Measured
> on RTX PRO 6000 Blackwell: n=22 **6.4×**, n=24 **7.1×** (rising with n).
> Does **not** reach the ≥10× target on this fast CPU + reshape+matmul gate
> path — per-gate permute-copies dominate; the **fused in-place kernels**
> (`--features cuda-fused`, §5.2c′) are the route to ≥10×. Baseline:
> `docs/bench-baselines/statevector-linux-cuda.json`.

#### 5.2c′ Fused in-place CUDA statevector (`--features cuda-fused`, the ≥10× path)

The `cuda` path above evolves the state with `tch` reshape+matmul, paying a
`movedim().contiguous()` copy of the whole `2^n` buffer **per gate** — that
copy is what caps it at 6–7×. The `cuda-fused` feature is the ≥10× lever: a
`cudarc` + NVRTC `double2` (complex128) kernel path that mutates the
amplitudes **in place** (one thread per amplitude pair/quad, no transpose,
one host sync at the end). The kernels are precision ports of omega's
`apply_1q.cu`/`apply_2q.cu`. **Not cuStateVec** — cuStateVec is not installed
and omega's own CUDA backend uses cudarc+NVRTC, so we mirror that.

```bash
source scripts/env.sh
# Correctness — fused vs ndarray reference AND vs the tch-CUDA path, ≤1e-10:
cargo test -p quantum-qml --features "cuda cuda-fused" \
    --test cuda_fused_crosscheck -- --test-threads=1
```

**Numeric checks (all self-skip if `FusedCudaSim::new()` errors / no GPU):**
- `fused_bell_matches_reference`, `fused_ghz_matches_reference`,
  `fused_mixed_gates_match_reference`, `fused_deep_layers_match_reference`
  (8q HEA): fused statevector vs the ndarray CPU reference **≤ 1e-10**, and
  ‖ψ‖² = 1 ± 1e-10.
- `fused_parametric_override_matches_reference`: the `params`-override path
  (the QML trainer's path) vs reference **≤ 1e-10**.
- `fused_one_shot_helper_matches_reference`: the `simulate_statevector_cuda_fused`
  one-shot helper vs reference **≤ 1e-10**.
- `fused_matches_tch_cuda_path` (needs both features): fused vs tch-CUDA,
  device-vs-device **≤ 1e-10**.

> **Fused CUDA bench** (`cargo bench -p quantum-qml --features "cuda cuda-fused"
> --bench tensor_statevector_cuda_fused`): three arms — `cpu`, `cuda_tch`
> (6–7×), `cuda_fused`. Measured on RTX PRO 6000 Blackwell (depth-2 ansatz,
> complex128): fused vs tch-CPU **n=22 → 42×, n=24 → 46×**; fused vs the
> tch-CUDA arm **~10×** (n=22 10.3×, n=24 10.2×, n=26 10.2×). The fused arm
> clears the ≥10× target the tch path could not. Baseline:
> `docs/bench-baselines/statevector-linux-cuda-fused.json`.

#### 5.2d OpenCL delegation (`--features omega-http` + omega-server)

OpenCL is **not** an in-tree backend — we delegate to omega-server, which
routes Statevector through its OpenCL backend (GPU_PLAN Phase 4). The
`OmegaHttpExecutor` posts the JSON IR; the integration test asserts the
delegated results match an in-tree CPU statevector reference, numerically.

**1. Bring up an OpenCL omega-server** (sibling repo `../aria-quantum-language-oss`):

```bash
cd ../aria-quantum-language-oss
# `cl-sys` emits `-lOpenCL`, which the linker resolves only against the ICD
# loader DEV symlink `libOpenCL.so`. A driver install ships just
# `libOpenCL.so.1`, so without the dev package the build fails with
# `unable to find library -lOpenCL` even though the OpenCL runtime is fine.
# Preferred fix (once, system-wide):
#     sudo apt install ocl-icd-opencl-dev
# With that installed the plain `cargo build` below links — verified on this
# box. Without root, point the linker at the copy the CUDA toolkit already
# ships (adjust the version dir to match your toolkit):
#     export LIBRARY_PATH="/usr/local/cuda/targets/x86_64-linux/lib:${LIBRARY_PATH:-}"
cargo build -p omega-server --features opencl
# The LD_LIBRARY_PATH below is the RUNTIME counterpart of the link fix above,
# and is likewise unnecessary once `ocl-icd-opencl-dev` is installed (its
# `libOpenCL.so.1` sits in /usr/lib/<triple>, already on the default loader
# path). Keep it only if you took the no-root LIBRARY_PATH route.
OMEGA_PORT=8137 OMEGA_DEVICE=opencl OMEGA_DB_PATH=/tmp/omega-test.db \
  ./target/debug/omega-server --auth bearer-only --save-token-to /tmp/omega.token &
```

**2. Run the delegation test** (back in `quantum/`):

```bash
cd ../quantum && source scripts/env.sh
export OMEGA_SERVER_URL=http://localhost:8137 OMEGA_TOKEN="$(cat /tmp/omega.token)"
cargo test -p quantum-qml --features omega-http --test opencl_delegate -- --nocapture
```

**Numeric checks** (the test self-skips if `OMEGA_SERVER_URL` is unset):
- Bell forced through Statevector: `backend == "statevector"`, counts sum to
  4096, support ⊆ {`00`,`11`}.
- GHZ(4): support ⊆ {`0000`,`1111`}, sum 4096. (Asserted inside the test; run
  with `--nocapture` as shown — the counts themselves are not printed.)
- 4-qubit VQE ansatz: empirical distribution vs the in-tree CPU statevector
  **TVD < 0.06** (sampling noise at 4096 shots: observed 0.017 on mac,
  **0.0264** on the Linux/OpenCL box 2026-08-29 — the `< 0.06` bound is the
  check, not the quoted value).
- Server stderr logs `[quantum] statevector via OpenCL device` (one or more
  lines per `execute` call), confirming the OpenCL device ran the circuits
  rather than the CPU fallback.

A matching CI stage (4d) runs this when `OMEGA_SERVER_URL` is set; otherwise
it skips. Python: build the wheel `--features omega-http` and call
`quantum._rust.omega_execute(url, token, circuit, shots, force_statevector=True)`.

> **Phase 6 bench** (`cargo bench -p quantum-qml --bench batched_gradient`):
> batched vs sequential parameter-shift. On CPU batched is ~0.54× (slower —
> tch dispatch overhead); the batched win is a GPU effect validated on
> `Device::Mps` after Phase 2. Baseline:
> `docs/bench-baselines/gradient-arm64-darwin-m4.json`.

### 5.3 quantum-py (PyO3 — see §9 for full build)

```bash
source scripts/env.sh
cargo check -p quantum-py            # type-check only; needs libtorch on link path
echo "exit=$?"                       # expected: exit=0 (this step's only check)
```

> **This step is a prerequisite gate, not a numeric one** — it proves the crate
> type-checks against the local interpreter. The numeric content of §5.3 is the
> catchable-exception block below, which needs §9.1's `maturin develop` first.

> **PyO3 caps the Python version, and it is the real blocker here** — not a
> missing `maturin`. `pyo3 0.23` supports up to **Python 3.13**; the mac box has
> 3.14, so the build script aborts with
> `the configured Python interpreter version (3.14) is newer than PyO3's
> maximum supported version (3.13)`. On the Linux box `python3` is 3.12, which
> PyO3 accepts — but a `python3.14` earlier on `PATH` (or an active conda env)
> reproduces the abort there too, so (a) below is worth keeping in reach on
> either host. Two ways forward:
>
> ```bash
> # (a) type-check / build anyway against the stable ABI
> PYO3_USE_ABI3_FORWARD_COMPATIBILITY=1 cargo check -p quantum-py
>
> # (b) the supported route — a venv on <= 3.13 (project rule: never system Python)
> PY=$(command -v python3.13 || command -v python3.12)
> $PY -m venv .venv && . .venv/bin/activate && pip install maturin
> ```
>
> §9's wheel steps need (b). Where no ≤3.13 interpreter exists, §5.3 runs with
> (a) and §9 is skipped; on this Linux box (b) works and §9 is verified.

Numeric check that a bad circuit reaches Python as a **catchable** exception
(`SIM_RESULT_PLAN.md` P3). Run after §9.1's `maturin develop`:

```bash
source scripts/env.sh && . .venv/bin/activate
python - <<'PY'
import quantum_py as q
b = q.CircuitBuilder("p3", 1, 0); b.ry(0, 0.5); c = b.build()
print("baseline:", [f"{re:.6f}" for re, im in q.simulate(c)])
try:                                   # 3 params for a 1-slot circuit
    q.simulate(c, params=[0.1, 0.2, 0.3]); print("NO ERROR — regression")
except ValueError as e:
    print("caught ValueError:", str(e)[:70])
try:
    q.simulate(c, params=[0.1, 0.2, 0.3])
except Exception:
    print("caught by plain `except Exception:` -> catchable")
PY
```

Expected, verified 2026-08-01:

```
baseline: ['0.968912', '0.247404']
caught ValueError: simulate: 3 parameters supplied for a circuit with 1 parameter slot(s)
caught by plain `except Exception:` -> catchable
```

The last line is the point. `simulate` used to return a bare list and panic
here, which PyO3 raises as `pyo3_runtime.PanicException` — that inherits from
`BaseException`, **not** `Exception`, so an ordinary `except Exception:` does
not catch it and a bad circuit tears the caller's script down.

(The `CircuitBuilder` route is deliberate: `Circuit(name)` alone has no
registers, and the binding exposes numeric gates only — there is no way to
build an unbound-symbol circuit from Python, so over-supply is the reachable
case.)

### 5.4 quantum-data (finance_lab port Phase 1 — no libtorch, no Python)

Pure-Rust OHLCV loaders + copula/AR(1)/joint-histogram transforms. Every
transform is an exact port of finance_lab's `qcbm_utils.py`, checked against
committed golden fixtures (`crates/quantum-data/tests/golden/golden.json`,
generated once offline from the real Python helpers — **no Python is linked at
build or test time**).

```bash
cargo test -p quantum-data                       # unit + golden parity (33 tests)
cargo test -p quantum-data --features duckdb-lake # 34 tests: +1 (the `parity` binary's DuckDB round-trip)
```

33 tests without the feature, +1 with `duckdb-lake`:

| Test | Kind | Tolerance | What's checked |
|------|------|-----------|----------------|
| `ndtri_known_quantiles` | unit | ≤1e-12 | inverse-normal CDF (Cephes port of `scipy.norm.ppf`) at 0.5/0.975/0.025 |
| `empirical_cdf_monotone_and_ranked` | unit | ≤1e-15 | rank → `(r+0.5)/(N+1)` mapping on a hand example |
| `joint_hist_sums_to_one` | unit | ≤1e-9 | base-K packing, Σp=1, known bin |
| `ar1_passthrough_rho_zero` | unit | ≤1e-15 | `use_copula=false, ρ=0` ⇒ ε = shifted series |
| `empirical_cdf_matches_python` | parity | ≤1e-12 | rank-based empirical CDF vs golden |
| `joint_hist_matches_python` | parity | ≤1e-12 | base-K joint histogram vs golden |
| `ar1_copula_matches_python` | parity | ρ ≤1e-12, ε ≤1e-5 | AR(1) innovations (copula+ppf, estimated ρ); ε at f32 (Python returns float32) |
| `ar1_fixed_rho_matches_python` | parity | ≤1e-5 | AR(1) with fixed ρ, no copula |
| `csv_loader_semicolon_and_dateslice` | parity | ≤1e-12 | `;`-CSV load + ISO date slice (XAUUSD format) |
| `duckdb_roundtrip` | parity *(feature)* | ≤1e-12 | build fixture lake → read OHLCV by ticker/freq/date |

**Numeric manual — the shipped-artefact check.** The deterministic
`pipeline_demo` example runs the full copula → AR(1) → joint-histogram path on a
fixed `(2,6,2)` dataset (no RNG). Its output is Python-verified; run it and
check each line against the golden value:

```bash
cargo run -q -p quantum-data --example pipeline_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `ndtri_0975` | `1.959963984540054` | ≤1e-12 |
| `u00` | `0.576923076923077` | ≤1e-12 |
| `u_min` | `0.115384615384615` | ≤1e-12 |
| `u_max` | `0.961538461538462` | ≤1e-12 |
| `rho` | `-0.367996928096713` | ≤1e-12 |
| `eps_dims` | `2 5 2` | exact |
| `eps000` | `-0.1318809` | ≤1e-5 (f32) |
| `hist_K` | `4` | exact |
| `hist_bins` | `16` | exact |
| `hist_sum` | `1.000000000000` | ≤1e-9 |
| `hist_argmax` | `2` | exact |
| `hist_pmax` | `0.166666666667` | ≤1e-9 |

> The binary-only **dist** artefact (item 0b) gains a finance entrypoint in
> Phase 9 (`quantum-finance` CLI); until then the Phase-1 numeric manual is
> driven through this example binary.

### 5.5 Finance models — QCBM (finance_lab port Phase 2, requires libtorch)

Quantum Circuit Born Machine: H-prelude + `StronglyEntanglingLayers` read out as
`qml.probs`, trained by Adam on cross-entropy against the Phase-1 copula joint
histogram. Lives in `quantum-qml::models::qcbm`; covered by CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::            -- --test-threads=1  # 24 tests (whole models:: tree; 5 of them are qcbm)
cargo test -p quantum-qml --test qcbm_compat                              # PennyLane parity
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `models::qcbm::tests::probs_sum_to_one_and_right_length` | ≤1e-9 | `p_model` is a length-`2ⁿ` distribution |
| `models::qcbm::tests::trains_toward_target_distribution` | KL <0.05 | Adam reduces cross-entropy; residual KL small |
| `models::qcbm::tests::sampling_in_unit_interval` | exact | Born samples land in (0,1)ᴰ |
| `models::qcbm::tests::target_hist_from_eps_sums_to_one` | ≤1e-9 | copula-target builder |
| `qcbm_probs_match_pennylane` (`tests/qcbm_compat.rs`) | ≤1e-10 | circuit `probs` vs PennyLane qnode, 3 cases (4q/2L, 2q/3L, 6q/1L) |

**Numeric manual — end-to-end convergence.** `qcbm_demo` builds a fixed series,
extracts AR(1) copula innovations, trains a 4-qubit/3-layer QCBM, and Born-samples.
Deterministic (seeded θ init + parameter-shift forward); check each line:

```bash
cargo run -q -p quantum-qml --example qcbm_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `rho` | `0.890003` | ≤1e-5 |
| `K` | `4` | exact |
| `target_bins` | `16` | exact |
| `n_qubits` | `4` | exact |
| `target_entropy` | `2.455606` | ≤1e-3 |
| `final_loss` | `2.455606` | ≤1e-3 |
| `final_kl` | `0.000000` | <1e-2 (converged: p_model→p_target) |
| `tvd_model_target` | `0.000000` | <1e-2 |
| `initial_loss` > `final_loss` | yes | — |
| `sample_mean0` | `0.5037` | ±0.05 |
| `sample_mean1` | `0.5000` | ±0.05 |

> Aria mirror: `examples/aria/qcbm_strongly_entangling.aria` (parses +
> instantiates in the `aria_examples` coverage gate).

### 5.6 Finance models — TimeGAN (finance_lab port Phase 3, requires libtorch)

Classical TimeGAN core: five GRU/LSTM→Linear→Sigmoid nets (Embedder, Recovery,
Generator, Supervisor, Discriminator) trained on the canonical three-phase
schedule (embedding → supervised → joint adversarial) with the finance_lab loss
terms. `quantum-qml::models::timegan`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::timegan -- --test-threads=1   # 3 tests (the filter also matches the hybrid TimeGAN)
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `timegan_converges_basic` | E_loss0 ↓, moment_gap <0.25 | embedding autoencoder learns; generated moments near real |
| `timegan_save_load_roundtrip` | ≤1e-5 | `.ot` checkpoint reload regenerates identically |

**Numeric manual — three-phase convergence.** `timegan_demo` trains on a fixed
48×16×3 series and reports diagnostics + a generated-vs-real mean. Deterministic
(seeded init + splitmix batching); check each line:

```bash
cargo run -q -p quantum-qml --example timegan_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `e_loss0_initial` | `3.8505` | ±0.05 |
| `e_loss0_final` | `1.2023` | ±0.10 |
| `e_loss0_improved` | `1` | exact (must fall) |
| `g_loss_s_initial` | `0.135551` | ±0.02 |
| `g_loss_s_final` | `0.003403` | <0.02 (falls ≫10×) |
| `d_loss_final` | `2.8030` | ±0.5 |
| `moment_gap` | `0.0474` | <0.1 |
| `real_mean` | `0.5205` | ±1e-3 |
| `synth_mean` | `0.5005` | ±0.05 |
| `mean_abs_gap` | `0.0200` | <0.05 |
| `synth_dims` | `64 16 3` | exact |

> Full discriminative/predictive-score parity vs Python (within 10%) is a
> deeper check tracked under plan item 3.7; §5.6 is the basic-convergence gate.

### 5.7 Finance models — TimeGAN + QCBM hybrid (Phase 4, requires libtorch)

The "qcbm_pretrained" hybrid: a frozen QCBM (trained on the copula joint
histogram) replaces the Gaussian latent — Born-sample → `ndtri` Gaussianize →
`(B,T,input_dim)` latent carrying the QCBM-learned dependence. CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::timegan::tests::timegan_qcbm_hybrid_converges -- --test-threads=1
```

**Numeric manual.** `timegan_qcbm_demo` trains the QCBM, freezes it as the
latent source, trains the hybrid TimeGAN. Deterministic; check each line:

```bash
cargo run -q -p quantum-qml --example timegan_qcbm_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `rho` | `0.8300` | ±1e-3 |
| `qcbm_K` | `2` | exact |
| `qcbm_final_kl` | `0.000000` | <1e-2 (QCBM converged) |
| `noise_dim` | `3` | exact (= input_dim) |
| `e_loss0_initial` | `3.8505` | ±0.05 |
| `e_loss0_final` | `1.2023` | ±0.10 |
| `e_loss0_improved` | `1` | exact |
| `g_loss_s_final` | `0.003403` | <0.02 |
| `moment_gap` | `0.0461` | <0.12 |
| `real_mean` | `0.5205` | ±1e-3 |
| `synth_mean` | `0.5188` | ±0.05 |
| `mean_abs_gap` | `0.0016` | <0.05 |
| `synth_dims` | `64 16 3` | exact |

> "qcbm_joint" mode (QCBM θ in the same optimizer) and the conditional variant
> are tracked under plan items 4.3/4.4; §5.7 covers the pretrained hybrid.

### 5.8 Finance models — PQC classifier (Phase 5 rich ansatz, requires libtorch)

Market-regime classifier: encoder (Linear→ReLU→Linear) → quantum block
(AngleEmbedding-Y + L×[ring IsingZZ + Rot], ⟨Z_i⟩ readout) → head
(Linear→ReLU→Linear). The quantum block separates data angles from trainable
weights; parameter-shift gradients flow to both (encoder *and* ansatz).
`quantum-qml::models::qclassifier`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::qclassifier -- --test-threads=1   # 1 test
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `qclassifier_learns_three_classes` | acc >0.75, loss ↓ | end-to-end training on separable 3-class blobs |

**Numeric manual.** `qclassifier_demo` trains on separable 3-class blobs.
Deterministic (seeded init + deterministic blobs + parameter-shift); check:

```bash
cargo run -q -p quantum-qml --example qclassifier_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_qubits` | `4` | exact |
| `n_classes` | `3` | exact |
| `loss_initial` | `1.4486` | ±0.1 |
| `loss_final` | `0.0003` | <0.1 (converged) |
| `loss_improved` | `1` | exact |
| `train_acc` | `1.0000` | ≥0.9 |
| `acc_above_chance` | `1` | exact |

> Aria mirror: `examples/aria/qclassifier_rich.aria`. The QCNN / amplitude
> ansätze, Z+ZZ / Z₀ readouts, mid-circuit measure, and val-accuracy-within-5pp
> parity are Phase-5 follow-ups (plan items 5.1 QCNN/amplitude, 5.2, 5.3, 5.5).

### 5.9 Finance models — Quantum GAN discriminator (Phase 6, requires libtorch)

The reference's commented-out quantum discriminator, brought to life: GRU →
last step → Linear → tanh·π angles → quantum block (AngleEmbedding-Y + L×(RY,RZ),
⟨Z_i⟩) → Linear → Sigmoid. A sequence-level real/fake score.
`quantum-qml::models::qgan`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::qgan -- --test-threads=1   # 1 test
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `qdiscriminator_separates_real_from_noise` | AUC >0.6, loss ↓ | trains to distinguish smooth sequences from noise |

**Numeric manual.** `qgan_demo` trains the discriminator on real-vs-noise.
Deterministic; check each line:

```bash
cargo run -q -p quantum-qml --example qgan_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_qubits` | `3` | exact |
| `loss_initial` | `1.4170` | ±0.1 |
| `loss_final` | `0.0129` | <0.2 (converged) |
| `loss_improved` | `1` | exact |
| `auc_final` | `1.0000` | ≥0.6 (plan target) |
| `auc_above_0p6` | `1` | exact |

> No strict Python parity (the reference discriminator is commented out); §5.9
> is the plan's sanity gate (AUC > 0.6). Slotting into the full TimeGAN loop as
> a config-flag discriminator (plan 6.2) is structural / off by default.

### 5.10 Finance models — Architecture search (Phase 7, requires libtorch)

Optuna replacement: a deterministic random/grid search over PQC-classifier
hyperparameters (`n_qubits`, `n_layers`, `lr`) scored by validation accuracy,
with a per-trial step budget. `quantum-qml::models::archsearch`; CI stage 4.

```bash
source scripts/env.sh
cargo test -p quantum-qml --lib models::archsearch -- --test-threads=1   # 1 test
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `search_selects_a_good_config` | best ≥ mean, >0.6 | the search runs N trials and selects the best by val accuracy |

**Numeric manual.** `archsearch_demo` searches 4 trials over a train/val split:

```bash
cargo run -q -p quantum-qml --example archsearch_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_trials` | `4` | exact |
| `best_val_acc` | `1.0000` | ≥0.6 |
| `best_config` | `nq3 nl2 lr0.05` | exact (deterministic winner) |
| `best_ge_mean` | `1` | exact |
| `best_above_chance` | `1` | exact |

> TPE/argmin surrogate + macro-F1 walk-forward CV + results CSV are deeper
> follow-ups (plan items 7.1/7.3/7.5); §5.10 covers the search loop + selection.

### 5.11 quantum-backtest (finance_lab port Phase 8 — no libtorch, no Python)

Pure-Rust walk-forward backtest harness: rolling train/test windows, a
`Strategy` mapping regime predictions to positions, and PnL/Sharpe/max-drawdown.
CI stage 2 (no external deps).

```bash
cargo test -p quantum-backtest          # 5 unit tests
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `splitter_rolls_windows` | exact | rolling window index ranges |
| `backtest_known_series` | ≤1e-12 | equity/PnL/drawdown on a hand series (1→1.1→1.045, dd 5%) |
| `strategy_beats_buy_and_hold_on_regime_signal` | — | **harness identity only** — regimes are ground truth encoding each bar's own return sign, so PnL > B&H is forced. Pins the arithmetic, not skill. |
| `causal_regime_never_reads_the_current_bar` | exact | a negative trailing window + a huge positive current bar ⇒ still flat (0 would mean look-ahead) |
| `negative_control_discriminates_a_leaky_estimator` | — | causal rule must **not** beat B&H on a structureless series, and a look-ahead rule on the same series **must** — so the control can tell them apart |

**Numeric manual.** `backtest_demo` prints three sections. Section A is a
perfect-foresight identity (cannot fail). Section B is the real result: the
regime is estimated from **past bars only** and scored on test blocks only.
Section C is the **negative control** — the same rule on a structureless series
with positive drift, where a flat-part-of-the-time rule must lose.

Verified by injection: putting look-ahead into the estimator flips
`control_beats_bh_oos` from 0 to 1 while `causal_beats_bh_oos` stays 1 — so the
control is the only line here that detects leakage. Deterministic:

```bash
cargo run -q -p quantum-backtest --example backtest_demo
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_windows` | `4` | exact |
| `oracle_pnl` | `0.4800` | ±1e-3 |
| `bh_pnl` | `0.1200` | ±1e-3 |
| `oracle_beats_bh` | `1` | exact (forced — identity) |
| `oracle_sharpe` | `14.1393` | ±0.01 |
| `oracle_max_dd` | `0.0000` | ≤1e-3 |
| `bh_max_dd` | `0.0584` | ±1e-3 |
| `oracle_dd_le_bh` | `1` | exact |
| `oracle_final_equity` | `1.6126` | ±1e-3 |
| `causal_oos_bars` | `80` | exact |
| `causal_oos_pnl` | `0.1520` | ±1e-3 |
| `causal_oos_bh_pnl` | `0.0800` | ±1e-3 |
| `causal_beats_bh_oos` | `1` | exact |
| `control_oos_pnl` | `0.0431` | ±1e-3 |
| `control_oos_bh_pnl` | `0.0955` | ±1e-3 |
| `control_beats_bh_oos` | **`0`** | exact (a `1` means look-ahead leaked) |

> Python `lab/baseline_regime.ipynb` equity-within-1% parity (plan acceptance)
> needs the notebook's data fixture; §5.11 is the numeric harness check.

### 5.11b quantum-qpu (GPU_PLAN Phase 8.A — no libtorch, no Python)

Real-machine (QPU) **provider abstraction**: the `QpuProvider` trait
(`submit → poll → result`, accepting the same `OmegaCircuitIR` as the local-GPU
path) plus `SimulatorProvider` — the reference backend that executes the IR
through an in-tree statevector + seeded SplitMix64 shot-sampler (the
omega-functions runtime mirrored in pure Rust). Deterministic. CI stage 2.

```bash
cargo test -p quantum-qpu               # 48 tests (21 lib + 24 integration) + 3 doctests
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `bell_is_5050_entangled` | ±5% | Bell job → `{00,11}` each ≈0.5, `01`/`10` = 0 (≤1e-9) |
| `ghz_is_5050_three_qubit` | ±5% | GHZ-3 → `{000,111}` each ≈0.5, zero leakage |
| `ry_rotation_matches_born_rule` | ±5% | `Ry(π/3)` → `P(1)=sin²(θ/2)=0.25` (Born rule) |
| `same_seed_reproduces_counts` | exact | same seed ⇒ identical counts; different seeds differ |
| `job_lifecycle_and_not_ready` | exact | `Queued→Running→Done`; early `result` ⇒ `NotReady` |
| `submit_validates_inputs` | exact | `UnknownBackend`/`LimitExceeded`/`UnknownJob` rejects |
| `conditioned_gate_is_unsupported` | exact | classically-conditioned gate ⇒ `Unsupported` (no silent wrong answer) |

**Numeric manual.** `qpu_bell` submits a Bell circuit to `SimulatorProvider`,
polls to Done, and prints the shot split. Deterministic (fixed seed 2026):

```bash
cargo run -q -p quantum-qpu --example qpu_bell
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `bell_00` | `0.5001` | ±0.05 |
| `bell_11` | `0.4999` | ±0.05 |
| `bell_leak` | `0.000000` | ≤1e-9 |
| `bell_ok` | `1` | exact |

> Real cloud providers (IBM 8.B / IonQ 8.C / omega-server HTTP) are hardware-
> gated; they drop in as additional `QpuProvider` impls with the same numeric
> Bell acceptance (50/50 ±5%).

#### 5.11b-ii Readout-error mitigation (GPU_PLAN Phase 8.E.1)

**Provider-agnostic** — `quantum_qpu::mitigation` takes counts plus an
assignment matrix `A[m][t] = P(read m | true t)` and inverts the measurement
channel. No hardware, no libtorch, no Python; `A` comes from per-qubit
calibration rates or a measured full matrix (crosstalk included). CI stage 2.

**Numerical policy** (this is the part worth checking, not the inverse itself):
the exact inverse `A⁻¹y` is returned untouched **when it is already a
probability vector**; when it is not — the routine case on real data, because
`A⁻¹` amplifies shot noise into negative entries — the mitigator does **not**
clip and renormalise. It returns `argmin ‖Ax−y‖₂` subject to `x ≥ 0, Σx = 1`
(projected gradient onto the simplex), and reports `negative_mass` (how far the
naive inverse went below zero) and `residual` (`‖Ax−y‖₂`) so an inconsistent
calibration is visible rather than silently absorbed. Counts are therefore
`f64` — mitigated counts are not integers.

```bash
cargo test -p quantum-qpu --test readout_mitigation   # the 9 mitigation tests
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `identity_matrix_is_a_no_op` | ≤1e-6 | identity `A` ⇒ counts unchanged, `iterations = 0`, no key invented/dropped |
| `per_qubit_zero_error_equals_identity` | exact | tensor-product build == explicit identity (catches a transpose) |
| `asymmetric_error_on_bell_recovers_5050` | ≤1e-4 | raw leak 0.1055 ⇒ mitigated `{00,11}` = 0.5 each, leak ≤1e-4 |
| `full_assignment_matrix_with_crosstalk_recovers_bell` | ≤1e-4 | measured 4×4 `A` with correlated terms ⇒ same recovery |
| `adversarial_negative_inverse_is_projected_not_clipped` | ≤1e-6 | `A⁻¹y = (−1/3, 4/3)` ⇒ output `(0, 1)`, `negative_mass = 1/3`, `residual = √2·0.2 = 0.282843` |
| `mildly_infeasible_data_stays_close_to_the_inverse` | ≤1e-6 | slightly infeasible data ⇒ non-negative, shots conserved, residual < 0.05, converged |
| `singular_channel_is_refused` | exact | `p10+p01 = 1` ⇒ `QpuError::Mitigation`; singular measured `A` ⇒ finite constrained fit, no NaN |
| `over_wide_register_is_refused` | exact | 11 qubits ⇒ `LimitExceeded` (dense `2ⁿ×2ⁿ`, `MAX_QUBITS = 10`) |
| `provider_counts_round_trip_through_mitigation` | ≤1e-4 | `SimulatorProvider` counts → channel → mitigation → the simulator's own numbers (proves the bitstring convention matches `ExecResult`) |

**Numeric manual.** Bell counts from `SimulatorProvider` (seed 2026, 10⁶ shots)
pushed through readout error `(p10,p01) = (0.02,0.11)` on bit 0 and
`(0.06,0.03)` on bit 1, then mitigated; plus the adversarial single qubit
(20% symmetric error, every shot read as `1`):

```bash
cargo run -q -p quantum-qpu --example qpu_readout_mitigation
```

| Output line | Expected | Tol | Meaning |
|-------------|----------|-----|---------|
| `raw_00` | `0.4625` | ±1e-3 | corrupted — the channel did something |
| `raw_11` | `0.4320` | ±1e-3 | corrupted asymmetrically (≠ `raw_00`) |
| `raw_leak` | `0.1055` | ±1e-3 | 10.5% of shots landed in `01`/`10`, which a Bell state never produces |
| `mit_00` | `0.5003` | ±1e-3 | recovered = the simulator's own clean value |
| `mit_11` | `0.4997` | ±1e-3 | recovered |
| `mit_leak` | `0.000001` | ≤1e-3 | leakage removed |
| `mit_iterations` | `0` | exact | well-conditioned ⇒ exact inverse used, no projection needed |
| `mit_residual` | `0.000000000` | ≤1e-6 | the fit explains the data exactly |
| `adv_neg_mass` | `0.333333` | ±1e-6 | the naive inverse really was `−1/3` here |
| `adv_p1` | `1.000000` | ±1e-6 | constrained optimum sits on the simplex boundary |
| `adv_residual` | `0.282843` | ±1e-6 | `√2·0.2` — the data is not reachable from any distribution, and it says so |
| `adv_min_count` | `0.000000` | exact | **no negative count is ever emitted** |
| `readout_ok` | `1` | exact | all of the above |

#### 5.11b-iii Zero-noise extrapolation (GPU_PLAN Phase 8.E.2)

**Backend-agnostic** — `quantum_qpu::zne` scales noise by *unitary folding*
(`U ↦ U (U† U)^k`, scale factor `λ = 2k+1`) and extrapolates the measured
expectation to `λ = 0` by Richardson. The only backend coupling is a closure
`FnMut(&OmegaCircuitIR) -> Result<f64, QpuError>`; no provider appears in any
signature. No hardware, no libtorch, no Python. CI stage 2. Full write-up:
`docs/qpu-choreography.md`.

Two things are checked separately, because they fail independently:

1. **Folding is logically the identity.** A folded circuit must compute exactly
   what the original did — otherwise ZNE is running a different program. Checked
   on the *exact* Born-rule distribution (`sim::run_ir_probabilities`, no shot
   noise) in a generic measurement basis, so a `U†` wrong only by a relative
   phase still fails. Global **and** local folding, `k = 1..3`.
2. **The extrapolation recovers the noiseless value** under a noise model whose
   λ-dependence is known in closed form. An identity-fold no-op test is
   necessary and not sufficient; the depolarizing test below is the real one.

```bash
cargo test -p quantum-qpu --test zne    # the 8 ZNE integration tests
cargo test -p quantum-qpu --lib         # + 12 zne unit tests (21 lib total)
```

| Test | Tolerance | What's checked |
|------|-----------|----------------|
| `folding_is_logically_the_identity` | ≤1e-12 | folded distribution == base distribution, both methods, `k = 0..3`, on a 12-gate mixed-kind circuit; gate count == `(2k+1)·g₀` |
| `every_gate_kind_adjoint_is_exact` | ≤1e-12 | all 23 foldable kinds, one at a time: `prep; g; g†` == `prep`, **and** `g` alone provably moves the state (so the first check is not vacuous) |
| `ir_inverse_agrees_with_quantum_core_circuit_inverse` | ≤1e-12 | this crate's IR-level adjoint and `quantum_core`'s AST-level `Circuit::inverse()` both give `P(000) = 1` for `C†C` |
| `zne_recovers_the_noiseless_expectation_under_depolarizing_noise` | ≤5e-3 | `⟨Z₀⟩(λ) = (1−p)^{λg₀}⟨Z₀⟩_ideal`, `p = 0.02`: raw error 0.0592 ⇒ mitigated 0.0008 (>20× better); points match the model to 1e-12; degree 3 beats degree 2 but costs more amplification |
| `quadratic_noise_is_extrapolated_exactly` | ≤1e-12 | exactly-quadratic noise ⇒ exact recovery on 3 points; 2 points miss by exactly `a₂λ₁λ₂` |
| `zne_through_a_provider_is_a_no_op_on_a_noiseless_backend` | ±0.022 | real `SimulatorProvider` jobs (400k shots, `Queued→Running→Done`), one per scale factor; tolerance = shot noise × the fit's own 3.5 amplification |
| `unfoldable_circuits_are_refused` | exact | `Reset`, gate-after-`Measure`, `Collapse` mode, conditioned gate, photonic `PhaseShifter`/`BeamSplitterRx` ⇒ `QpuError::Mitigation`; evaluator errors propagate; `NaN` expectation refused |
| `richardson_is_usable_standalone` | ≤1e-12 | the extrapolator on data that never came from a circuit: `15/8·0.90 − 5/4·0.70 + 3/8·0.54 = 1.015` |

**Numeric manual.** `Ry(0.7) q0; CX; Rz(0.4) q1; CX` (`g₀ = 4`), 10⁶ shots per
point on `SimulatorProvider` (seed 2026), counts pushed through a global
depolarizing channel of strength `p = 0.02` **per gate of the folded circuit**,
so `⟨Z₀⟩(λ) = (1−p)^{4λ}·cos(0.7)` — exponential in λ, hence *not* exactly
representable by the quadratic fit, so `zne_mit_err` is a real error and not a
rigged zero:

```bash
cargo run -q -p quantum-qpu --example qpu_zne
```

| Output line | Expected | Tol | Meaning |
|-------------|----------|-----|---------|
| `zne_base_gates` | `4` | exact | unitary gates before folding |
| `zne_fold_kinds` | `15` | exact | gates in the separate fold-identity circuit (12 distinct kinds) |
| `zne_fold_drift` | `1.166e-15` | ≤1e-12 | max \|Δp\| between folded and unfolded exact distributions — **folding changes nothing** |
| `zne_ideal` | `0.764842` | ±1e-6 | `cos(0.7)`, analytic |
| `zne_lambda1` | `0.705598 gates 4` | ±1e-3 | unfolded, already 7.8% low |
| `zne_lambda3` | `0.599946 gates 12` | ±1e-3 | λ=3 ⇒ exactly 3× the gates |
| `zne_lambda5` | `0.509736 gates 20` | ±1e-3 | λ=5 ⇒ exactly 5× the gates |
| `zne_mitigated` | `0.764215` | ±5e-3 | degree-2 Richardson to λ=0 |
| `zne_raw_err` | `0.059244` | ±1e-3 | the bias ZNE has to remove |
| `zne_mit_err` | `0.000627` | ≤5e-3 | what is left of it |
| `zne_improvement` | `94.4` | ≥20 | × |
| `zne_order` | `2` | exact | 3 scale factors ⇒ degree 2. Not a free parameter. |
| `zne_amplification` | `3.5000` | ±1e-9 | `Σ|cᵢ|` for `λ = 1,3,5` — the variance price of the fit |
| `zne_two_point` | `0.758289` | ±5e-3 | degree-1 fit, weights exactly `(3/2, −1/2)` |
| `zne_two_err` | `0.006553` | < raw, > `zne_mit_err` | one order fewer, ten times worse |
| `zne_local_vs_global` | `1.315e-3` | ≤1e-2 | the two fold scopes agree to within the shot noise of two independent job sets |
| `zne_ok` | `1` | exact | all of the above |

> **Mutation-tested.** Four deliberate breakages were each confirmed to fail the
> suite before being reverted: dropping the φ/λ swap in the `U3` adjoint
> (4 tests + `zne_ok`), flipping the Lagrange denominator sign (3 tests +
> `zne_ok` — note the 3-point weights are sign-invariant under this, which is
> why the example also prints a 2-point sweep), emitting `g g g` instead of
> `g g† g` in local folding (4 tests + `zne_ok`), and `λ = k+1` instead of
> `2k+1` (5 tests + `zne_ok`).

> Still open in 8.E: nothing — 8.E.1, 8.E.2 and 8.E.3 have all landed. The 8.E
> *acceptance* line "Bell submits to IBM *and* IonQ sims with mitigation
> applied" still needs 8.B/8.C, which are hardware-token-gated, and the real
> readout matrix of 8.D.1 is a provider method gated with them.

### 5.11c quantum-photonics (item 12 photonic batch — no libtorch, no Python)

Pure-Rust linear-optical **Fock/SLOS engine** (beam splitters + phase shifters →
mode-transfer unitary → output photon-number distribution via permanents), the
**four adaptive/temporal primitives** (`fockstate` partial-mode measurement +
adaptive feed-forward, `distinguishability` partial-distinguishability SLOS,
`reservoir` memristive temporal feedback), and the **full photonic
reproduced-paper set**. In-tree reference mirroring `omega-backend-photonics`.
Deterministic. CI stage 2.

```bash
cargo test -p quantum-photonics         # engine + primitives + papers (+ doctest)
```

Engine goldens (exact, ≤1e-12): Hong–Ou–Mandel dip (two photons on a 50:50
splitter ⇒ `P(1,1)=0`, `P(2,0)=P(0,2)=0.5`), single-photon Born rule, output
distribution normalised, permanent values, deterministic seeded sampler.
Primitive goldens: `FockKet.evolve` probabilities = SLOS distribution (≤1e-10),
measurement branches sum to 1, partial-distinguishability coincidence
`P(1,1)=0.5·(1−η)` exact, memristive memory bounded + τ-monotone.

**Numeric manual.** `photonic_papers` runs all nine and prints each headline
metric vs reference, PASS/FAIL:

```bash
cargo run -q -p quantum-photonics --example photonic_papers
```

| Paper | Output metric | Expected | Tol |
|-------|---------------|----------|-----|
| `fock_state_expr` | accessible Fock dim (3 photons,3 modes) | `10` (=`C(5,2)`) | exact |
| `nearest_centroids` | `max\|P(overlap) − (a·b)²\|` | `0` | ≤1e-10 |
| `DQNN` | distributed 2-photon interference visibility | `1.0` | ≥0.99 |
| `QORC` | reservoir+linear-readout NMSE, `g(x)=sin2x` | `≈0` | ≤0.05 |
| `photonic_QGAN` | recovered BS angle vs closed-form θ\* | `≈0` (1.5e-12) | ≤1e-6 |
| `photonic_genmodel` | MMD-trained generator final MMD² | `≈0` | ≤0.05 |
| `photonic_QCNN` | BAS test accuracy (adaptive injection) | `1.0` | ≥0.85 |
| `photonic_kernels` | η-kernel vs two-source model + hand-written 2×2 | `≈0` (6.7e-16) | ≤1e-12 |
| `qrc_memristor` | memristive reservoir NMSE on NARMA2 | `≈0.037` | ≤0.10 |
| final line | `PHOTONIC PARITY OK — 9/9 within reference` | — | exit 0 |

**`photonic_kernels` carries two extra gates** (`cargo test -p quantum-photonics`,
not in the parity table because each is a `Metric`-free assertion). Both are
numeric and both were verified by injection — see `docs/reproduced-papers.md`
§ "The `photonic_kernels` claim, withdrawn and restated".

| Test | Checks | Expected | Tol |
|-------|---------------|----------|-----|
| `..._interference_is_non_degenerate` | `max\|κ(η=1) − κ(η=0)\|` over the grid | `0.334099` | ≥0.30 |
| `..._alignment_advantage_is_a_normalisation_artifact` | random balanced label patterns scoring a positive *uncentered* advantage | `10` of 10 | exact |
| `..._alignment_advantage_is_a_normalisation_artifact` | centered advantage, 14 structured targets vs 10 random | `−0.0037` vs `+0.0059` | structured ≤ random |
| `..._alignment_advantage_is_a_normalisation_artifact` | `‖K(η=0)‖_F` vs `‖K(η=1)‖_F` (the pedestal) | `8.8184` vs `7.6742` | k0 > k1 |

> The *Expected* values are reference numbers computed inside the tests;
> `cargo test` (even with `-- --nocapture`) prints only `ok` for them. The
> copy-paste-verifiable check is the *Tol* inequality passing (`test result:
> ok`), not the digits.

> The second and third rows are a pin on a **withdrawn** claim: Yin 2025's
> indistinguishability advantage is not reproduced, and these keep it from being
> quietly re-promoted. If the third row ever fails, re-measure and restate the
> entry — do not relax the bar.

> The four primitives that previously blocked the last three papers (adaptive
> injection, partial-mode measurement, distinguishability, stateful reservoir)
> were built 2026-06-04 in `omega-backend-photonics` (commit `89ec960`) and
> mirrored here — see `docs/reproduced-papers.md` § "Photonic gap — CLOSED".

#### Photonic generative model — Track B (no libtorch)

The photonic train-on-classical / deploy-on-quantum model (Gottlieb et al. 2026,
arXiv:2603.08793). A 4-mode beam-splitter mesh fed `|1,1,0,0⟩` is trained by
finite-difference gradient descent on the squared MMD to match a realizable
teacher's output photon-number distribution. The exact SLOS distribution is the
referee; **deployment is boson sampling** (classically hard at scale). CI stage 2
+ `photonic_papers` `photonic_genmodel`.

```bash
cargo run -q -p quantum-photonics --example photonic_genmodel_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `hom_p11` (HOM coincidence sanity) | `0.000000` | ≤1e-10 |
| `n_output_states` (2 photons, 4 modes ⇒ `C(5,3)`) | `10` | exact |
| `mmd_exact_vs_empirical` (20k shots vs exact dist) | `0.005152` | ≤1e-5 (golden); bar ≤1e-2 |
| `mmd_initial` | `0.407811` | ≤1e-5 (golden) |
| `mmd_final` | mac `0.002026` / linux `0.011927` | ≤1e-5 (per-OS golden); ratio ≤0.03 |
| `mmd_ratio` | linux `0.029246` | ≤0.03 — the demo prints this line directly; it is the "ratio" gate above as its own row |
| `tv_to_target` | mac `0.063559` / linux `0.131076` | ≤1e-5 (per-OS golden); bar ≤0.2 |

> The finite-difference MMD training loop accumulates libm float drift, so the
> two **post-training** lines are per-OS goldens (each exact + deterministic on
> its platform); every pre-training line agrees bit-for-bit across mac + linux.

> The 4-mode mesh is universal over the 10-state Fock space, so unlike the
> truncated-MMD IQP case (§5.11e) the model fits the *full* distribution well
> (TV≈0.06). On the **RTX6000 Pro** box: 12-photon / 12-mode training run +
> wall-clock (32-thread permanents).

### 5.11d Surrogates & sketching — Track C (requires libtorch)

The classically-tractable side of the "scale QML to more qubits / more data"
program, each piece certified against the exact circuit (CI stage 4a-C +
`papers_runner` `classical_surrogate`, `data_sketching`):

1. **RFF ≈ RBF kernel** (Bochner) — random Fourier features approximate the exact
   kernel Gram matrix.
2. **Classical surrogate of a quantum model** (arXiv:2206.11740) — an RFF+ridge
   regressor reproduces a single-qubit data-reuploading `⟨Z₀⟩(x)` (a truncated
   Fourier series). A small fidelity gap *is* the dequantization point.
3. **Johnson–Lindenstrauss sketch → 10-qubit quantum kernel** — the runnable
   analogue of Babbush et al.'s oracle sketching (arXiv:2604.07639); the
   fault-tolerant oracle-sketch itself is out of scope. A JL projection
   compresses 256-dim data while preserving pairwise distances so a 10-qubit
   quantum-kernel classifier matches the full-dim classifier.
4. **Shuffled-label negative control** — the same pipeline with the labels
   permuted. This is the line that makes (3) mean anything; see the note below.

Everything is deterministic (SplitMix64 + Box–Muller), so the numbers are golden.

```bash
cargo run -q -p quantum-qml --example surrogate_sketch_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `rff_kernel_relerr` | `0.0212` | ≤1e-3 (golden); bar ≤0.10 |
| `surrogate_fidelity` | `0.0023` | ≤1e-3 (golden); bar ≤0.05 |
| `jl_distortion_k128` | `0.3646` | ≤1e-3 (golden); bar ≤0.50 |
| `jl_distortion_k10` | `1.8192` | ≤1e-3 (golden; k=qubit budget, looser) |
| `n_qubits` | `10` | exact |
| `acc_full` | `1.0000` | exact |
| `acc_sketched` | `1.0000` | exact |
| `acc_gap` | `0.0000` | exact |
| `acc_shuffled_mean` | `0.5052` | ≤1e-3 (golden); bar ≤0.60 |
| `control_gap` | `0.4948` | ≤1e-3 (golden); bar ≥0.35 |

> **Read `acc_gap` only together with `acc_shuffled_mean`.** `two_blobs`
> separates the classes by `‖Δmean‖ = 2·0.5·√256 = 16` against `0.3` noise, so
> `acc_full` and `acc_sketched` are both exactly `1.0` and `acc_gap` is `0`
> *because the task is easy* — not because the sketch preserved structure. On
> its own that line would pass for a pipeline doing nothing.
>
> `acc_shuffled_mean` re-runs the identical pipeline with the labels permuted
> (features, split and class balance untouched). It must fall to chance: measured
> `0.5052` against a theoretical `0.5`. Averaged over 16 label seeds because a
> single seed has sd ≈ `√(0.25/24)` ≈ `0.10` at 24 test points — one of the 16
> does reach `0.7917` by chance alone, so a max-based bar would be noise.
>
> Both directions are verified by fault injection: reinstating the old
> whole-dataset scaler fit trips `scaler_is_fit_on_the_training_rows_only`
> (train-column mean `0.0044`, want `0`), and leaking the true label into the
> prediction drives `acc_shuffled_mean` to `1.0` and trips the control. Note the
> label leak does **not** trip `acc_gap` — which is exactly why the control is
> there.

> On the **RTX6000 Pro** box (`QUANTUM_SCALE=1`) the same pipeline runs at
> d=50k → k=64 sketch with an n=24-qubit kernel; report `acc_gap` and wall-clock.

### 5.11e IQP Born machine — Track A (requires libtorch)

Train-on-classical / deploy-on-quantum generative model (arXiv:2503.02934). A
1-D chain-IQP Born machine `|ψ⟩=H^⊗n·D(θ)·H^⊗n|0⟩` is trained to match a
realizable teacher target by gradient descent on the **truncated analytic MMD**
— a poly-time estimator (transfer-matrix `⟨Z_S⟩`) that never touches the 2ⁿ
statevector, so the same code scales to many qubits. Sampling `p_θ` is
classically hard (deploy on quantum); `sample_exact` is verification-only.

The load-bearing certificate: the full-Fourier analytic MMD **equals** the exact
statevector MMD to ≤1e-10 — i.e. the efficient training objective is exact at
this size. CI stage 4a-A + `papers_runner` `iqp_born`.

```bash
cargo run -q -p quantum-qml --example iqp_born_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `n_qubits` | `12` | exact |
| `mmd_analytic_vs_exact` | `1.05e-13` | ≤1e-10 (certificate) |
| `mmd_initial` | `0.117284` | ≤1e-5 (golden) |
| `mmd_final` | `0.001603` | ≤1e-5 (golden); ratio ≈0.014 |
| `loss_monotone` | `1` | exact |
| `tv_to_target` | `0.411620` | ≤1e-4 (golden) |
| `mmd_empirical_deploy` | `0.002215` | ≤1e-4 (golden) |

> **Honesty.** The headline is the ≤1e-10 certificate and the MMD collapse
> (×0.014). `tv_to_target≈0.41` is *expected and reported, not hidden*: a
> truncated low-order MMD matches the target's low-order moments, not the full
> 4096-dim distribution — exactly the trade-off that makes training poly-time.
> On the **RTX6000 Pro** box (`QUANTUM_SCALE=1`) the same `train` runs at n=256
> and a 1000-qubit smoke (loss collapse only; sampling would need a QPU), with
> the ≤1e-10 certificate re-checked at the largest affordable n (≈28, CUDA).

### 5.11f Quantum Oracle Sketching — Track D (no libtorch)

Emulation of Quantum Oracle Sketching (Zhao/Babbush/Huang 2026,
arXiv:2604.07639; reference code github.com/haimengzhao/quantum-oracle-sketching).
QOS instantiates a query oracle **from a stream of random classical samples**
(no QRAM); the qubit count is `⌈log₂ dim⌉` — polylog in the dataset size, the
memory-advantage framing. We port the authors' **expected-unitary** benchmarking
mode and certify the headline claim on a statevector: the infidelity to the
exact oracle obeys the `O(1/N²)` sample-complexity law. CI stage 2 +
`papers_runner` `qos`. This is an emulation at small n; the fault-tolerant
hardware claim, the QSVT linear-algebra step, interferometric classical-shadow
readout, and the real RNA-seq / sentiment experiments are explicitly out of scope.

```bash
cargo run -q -p quantum-core --example qos_sketch_demo
```

| Output line | Expected | Tol |
|---|---|---|
| `dim` | `1024` | exact |
| `n_qubits` (= `⌈log₂ dim⌉`) | `10` | exact |
| `infidelity_N64` | `2.081e-6` | ≤1e-9 (golden) |
| `infidelity_N1024` | `8.135e-9` | ≤1e-11 (golden) |
| `infidelity_N16384` | `3.178e-11` | ≤1e-13 (golden) |
| `error_ratio_2x` (the O(1/N²) law) | `3.9999` | ±0.05 |
| `block_encoding_err` (Halmos round-trip) | `0.00e0` | ≤1e-12 |

> The clean `≈4×` infidelity drop per doubling of samples *is* the paper's
> sample-complexity scaling, reproduced exactly. On the **RTX6000 Pro** box the
> same emulation runs at larger `dim` (more index qubits) where the full
> statevector is still cheap because the QOS oracle is diagonal.

**Dist artefact (item 0b).** QOS is libtorch-free, so the **stripped dist
`quantum` binary** runs it directly — the first scaling-QML track exercised
through the shipped artefact, not just `cargo run`:

```bash
quantum qos            # same goldens as above
quantum qos --dim 4096 # 12 index qubits
```

Expect `n_qubits 10` (default) / `n_qubits 12` (`--dim 4096`), and for both `error_ratio_2x 3.9999`, `block_encoding_err 0.00e0`.

### 5.12 quantum-finance CLI (finance_lab port Phase 9, requires libtorch)

The single finance entrypoint — one binary, model subcommands. Mirrors
finance_lab's per-model binaries; the dist's finance face (item 0b). CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- help            # subcommand list
cargo run -q -p quantum-finance -- qcbm            # final_kl 0.000000
cargo run -q -p quantum-finance -- regime-classify # train_acc 1.0000
cargo run -q -p quantum-finance -- arch-search     # best_config nq3 nl2 lr0.05
cargo run -q -p quantum-finance -- backtest        # causal_beats_bh_oos 1, control_beats_bh_oos 0
cargo run -q -p quantum-finance -- timegan         # e_loss0_improved 1
cargo run -q -p quantum-finance -- timegan-qcbm    # e_loss0_improved 1
```

| Subcommand | Key output line | Expected | Tol |
|------------|-----------------|----------|-----|
| `qcbm` | `final_kl` | `0.000000` | <1e-2 |
| `regime-classify` | `acc_above_chance` | `1` | exact |
| `arch-search` | `best_config` | `nq3 nl2 lr0.05` | exact |
| `backtest` | `oracle_beats_bh` | `1` | exact (forced — perfect-foresight identity) |
| `backtest` | `oracle_final_equity` | `1.6126` | ±1e-3 |
| `backtest` | `causal_beats_bh_oos` | `1` | exact (regime estimated from past bars only) |
| `backtest` | `control_beats_bh_oos` | **`0`** | exact (a `1` means look-ahead leaked) |
| `timegan` | `e_loss0_improved` | `1` | exact |
| `timegan-qcbm` | `e_loss0_improved` | `1` | exact |
| `help` | lists `qcbm`…`backtest` | — | — |

> The subcommand outputs reuse the per-model logic validated in §5.5–§5.11.
> Bundling `quantum-finance` into the stripped binary-only dist
> (`scripts/release/build-dist.sh`, item 0b) is the remaining packaging step
> (plan 9.3); the per-OS dist build/test runs on its own box.

### 5.13 quantum-finance `xauusd` — real XAUUSD daily data (Phase 9, requires libtorch)

End-to-end on **real market data**: the committed lake-export fixture
`examples/data/xauusd_1d.csv` (XAUUSD daily, 5462 bars, the file finance_lab's
GAN models train on) is loaded by `CsvOhlcvLoader` (`;`-delimited,
`YYYY.MM.DD HH:MM` dates), a trend regime is derived from a 20/50-day SMA
crossover (no lookahead — the regime at the *start* of each step picks that
step's position), and a "long the uptrend, flat the downtrend" strategy is
backtested against buy-and-hold. Fully deterministic: real prices in, no RNG.
CI stage 2 (loader parity) + stage 4 (CLI). The pure-Rust loader parity test
also runs with **no libtorch**:

```bash
# Loader parity (no libtorch, no Python) — shape + exact close anchors:
cargo test -q -p quantum-data --test xauusd_fixture   # 2 passed

source scripts/env.sh
cargo run -q -p quantum-finance -- xauusd examples/data/xauusd_1d.csv
```

| Output line | Expected | Tol | Meaning |
|-------------|----------|-----|---------|
| `n_bars` | `5462` | exact | daily bars in the fixture |
| `close_first` | `384.100` | ±1e-3 | first bar Close (source value) |
| `close_last` | `4246.310` | ±1e-3 | last bar Close (2025-12-01) |
| `exposure` | `0.5691` | ±1e-3 | fraction of days long (in uptrend) |
| `bh_final_equity` | `11.0552` | ±1e-3 | buy-and-hold equity (gold ~11× over span) |
| `bh_max_dd` | `0.4464` | ±1e-3 | buy-and-hold max drawdown |
| `strat_final_equity` | `3.8512` | ±1e-3 | trend strategy equity |
| `strat_max_dd` | `0.3375` | ±1e-3 | trend strategy max drawdown |
| `strat_lower_dd` | `1` | exact | **trend strategy cuts drawdown vs B&H** |

> **Honest result, not a cherry-pick.** Over a secular gold bull (384 → 4246,
> ~11× buy-and-hold), a long/flat trend filter that sits out ~43% of days does
> **not** beat buy-and-hold on total return or Sharpe — but it materially
> **reduces max drawdown** (0.4464 → 0.3375). The committed gate asserts the
> true property (`strat_lower_dd 1`) plus the exact data anchors; it does not
> claim the strategy "wins". Swapping in a different CSV (e.g. an AAPL/GOOGL
> lake export) reuses the same path: `xauusd <other.csv>`.

### 5.14 Regime labeling — features + Gaussian HMM (Phase 13)

The first true-1:1 roadmap phase (FINANCE_LAB_PORT_PLAN §4b). Two layers:

**(a) Pure-Rust parity (no libtorch, no Python).** `quantum_data::features`
reproduces finance_lab's `input_features` (logret/range/atr/rv/mom, exact pandas
rolling semantics) and `quantum_data::hmm` ports the StandardScaler + full-cov
Gaussian-HMM labeler. Golden fixtures minted offline by
`tests/golden/gen_features_golden.py` and `gen_hmm_golden.py` (numpy/pandas +
hmmlearn). CI stage 2.

```bash
cargo test -q -p quantum-data --test features_parity   # 1 passed (≤1e-10 vs pandas)
cargo test -q -p quantum-data --test hmm_parity         # 1 passed (scaler exact + dist)
```

| Check | Expected | Tol |
|-------|----------|-----|
| feature rows kept (XAUUSD) | `5438` | exact |
| feature first/last row + col sums/means vs pandas | — | ≤1e-10 |
| StandardScaler mean/std vs sklearn | — | ≤1e-10 |
| regime population fractions vs hmmlearn | within `0.12` | — |
| per-step label agreement vs hmmlearn | `> 0.55` (≈0.60) | — |

> **Honest scope.** The scaler is **exact** and the regime *distribution*
> matches hmmlearn; per-step label agreement is ≈0.60 (vs 0.33 chance) because
> hmmlearn seeds means with sklearn-KMeans and lands a different EM optimum —
> mostly disagreeing on the ambiguous mid-vol regime. Exact-segmentation parity
> is a documented deferred gate (plan §4d), not a silent gap.

**(b) End-to-end CLI** (`quantum-finance`, requires libtorch). Deterministic
(seeded EM) regime labels + beliefs on real XAUUSD. CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- regime-gen examples/data/xauusd_1d.csv
cargo run -q -p quantum-finance -- regime-gen examples/data/xauusd_1d.csv out.csv  # writes labels+beliefs
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `n_rows` | `5438` | exact |
| `regime0_frac` (low vol) | `0.4994` | ±1e-3 |
| `regime1_frac` (mid vol) | `0.3174` | ±1e-3 |
| `regime2_frac` (high vol) | `0.1832` | ±1e-3 |

> Regime fractions are deterministic (seeded EM), so they double as exact
> regression anchors. Other `--method` choices (`pca_kmeans`, `vol_term`, `kde`,
> `spectral`, `autoencoder`) are registered as could-be-added in plan §4d.

### 5.15 Classifier ansätze — QCNN + readout modes (Phase 12)

Completes the QNN classifier circuit topologies (FINANCE_LAB_PORT_PLAN §4b
Phase 12). The **QCNN** classifier (`quantum_qml::QcnnClassifier`): encoder →
AngleEmbedding(Y) → `pool_steps` × [conv across adjacent pairs, pool away the
upper half] → readout on the surviving wires → head. Conv/pool are the shared
Phase-0.5 primitives, so the quantum block is **bit-identical** to the
standalone `qcnn_circuit` (PennyLane-parity-tested ≤1e-12). Readout modes
(`Readout` enum): `Z`, `Z+ZZ`, `Z0`.

```bash
source scripts/env.sh
cargo test -q -p quantum-qml --lib qcnn_classifier -- --test-threads=1        # 5 passed
cargo test -q -p quantum-qml --lib amplitude_classifier -- --test-threads=1   # 2 passed
cargo run -q -p quantum-qml --example qcnn_classifier_demo
cargo run -q -p quantum-qml --example amplitude_classifier_demo
```

| Check | Expected | Tol |
|-------|----------|-----|
| QCNN quantum block vs `qcnn_circuit` primitive (statevector) | identical | ≤1e-10 |
| survivors after `pool_steps` (n=8, steps=1) | `[0,2,4,6]` | exact |
| `Readout` output counts (Z / Z+ZZ / Z0 on 4 wires) | `4 / 7 / 1` | exact |
| demo: QCNN learns 3-class blobs | `loss_improved 1`, `acc_above_chance 1` (train_acc 1.0) | — |
| Amplitude: zero-weight readout vs pure amplitude-embedded state | identical | ≤1e-10 |
| demo: amplitude classifier learns 3-class blobs (n_qubits 3, 24 weights) | `loss_improved 1`, `acc_above_chance 1` (train_acc 1.0) | — |

> **Honest scope.** Wired: the **QCNN** ansatz (12.1), the `Readout` enum
> `{Z, Z+ZZ, Z0}` (12.3), and the **amplitude-embedding** classifier (12.2 —
> Möttönen `AmplitudeEmbedding` → ring IsingZZ+Rot → Z+ZZ → head; data baked as
> concrete amplitudes, ansatz weights baked + param-shifted per eval). The
> mid-circuit-measure path (12.4) and wiring the CLI `qnn-pqc`/`qnn-amp` choices
> to these ansätze (a Phase-17 trait-object on the regime-classify QNN branch)
> are registered as could-be-added (§4d).

### 5.16 Regime classifier — supervised DNN / QNN (Phase 14)

The supervised classifier surface (FINANCE_LAB_PORT_PLAN §4b Phase 14). Trains a
classical **DNN** (or the **QNN** rich-ansatz classifier) on the regime labels
from §5.14, with a train-only StandardScaler (no leakage), causal
train/val/test split, accuracy + macro-F1 metrics, and class-weighted CE.

**(a) Pure-Rust building blocks (no libtorch).** `quantum_data::metrics`
(`accuracy`, `confusion_matrix`, `macro_f1` — sklearn `zero_division=0`
convention) and `quantum_data::split` (`time_ordered_split`, `stratified_split`,
`balance_train`). CI stage 2.

```bash
cargo test -q -p quantum-data --lib metrics   # macro_f1 vs hand-computation ≤1e-8
cargo test -q -p quantum-data --lib split      # causal/stratified/balance invariants
```

**(b) End-to-end CLI + cross-language parity** (`quantum-finance`, libtorch).
The DNN must land within **5 percentage points** of a scikit-learn
`MLPClassifier(128,128)` golden, and the pure-Rust GBDT within 5pp of a
`GradientBoostingClassifier(100,d3)` golden — same labeled fixture, same split,
same scaler. Goldens minted offline by `tests/golden/gen_classifier_golden.py`
(sklearn) → `golden_classifier.json` + `golden_boosting.json`; **zero Python at
test time**. CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- regime-classify train --model dnn
cargo run -q -p quantum-finance -- regime-classify train --model gbdt   # xgb/lightgbm alias
cargo run -q -p quantum-finance -- regime-classify train --model qnn-rich --qnn-max-rows 200  # gate: prints `qnn_max_rows 200` (never silent) + acc/f1; no golden — the QNN preset is row-capped, see Honest scope
cargo run -q -p quantum-finance -- regime-classify train --model qfeat_xgb   # quantum-feature boosting (§4d wired): DNN 64-d embedding → GBDT
cargo run -q -p quantum-finance -- regime-classify train --model pqc_xgb     # amplitude-PQC ⟨Z⟩ (5-d) → GBDT, ~3 min (param-shift training)
cargo run -q -p quantum-finance -- regime-classify train --model qfeat_xgb --qfeat-mutate zeros   # negative control: Z zeroed after extraction
cargo test -q -p quantum-finance --test regime_classify_parity   # 5 passed (DNN, GBDT, pqc_xgb, qfeat_lightgbm, negative control) ~4 min
```

| Output line / check | Expected | Tol |
|---------------------|----------|-----|
| `n_train n_val n_test` (causal split) | `3806 / 544 / 1088` | exact |
| DNN `val_acc` / `test_acc` / `test_macro_f1` | `0.9210 / 0.9393 / 0.9033` (golden `0.9063 / 0.9375 / 0.9181`) | within 5pp |
| GBDT `val_acc` / `test_acc` / `test_macro_f1` | `0.9026 / 0.9366 / 0.9116` (golden `0.9026 / 0.9393 / 0.9158`) | within 5pp |
| DNN / GBDT determinism (seeded) | identical across runs | exact |
| `qfeat_xgb`: `feature_map dnn`, `z_dim 64`, `aug_dim 69`, `gbdt_backend pure-rust` | exact | exact |
| `qfeat_xgb` `val_acc` / `test_acc` / `test_macro_f1` | `0.9062 / 0.9292 / 0.8924` | within 5pp |
| `qfeat_xgb` **wiring**: `z_test_abs_mean` / `gbdt_splits_on_z` | `0.625038` / `1596` (of 1990) | ±0.05 abs / ±25% |
| `pqc_xgb`: `feature_map amplitude`, `z_dim 5`, `aug_dim 10` | exact | exact |
| `pqc_xgb` `val_acc` / `test_acc` / `test_macro_f1` | `0.8971 / 0.9357 / 0.9072` | within 5pp |
| `pqc_xgb` **wiring**: `z_test_abs_mean` / `gbdt_splits_on_z` | `0.380233` / `401` (of 1984) | ±0.05 abs / ±25% |
| `--qfeat-mutate zeros` (negative control) | `z_test_abs_mean 0.000000`, `gbdt_splits_on_z 0`, `test_acc` still ≈0.93 — accuracy alone would **not** catch a severed wiring; the two wiring probes do | exact |

> **Honest scope.** Wired: `dnn`, `qnn{,-toy,-rich,-pqc}`, boosting
> `gbdt`/`xgb`/`lightgbm` (a pure-Rust Friedman GBDT — *not* bit-exact to
> XGBoost/LightGBM, but a faithful functional 1:1, gated within 5pp of sklearn's
> GBDT), and **quantum-feature boosting** `pqc_{xgb,lightgbm}` (amplitude PQC
> ⟨Z⟩ readouts, 5-d) / `qfeat_{xgb,lightgbm}` (DNN penultimate embedding, 64-d)
> → concatenated onto the 5 raw features → the same GBDT. The QNN presets share
> the Phase-5 rich ansatz (distinct toy/QCNN/amplitude *circuits* are Phase 12);
> the param-shift forward is heavy, so QNN runs cap rows (`--qnn-max-rows`,
> reported never silent). The `pqc_*`/`qfeat_*` goldens were minted from the
> Rust binary itself (finance_lab has no committed numbers for these arms) —
> the gate is therefore a *wiring + regression* gate, not a cross-language one.
> `catboost` → "unsupported (no Rust backend)"; `tabpfn*` → "unsupported
> (pending Rust lib; `tabpfn` Cargo feature)" (§4c). Walk-forward CV objective is
> the Phase-16 surface.

**GPU (Phase 18.1).** The DNN is device-wired — build `--features cuda` and pass
`--device cuda` to run on `Device::Cuda(0)`; CI stage 4c2 gates it (GPU box).
The `bench-device` subcommand measures CPU vs CUDA → `benchmarks/finance-device.md`.
**The ratios are box-specific — re-measure, do not quote these.** At the finance
size the two are within noise of each other and which one wins depends on the
GPU; the CUDA advantage only appears at the large size:

| Box | finance size | large size |
|---|---|---|
| (earlier box, as originally documented) | CPU 5.1× faster | CUDA 2.27× |
| RTX PRO 6000 Blackwell (2026-08-30) | CUDA 1.05× (1126.8 vs 1179.3 ms — a tie) | CUDA **10.33×** (287.2 vs 2965.9 ms) |

CPU remains the default because it is the measured-correct one at the finance
size on every box tested; the check here is that the command runs and emits both
columns, not any particular ratio.

```bash
cargo build -p quantum-finance --features cuda
./target/debug/quantum-finance regime-classify train --model dnn --device cuda   # device Cuda(0)
./target/release/quantum-finance bench-device --out benchmarks/finance-device.md
```

**Metal / MPS (macOS).** `--device metal` resolves to `Device::Mps` when
libtorch can allocate on it, else falls back to CPU — and the `device` line
reports which one actually ran, so **read it rather than trusting the flag**.
This is worth checking explicitly: `parse_device` used to match only
`cuda`/`gpu`, so `--device metal` fell through to `Device::Cpu` and trained on
the CPU while the mac-metal bundle's docs claimed the Apple GPU.

```bash
./target/debug/quantum-finance regime-classify train --model dnn --device metal
./target/debug/quantum-finance regime-classify train --model dnn --device cpu
```

| Flag | Expected `device` line | Test accuracy | Tol |
|------|------------------------|---------------|-----|
| `--device metal` (on an MPS-capable mac) | `device Mps` | `0.9311` | ±0.02 |
| `--device cpu` | `device Cpu` | `0.9393` | ±0.02 |

The two accuracies differ slightly and should: MPS float32 arithmetic is not
bit-identical to CPU. A `--device metal` run that prints `device Cpu` on a mac
means the fallback fired — the flag is not silently ignored, but the GPU did
not run.

### 5.17 TimeGAN post-hoc metric nets (Phase 15)

Hardens the soft TimeGAN convergence gates (plan 2.4/3.7/4.5). Two post-hoc
metric nets (`quantum_qml::models::{discriminative_score, predictive_score}`),
faithful ports of `Conditional_TimeGAN_Pytorch/metrics/`:
* **Discriminative** — GRU(D→D/2)→Linear→sigmoid real/synthetic classifier
  (BCE, Adam 1e-3); score = `|0.5 − test_acc|`, **lower = better**.
* **Predictive (TSTR)** — GRU(D−1→D/2)→Linear(1) one-step predictor trained on
  **synthetic**, MAE on **real**; **lower = better**.

The hard gate: the TimeGAN's synthetic output must beat a noise baseline under
**both** metrics. Deterministic (seeded init + seeded batch sampler).

```bash
source scripts/env.sh
cargo test -q -p quantum-qml --lib metric_nets -- --test-threads=1   # 2 passed (separability)
cargo run  -q -p quantum-qml --example timegan_eval_demo
cargo run  -q -p quantum-finance -- timegan-eval                     # shipped binary
```

| Output line | Expected | Tol |
|-------------|----------|-----|
| `disc_synth` (TimeGAN) vs `disc_noise` | mac `0.1500` / linux `0.2000` < `0.5000` | **the `<` ordering** is the gate (per-OS golden) |
| `pred_synth` (TimeGAN) vs `pred_noise` | mac `0.0422` / linux `0.0372` < `0.2683` | **the `<` ordering** is the gate (per-OS golden) |
| `synth_beats_noise` | `1` (better on both metrics) | exact |
| unit: identical-data disc score | `< 0.25` | property |
| unit: noise-trained predictive MAE > real-trained | true | property |

> **Honest scope.** The metric nets + the synthetic-beats-noise hard gate are
> wired and deterministic. Exact cross-language **within-10%** value parity vs a
> committed Python (torch/TF) reference run (plan 15.4) is registered as a
> deferred deeper gate (§4d) — it needs a torch+tensorflow reference env, and
> the extreme-case scores (≈0.5 noise, ≈0 identical) are the robust anchors. The
> `{train,generate,eval}` sub-verb layout is Phase 17; here the metric is reached
> via `timegan-eval` + the library API.

### 5.18 Architecture search — TPE + walk-forward macro-F1 (Phase 16)

The full hyperparameter-search surface (FINANCE_LAB_PORT_PLAN §4b Phase 16).
A pure-Rust **categorical TPE** sampler (`quantum_data::TpeSampler`, the Optuna
replacement) drives `arch-search finetune`; the objective is **macro-F1**
averaged over an **expanding walk-forward** CV of the regime dataset. Model
axes: `mlp` (Phase-14 DNN) and `gbdt`/`xgb` (pure-Rust GBDT). CSV trial dump.

**(a) TPE sampler (pure Rust, no libtorch).** CI stage 2.

```bash
cargo test -q -p quantum-data --lib tpe   # 3 passed
```

| Check | Expected | Tol |
|-------|----------|-----|
| TPE locates the peak region on a 4×4 objective | best score ≥ −1 | property |
| TPE hits the exact optimum across seeds | ≥6/8 seeds | property |
| TPE mean trial score > random search | true | property |
| TPE deterministic (seeded) | identical | exact |

**(b) End-to-end CLI** (`quantum-finance`, libtorch). CI stage 4.

```bash
source scripts/env.sh
cargo run -q -p quantum-finance -- arch-search finetune --model gbdt \
    --n-trials 6 --walk-folds 2 --max-rows 1200 --out-csv arch.csv
cargo run -q -p quantum-finance -- arch-search trainonce --model gbdt   # gate: prints `macro_f1` (0.8543 here) — a single fixed-params run, no search, so no golden; it exists to show the objective is reachable without TPE
cargo run -q -p quantum-finance -- arch-search finetune --model mlp --n-trials 4
```

| Output line / check | Expected | Tol |
|---------------------|----------|-----|
| GBDT `selected` (best > mean + 1 sd of the trials) | `1` | exact |
| MLP `selected` | **not gated** — with `--model mlp --n-trials 4` the spread is wider (best 0.8686, mean 0.8377, sd 0.0428 ⇒ threshold 0.8805 > best) so `selected 0` is the arithmetically correct result, not a failure | — |
| `sd_macro_f1` | printed | — |
| GBDT `best_macro_f1` | `0.8830` (≥ 0.85) | exact (seeded) |
| GBDT `best_params` | `n_estimators=80 max_depth=2 lr=0.2` | exact (seeded) |
| CSV rows | `--n-trials` | exact |
| determinism (rerun) | identical best | exact |

> **Honest scope.** Wired: TPE finetune + trainonce over `mlp`/`gbdt`, macro-F1
> walk-forward, CSV dump. `qnn` (param-shift search too costly), `res`,
> `catboost`, `tabpfn*` are surfaced as pending/unsupported (§4c/§4d). The
> `--study-name`/`--eval-seeds`/`--qubits {sweep,fix}` knobs are registered as
> could-be-added (§4d).

### 5.19 Conditional TimeGAN — `ctimegan` (Phase 11, part 1)

The conditional-generator core (FINANCE_LAB_PORT_PLAN §4b Phase 11). Faithful
port of `Conditional_TimeGAN_Pytorch/networks.py`'s `LearnableAlphaBeta` +
`ConditionalGenerator`, plus regime conditioning (`regime_vec_proj`):
the generator takes a per-sequence regime condition `c` and forms
`Zc = [α·Z ‖ β·c_rep]` (`α=softplus(a)+ε`, `β=softplus(b)+ε`, learnable) →
`sigmoid(fc(GRU(Zc)))`. Trained on the TimeGAN three-phase schedule.

```bash
source scripts/env.sh
cargo test -q -p quantum-qml --lib ctimegan -- --test-threads=1   # 2 passed
cargo run  -q -p quantum-finance -- ctimegan                      # shipped binary
cargo run  -q -p quantum-finance -- ctimegan-qcbm                 # QCBM-latent hybrid (11.6)
```

| Output line / check | Expected | Tol |
|---------------------|----------|-----|
| `e_loss0_improved` (autoencoder) | `1` | exact |
| `alpha_beta_positive` (softplus + ε) | `1` (α≈1.60, β≈0.37) | exact |
| `conditioning_effect` | mac `0.4418` / linux `0.4412` | **`> 1e-3`** is the gate (per-OS golden) |
| `gen_mean_regime0` vs `gen_mean_regime1` | mac `0.3940` vs `0.7038` / linux `0.3935` vs `0.7033` (tracks data bases 0.30 / 0.65) | **regime0 < regime1** is the gate (per-OS golden) |
| `conditioning_works` | `1` | exact |
| `ctimegan-qcbm`: `noise_dim` + `conditioning_works` (QCBM latent, 11.6) | `3`, `1` | exact |

> **Honest scope.** Part 1 wires `LearnableAlphaBeta` (11.1), the
> `ConditionalGenerator` (11.3), and regime conditioning via `regime_vec_proj`
> (subset of 11.2). Deferred (§4d): the full conditioning surface
> (`logret_proj`/`cond_sim`/`cond_norm`/`cond_drop`/`z_diversity`), the
> boundary-continuity losses (11.4), and scenarios/fan-chart numeric artifacts +
> `self_baseline`/Brownian baseline (11.5) — later Phase-11 parts. The
> `ctimegan_qcbm` QCBM-latent hybrid (11.6) is wired (`ctimegan-qcbm`); the
> cached-Z reuse schedule (`fix_z`/`z_refresh_*`) is a §4d follow-up.

### 5.20 finance run scripts + migration (Phase 17.3 / 17.4 / 17.5)

The 1:1 swap-in for finance_lab's `run_*.sh`, driving the shipped Rust CLI
(`examples/finance/`). The orchestrator `run_all.sh` runs each workflow with
numeric assertions and prints `RUN OK`. CI stage 4.

```bash
source scripts/env.sh
QF_BIN="$PWD/target/debug/quantum-finance" bash examples/finance/run_all.sh   # fast → RUN OK
QF_BIN="$PWD/target/debug/quantum-finance" RUN_FULL=1 bash examples/finance/run_all.sh  # + training
```

| Check | Expected | Tol |
|-------|----------|-----|
| `run_all.sh` (fast: qcbm + xauusd + regime) | `RUN OK:` | — |
| `run_backtest.sh` | `FIN OK: backtest (synthetic)` (close_last 1114.222) | exact |
| `run_regime.sh` | `FIN OK: regime` (n_rows 5438, val_acc ≥ 0.88) | numeric |
| `run_timegan.sh` (RUN_FULL) | `FIN OK: timegan` (synth_beats_noise 1) | exact |
| `run_ctimegan.sh` (RUN_FULL) | `FIN OK: ctimegan` (conditioning_works 1) | exact |
| `run_archsearch.sh` (RUN_FULL) | `FIN OK: arch-search` (best_f1 ≥ 0.85) | numeric |

The 1:1 command mapping (Python → Rust, flag-by-flag) + the unsupported/deferred
list is [`docs/finance-lab-migration.md`](../docs/finance-lab-migration.md).

**Dist bundling (17.4).** `scripts/release/build-dist.sh` ships
`bin/quantum-finance` + `examples/data/xauusd_1d.csv` + `examples/finance/*.sh`
+ the migration doc **when `LIBTORCH` is set** (the variant pairs with one); the
bundled `run.sh` then runs the `xauusd` numeric anchor (degrading to a skip if
libtorch is not on the verify host's path). The libtorch-free core dist builds
and verifies unchanged.

> **Honest scope.** Phase 17 wires the run scripts (17.3), the migration doc
> (17.5), and dist bundling of the finance binary (17.4). The `{train,generate,
> eval}` sub-verb *nesting* (17.1) and notebook rendering (17.6) are registered
> as could-be-added (§4d) — the current flat subcommands expose the same compute
> 1:1, and the migration table maps each Python command to them.

### 5.21 Quantum Circuit Architecture Search (QCAS_PLAN P1–P7)

The RBS (Givens) gate, the Kerenidis layouts (arXiv:2606.03517), and the
two-stage architecture search. Every number below is reproducible from the
seed alone — datasets, sampler, weight init, and the classical head are all
seeded explicitly, so repeated runs are byte-identical.

**Path dependency.** `quantum-qml` path-depends on `aria-tune` in the sibling
`../aria-quantum-language-oss` checkout. A path dep is **not** pinned by
`Cargo.lock`, so `ci.sh` asserts the checkout exists and prints its git sha
(and whether it is dirty) as the first line of the run — that recorded sha is
the pin. Without the sibling, `quantum-qml` will not build.

```bash
source scripts/env.sh
```

#### 5.21a RBS gate + layout parity — **from the stripped dist binary**

Per the working rules, the manual proves the *shipped artefact*. `quantum rbs`
is in the binary-only dist, so this runs against the stripped binary:

```bash
case "$(uname -s)" in Darwin) V=mac-cpu ;; Linux) V=linux-cpu ;; esac
./scripts/release/build-dist.sh cpu                       # → dist/quantum-dist-$V-<sha>.tar.gz
mkdir -p /tmp/distcheck && tar xzf "$(ls -t dist/quantum-dist-$V-*.tar.gz | head -1)" -C /tmp/distcheck
/tmp/distcheck/dist-$V/bin/quantum rbs --layouts
```

| Check | Expected (dist / release) | Tol |
|-------|--------------------------|-----|
| `rbs_inverse_err` (RBS(θ)·RBS(−θ) = I) | `0.000e0` … `2.220e-16` (1 ULP, per-arch — see note) | ≤ 1e-10 |
| `rbs_unitary_err` (RBS†·RBS = I) | `0.000e0` … `2.220e-16` (1 ULP, per-arch — see note) | ≤ 1e-10 |
| `rbs_weight_err` (Hamming weight preserved) | `0.000e0` | ≤ 1e-10 |
| `rbs_block_err` (exact Givens block on span{\|01⟩,\|10⟩}) | `0.000e0` | ≤ 1e-10 |
| `rbs_layout_err` (depth = log₂n, p(n)=2p(n/2)+n/2, perfect matchings) | `0.000e0` | exact |
| `rbs_parity_max_err` | `0.000e0` … `2.220e-16` (1 ULP, per-arch) | ≤ 1e-10 |
| `rbs_parity_ok` | `1` | exact |
| `layout_params n4` | `butterfly 4 pyramid 6 x 5 brick4 6` | exact |
| `layout_params n8` | `butterfly 12 pyramid 28 x 13 brick4 14` | exact |
| `layout_params n16` | `butterfly 32 pyramid 120 x 29 brick4 30` | exact |
| `butterfly_depth_n8` | `3` | exact |

> **The last ULP is arch-dependent; only the ≤1e-10 gate is portable.** On
> **aarch64/macOS** the stripped release binary reports `2.220e-16` for the two
> matrix-product identities where the debug build reports exactly `0.000e0` —
> release FMA contraction reassociates the 4×4 products. On **x86-64 Linux**
> the stripped release artefact reports `0.000e0` on every line (measured
> 2026-08-30 from `dist-linux-cpu`, `file` confirms `stripped`), because the
> baseline x86-64 target does not enable FMA contraction. Both are ~15 orders
> inside the 1e-10 gate, so treat any value in `[0, 2.3e-16]` as a pass and do
> not gate on the digits. `cargo run -q -p quantum-core --example rbs_parity`
> (CI stage 2f, debug) prints `0.000e0` everywhere on both platforms.

The layout counts are the paper's closed forms: butterfly `(n/2)·log₂n`,
pyramid `n(n−1)/2`, X `2n−3`.

#### 5.21b Architecture search demo (P6)

```bash
cargo run -q --release -p quantum-qml --example qcas_demo
```

Release matters only for wall clock (~70 s vs ~10× in debug); the numbers are
identical because everything is seeded.

| Check | Expected | Tol |
|-------|----------|-----|
| `qcas_best_acc` | `0.8889` | ≥ 0.85 |
| `qcas_best_minus_mean` | `0.0235` | ≥ 0.02 |
| `qcas_pruned` | `11` | ≥ 1 |
| `qcas_unique_descriptors` | `21` (of 24 trials) | ≥ 1, ≤ trials |
| `qcas_best_key` | `AngleY\|LowEntangleZ { brickwall: true }\|ZPlusZZ\|n8\|l1` | exact |
| `qcas_acc_ok` / `qcas_beats_mean_ok` / `qcas_pruned_ok` | `1` / `1` / `1` | exact |
| two invocations | byte-identical output | exact |

`qcas_pruned` counts **in-loop** early stops, not retrospective verdicts: a
prune halts training on the spot. The wall clock is the witness — the same
search with retrospective pruning took 101 s, with in-loop pruning 71 s.
`qcas_unique_descriptors` counts distinct architectures *proposed after
repair*, so "24 trials" cannot hide a handful of architectures re-evaluated.

#### 5.21c `arch-search --model qnn` (P6, closes P16 §4d)

Circuit-architecture search on the XAUUSD regime features. Two-stage: the
architecture is chosen on one fast holdout split, then scored with the same
expanding walk-forward macro-F1 every other `--model` reports.

CI-sized config (~36 s) — this is the gated one:

```bash
cargo run -q --release -p quantum-finance -- arch-search finetune \
  --model qnn --n-trials 6 --walk-folds 2 --qnn-steps 6 --max-rows 200
```

| Check | Expected | Tol |
|-------|----------|-----|
| `best_macro_f1` | `0.6069` | ≥ 0.5769 (first measured − 0.03) |
| `best_arch` | `UnaryRy { magic_init: false }\|RichZZ { ring: true }\|ZFirstLast\|n8\|l2` | exact |
| `baseline_macro_f1` (majority-class) | `0.2290` | ±1e-3 |
| `selected` (best_macro_f1 > baseline) | `1` | exact |
| two invocations | identical `best_*` / `selected` | exact |

Full-scale config (~8 min 33 s, **not** gated in CI — too slow):

```bash
cargo run -q --release -p quantum-finance -- arch-search finetune \
  --model qnn --n-trials 12 --walk-folds 3 --qnn-steps 20
```

| Check | Expected | Tol |
|-------|----------|-----|
| `best_macro_f1` | `0.8286` | ≥ 0.80 |
| `best_arch` | `UnaryRy { magic_init: false }\|StronglyEntangling { range: None }\|ZAll\|n8\|l1` | numeric |

Both configs independently select `UnaryRy` loading — the Kerenidis unary
encoding, chosen on merit against `AngleY` and `HadamardInit`.

#### 5.21d Gradient correctness (P2)

The four-term Givens rule. The ±π/2 two-term rule is **wrong** for RBS
(generator spectrum {0,0,±1} → frequencies {1,2}), and one test asserts it is
measurably wrong so the dispatch cannot be "simplified" away.

```bash
cargo test -p quantum-core --quiet circuits::rbs::
cargo test -p quantum-qml --quiet -- --test-threads=1 gradients:: parallel_shift:: adjoint::
```

| Check | Expected | Tol |
|-------|----------|-----|
| RBS shift vs central finite difference (butterfly-8, pyramid-6) | agree | ≤ 1e-6 |
| RBS shift vs `TensorAdjoint` | agree | ≤ 1e-8 |
| parallel commuting-block vs serial four-term | agree | ≤ 1e-10 |
| trailing coupling layer executions | 1 (vs 16 serial) | exact |
| two-term rule vs true RBS gradient | **differs** | > 1e-3 |
| frozen params under a freeze mask | delta exactly `0.0` | exact |

> **Honest scope.** `Encoding::Amplitude` encodes **magnitudes only** — carrying
> signs would add a phase-`RZ` tree whose *presence* depends on the sample,
> making the gate structure data-dependent and breaking positional parameter
> binding. `qcnn_neck`'s pool is not literally `CRY(θ)`: a true controlled
> rotation ties its halves to ±θ/2, which positional binding cannot express, so
> the halves are independent (a strict generalisation). The `GatePruner` slope
> gate is disabled in `qcas_search` because the reported value is validation
> accuracy, quantised to 1/n_val — slope belongs on a smooth loss.

---

## 6. CI pipeline (`./scripts/ci.sh`)

Single command runs all 13 stages (`TOTAL=13` in `scripts/ci.sh`). Stages without their tool installed
print `⊘ skipped` (yellow) instead of failing red.

```bash
./scripts/ci.sh                       # stages 1–13 (12 and 13 self-skip unless opted in)
QUANTUM_MATHLIB=1 ./scripts/ci.sh     # also stage 11 (mathlib build)
```

> **Activate the project venv first.** Stage 5 (`quantum-py`) links PyO3,
> which rejects Python newer than 3.13. A bare shell whose `python3` is a
> newer system/Homebrew Python (e.g. 3.14) fails stage 5. Use the project
> `.venv` (Python ≤3.13) per §2/§3.1 — `source .venv/bin/activate` — before
> `./scripts/ci.sh`. (ci.sh self-configures libtorch/DYLD, but not the venv.)

| Stage | What | Required dep |
|-------|------|--------------|
| 1 | `cargo fmt` over this workspace's 8 crates (**not** `--all` — that reaches into the sibling repo) | Rust |
| 2 | `cargo test -p quantum-core` | Rust |
| 3 | `cargo test -p quantum-core --test macro_test` | Rust |
| 4 | `cargo test -p quantum-qml` | libtorch |
| 5 | `cargo check -p quantum-py` | libtorch |
| 6 | WASM guests `vqe/qaoa/ecc` (`cargo build --target wasm32-wasip1`) | wasm32-wasip1 target |
| 7 | Rust example smoke (41 examples) + bench compile + Lean spec-extract CLI smoke + editor-plugin JSON/JS smoke | Rust (+ node for 7d) |
| 8 | `cargo clippy` (warnings allowed, non-fatal) | Rust |
| 9 | Lean4 standalone (`Standalone.lean` → 23 thms; `Generated_Closed.lean` → Bell/DJ/GHZ) | Lean |
| 10 | Rocq (`QLibCompat.v`, `Gates.v`, `QFT.v`, `Grover.v`) | Rocq |
| 11 | Lean4 mathlib (`lake build QuantumProofs`) — opt-in, needs `QUANTUM_MATHLIB=1` | Lean + mathlib oleans |
| 12 | QML benchmark regression gate vs `docs/bench-baselines/` — opt-in, needs `QUANTUM_BENCH=1` (else `⊘ skipped`) | libtorch |
| 13 | Scaling-QML large-n gate (IQP Born machine at n=64, loss must decrease monotonically) — opt-in, needs `QUANTUM_SCALE=1` (else `⊘ skipped`) | libtorch |

**Stage 9 expected output:**

```
✓ 23 Lean4 theorems verified
✓ Generated_Closed: bell + DJ + GHZ closed-form proofs verified
```

**Stage 11 expected output:** `✓ mathlib-backed proofs compile (QuantumProofs root sorry-free)`.
(It used to read `(sorries expected)`.) The `QuantumProofs` root is now **sorry-free**
(`live_sorries 0`, verified in §8.2); the 8 sorries that message refers to were
all closed. `lake build QuantumProofs` must still succeed.

**Stage 11a-all: whole-corpus axiom gate.** The hand-listed `#print axioms`
blocks only name theorems they already know. `proofs/lean4/scripts/AxiomGate.lean`
walks every theorem in the `QuantumProofs` environment, so a new proof file
is covered with no extra entry. Needs a warm mathlib cache (`./scripts/setup-mathlib.sh`).

```bash
cd proofs/lean4 && lake env lean scripts/AxiomGate.lean 2>&1 | grep 'AXIOM-GATE'
# expect exactly one line: ... AXIOM-GATE theorems=807 modules=37 sorryAx=0
# PASS iff sorryAx=0 AND theorems >= 807 (floor pinned in ci.sh as AXIOM_GATE_MIN_THEOREMS)
```

**Stage 11a-closure: no unrooted modules.** The env walk only sees what the
`QuantumProofs` root transitively imports; a hand-written file nobody imports
is invisible to it (HGadget was exactly that until 2026-09-29). This check
enumerates `proofs/lean4/QuantumProofs/*.lean` (and every `.lean` in its
subdirectories) on disk and requires every non-`Generated/`
module to be in the root's import closure. `Generated/` (13 emitter stubs, `sorry`
by design) is exempt and built as explicit targets in 11b/11c.

```bash
cd proofs/lean4 && python3 - <<'EOF'
import re, os, glob
disk = sorted(p[:-5].replace('/', '.') for p in glob.glob('QuantumProofs/**/*.lean', recursive=True))
seen, q = {'QuantumProofs'}, ['QuantumProofs']
while q:
    m = q.pop(); f = m.replace('.', '/') + '.lean'
    if not os.path.exists(f): continue
    for d in re.findall(r'^import (QuantumProofs[\w.]*)', open(f).read(), re.M):
        if d not in seen: seen.add(d); q.append(d)
un = [m for m in disk if m not in seen and not m.startswith('QuantumProofs.Generated.')]
print("non-generated on disk:", sum(not m.startswith('QuantumProofs.Generated.') for m in disk), "unrooted:", len(un), un)
EOF
# expect: non-generated on disk: 38 unrooted: 0 []
# Negative control: `sed -i '/^import QuantumProofs.HGadget$/d' QuantumProofs.lean`
# → unrooted: 1 ['QuantumProofs.HGadget'] and ci.sh stage 11 FAILs; restore with git checkout.
```

---

## 7. Examples, benchmarks, WASM guests

### 7.1 Rust examples

```bash
# No libtorch:
cargo run -p quantum-core --example shor
cargo run -p quantum-core --example qft_qpe
cargo run -p quantum-core --example block_encoding

# Needs libtorch:
source scripts/env.sh
cargo run -p quantum-qml --example qml_classifier
```

Selected expected outputs (sanity checks):

| Example | Expect |
|---------|--------|
| `shor` | `15 = 3 x 5`, `21 = 3 x 7`, `35 = 7 x 5` |
| `qft_qpe` | QFT QASM output, QPE circuit for T gate |
| `qml_classifier` | Training accuracy ~94% |
| `vqe` (in `quantum-qml`, not `quantum-core`) | `Final energy: -1.834201 Ha` vs `Exact energy: -1.851199 Ha`; `vqe_variational_ok 1`, `vqe_converged_ok 1` |
| `aria_grover` | 2q 100%, 3q **94.5%** success (exact: 2 iterations on 3 qubits, sin²(5·asin(1/√8))); Lean4 export header |
| `aria_qft` | QFT(n) >> QFT(n).inverse() gate counts before/after optimizer |
| `shor_ecdlp` | Gate counts ≥ 100 000, depth ~50 000 |
| `shor_ecdlp_secp256k1` | ~5M physical qubits at code distance 35 |

#### 7.1a MBQC resource comparison (item 11 A3.3 — numeric)

Gate-model vs measurement-pattern resource side-by-side for Bell, GHZ(3),
QFT(4), Toffoli. Every `SUMMARY` field is checked against a golden value.

```bash
OUT=$(cargo run -q -p quantum-core --example mbqc_resource_compare)
echo "$OUT" | grep -q "SUMMARY Bell: gates=2 qubits=2 | vertices=5 edges=4 layers=3 meas=3 nonclifford=0"    && echo "bell ok"
echo "$OUT" | grep -q "SUMMARY GHZ(3): gates=3 qubits=3 | vertices=8 edges=7 layers=5 meas=5 nonclifford=0"   && echo "ghz ok"
echo "$OUT" | grep -q "SUMMARY QFT(4): gates=12 qubits=4 | vertices=80 edges=94 layers=76 meas=76 nonclifford=18" && echo "qft ok"
echo "$OUT" | grep -q "SUMMARY Toffoli: gates=1 qubits=3 | vertices=31 edges=34 layers=28 meas=28 nonclifford=7"  && echo "toffoli ok"
```

**Expect:** `bell ok`, `ghz ok`, `qft ok`, `toffoli ok` (4 lines). The
vertex/edge/measurement counts are the exact `circuit_to_pattern` output;
`nonclifford` is the count of non-(π/2-multiple) measurement angles (the
MBQC T-count analogue).

#### 7.1b MBQC CLI (item 11 B6 — numeric)

`quantum mbqc <input>` compiles a circuit to an MBQC pattern and prints the
resource, the `optimize()`d resource, the deterministic-sim output norm, and
the UBQC δ-lattice invariant. Golden run on a Bell circuit:

```bash
printf 'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[2];\nh q[0];\ncx q[0],q[1];\n' > /tmp/bell.qasm
OUT=$(cargo run -q -p quantum-core --bin quantum -- mbqc /tmp/bell.qasm)
echo "$OUT" | grep -q "pattern vertices=5 edges=4 layers=3 measurements=3 nonclifford=0" && echo "pattern ok"
echo "$OUT" | grep -q "optimized vertices=3 layers=1 measurements=1"                     && echo "optimize ok"
echo "$OUT" | grep -q "output_norm=1.000000"                                             && echo "norm ok"
echo "$OUT" | grep -q "ubqc_on_lattice=3/3"                                              && echo "ubqc ok"
```

**Expect:** `pattern ok`, `optimize ok`, `norm ok`, `ubqc ok` (4 lines).
Bell compiles to 5 pattern vertices; `optimize()` cuts it to 3 (40%
reduction); the deterministic output is normalized; and all 3 UBQC δ angles
sit on the {kπ/4} lattice (Clifford circuit).

#### 7.1c MBQC conditional gates / teleportation (item 11 A1.5 — numeric)

`mbqc_conditional_demo` compiles a teleportation circuit (mid-circuit `Measure`
+ classically-conditioned Pauli corrections; Aria form `examples/aria/teleport.aria`)
to an MBQC pattern. The conditional Paulis on the terminal output become
`Pattern::output_corr` byproducts — A1.5 "classical control becomes a flow edge".

```bash
OUT=$(cargo run -q -p quantum-core --example mbqc_conditional_demo)
echo "$OUT" | grep -q "1 output byproduct(s)" && echo "byproduct ok"
echo "$OUT" | grep -q "^RUN OK: A1.5"          && echo "run ok"
```

**Expect:** `byproduct ok`, `run ok` (2 lines). The demo asserts internally
(non-zero exit on failure, so CI stage 7 gates it): over 64 sampled
trajectories the X/Z output Pauli fires **iff** its source measurement outcome
is 1, matching hand-applied `X^{s}`/`Z^{s}` on the output qubit ≤1e-12.

#### 7.1d MBQC Lean-spec export (item 11 C4.1/C4.2 — numeric)

`mbqc_spec_export` emits the Lean circuit↔pattern obligation for Bell + GHZ via
`spec::render_pattern_proof` (the `PatternD` literal + `U|+⟩^n` expected vector
from `simulate_pattern_deterministic` + the `native_decide` theorem).

```bash
OUT=$(cargo run -q -p quantum-core --example mbqc_spec_export)
echo "$OUT" | grep -q "def bell_pattern : PatternD"                     && echo "bell literal ok"
echo "$OUT" | grep -q "theorem ghz_pattern_correct : ghz_pattern_ok"    && echo "ghz theorem ok"
echo "$OUT" | grep -q "^RUN OK: MBQC pattern Lean export"               && echo "run ok"
```

**Expect:** `bell literal ok`, `ghz theorem ok`, `run ok` (3 lines). The example
asserts each emission is well-formed with a normalized `U|+⟩^n`; the emitted
`bell_pattern`/`ghz_pattern` literals match the CI-verified hand-written
obligations in `Generated_Closed.lean` (§8.1, stage 9b).

#### 7.1e Networked UBQC client/server (item 11 B6 follow-on — numeric)

The BFK '09 blind client and the executing server can run in **two processes**
over a socket (not just in-process). `quantum-server` gained stateful
`ubqc.reset`/`ubqc.message` methods; `quantum mbqc … --remote <addr>` drives the
client against it. The server only ever sees blinded `δ` angles.

```bash
printf 'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[2];\nh q[0];\ncx q[0],q[1];\n' > /tmp/bell.qasm
SOCK="/tmp/quantum-ubqc-$$.sock"
cargo run -q -p quantum-core --bin quantum-server -- --listen unix:"$SOCK" &
SRV=$!
for n in $(seq 1 50); do [ -S "$SOCK" ] && break; sleep 0.1; done
OUT=$(cargo run -q -p quantum-core --bin quantum -- mbqc /tmp/bell.qasm --remote unix:"$SOCK")
kill $SRV 2>/dev/null; rm -f "$SOCK"
echo "$OUT" | grep -q "ubqc_remote_on_lattice=3/3 recovered=3 protocol_version=1 server_max_register=20" && echo "remote ubqc ok"
```

**Expect:** `remote ubqc ok` (1 line). The networked run reproduces the
in-process δ-lattice invariant (§7.1b `ubqc_on_lattice=3/3`): all 3 blinded
angles land on `{kπ/4}` over the wire and all 3 outcomes `s = b ⊕ r` are
recovered. `protocol_version=1 server_max_register=20` is the B1.3
`ubqc.hello` handshake: the client declared the Bell pattern's dimensions
(5 vertices, 3 measurements) and the server accepted them under its
20-qubit register cap before any qubit was prepared. The hermetic TCP-loopback equivalent (no external process) is the
`ubqc_net` integration test in CI stage 2 (`cargo test -p quantum-core`).

#### 7.1f CV-MBQC cluster + GKP grid states (item 11 C2 / C2.4 — numeric)

The continuous-variable track is verified by unit tests in CI stage 2. To run
just those numeric checks:

```bash
cargo test -q -p quantum-core --lib -- mbqc::cv mbqc::gkp 2>&1 | tail -3
```

**Expect:** `test result: ok.` with **8 tests** (3 CV + 5 GKP). The CV tests
assert a cluster's nullifier variances equal `e^{−2r}/2` (≤1e-9) and vanish as
the squeezing `r→∞`; the GKP tests assert the finite-energy `|0⟩/|1⟩/|±⟩` grid
states are L²-normalised (≤1e-6), the position stabiliser `⟨cos(2√π q̂)⟩` matches
`e^{−πΔ²}` (≤5e-3) and → 1 as Δ→0, the logical `Ẑ = ⟨cos(√π q̂)⟩` separates the
sublattices (`+`/`−`/`≈0` on `|0⟩`/`|1⟩`/`|±⟩`), and `|+⟩` is a period-`√π` comb.

#### 7.1e′ Bacon–Shor subsystem code (QEC_PLAN §4c — numeric)

The first *subsystem* code in the tree (weight-2 gauge generators that do not
commute; stabilizers are their centre). Unit-tested in CI stage 2:

```bash
cargo test -q -p quantum-core --lib bacon_shor 2>&1 | tail -3                    # 9 tests
cargo test -q -p quantum-core --features omega-sim --lib bacon_shor 2>&1 | tail -3  # 10 tests
```

**Both must print `test result: ok.`** The counts differ on purpose and the
second command is not optional: the gauge-measurement row below runs backends,
so it is `#[cfg(feature = "omega-sim")]` and is **absent** from the 9-test
default run. Checking only the first command would leave the circuit-level
claim — the interesting one — untested.

What they pin numerically:

| Check | Value |
|---|---|
| distance at `n=3`, **brute-forced** over all 512 Z-supports | `3` (i.e. `[[9,1,3]]`) |
| stabilizer count / weight | `n−1` per sector, weight `2n` |
| gauge generator count | `n(n−1)` per sector, weight `2` |
| single-qubit errors corrected, `n=3,5` | all, row-identified |
| BP+OSD cross-check | agrees up to gauge, `n=3,5` |
| gauge measurement on backends | folded syndrome == algebraic, all errors |

The gauge row is the circuit-level one and the reason the code is interesting:
the stabilizers have weight `2n`, but the circuit **measures nothing above
weight 2**. It runs the `ZZ` gauge checks on real backends and XORs them into
the two-row stabilizer syndrome. Coverage is width-limited on purpose — the
circuit needs `n² + n(n−1)` qubits, i.e. 15 at `n=3` but **45 at `n=5`**, where
a dense statevector is `2^49` bytes and aborts the process. The circuit is pure
Clifford, so `n=5` runs on the stabilizer backend alone; `n=3` runs on
statevector + stabilizer + MPS (three backends, because a single simulator
agreeing with the algebra could still be a shared convention bug — this repo has
had exactly that, a measurement-key offset differing between statevector and
stabilizer/MPS).

Two of these are the load-bearing ones. The **distance** is computed by
enumeration, not asserted from the literature. The **BP+OSD cross-check** runs
the geometry-free `decode_css_sector`, which knows nothing about Bacon–Shor,
and requires agreement *up to gauge equivalence* — same syndrome, same row —
because this code is degenerate and demanding an identical qubit would be
wrong, not stricter.

There is also a negative test: transposing the two logicals (`X̄` as a full row
instead of a column) must FAIL, since a row of `X` overlaps a two-row `Z`
stabilizer in `n` qubits with `n` odd.

**From the shipped binary** — verified against the stripped **dist artefact**
(item 0b), not just `cargo run`: `quantum-dist-mac-cpu` at
`SOURCE_DATE_EPOCH=1700000000`, sha256
`d305c68920a14c5c96bd58cd5b9114aaab737a0ff69ff0f51d911228c79d2c23`, reproducible
(two builds, identical sha) and `VERIFY OK` (53 files, 0 toolkit source files
leaked). All three checks below reproduce from `dist-mac-cpu/bin/quantum`:

```bash
quantum ecc --code bacon-shor --distance 3
quantum ecc --code bacon-shor --distance 5     # 45 qubits -> stabilizer backend
```

**Expect** `bacon_shor_ok 1` from both, with:

| `--distance` | data | gauge gens | stabilizers | width | battery |
|---|---|---|---|---|---|
| 3 | 9 | 6, weight 2 | 2, weight 6 | 15 qubits | `9/9 corrected, 0 failed` |
| 5 | 25 | 20, weight 2 | 4, weight 10 | 45 qubits | `25/25 corrected, 0 failed` |

The backend defaults by width — statevector at `n=3`, stabilizer at `n≥5`. Both
print the degeneracy table, where every row must read `identical across all
columns`; a row reading `DIFFER (bug)` means the gauge folding broke.

**Only 3 and 5 are supported**, and the three refusals below are part of the
gate — each must exit **1**:

```bash
quantum ecc --code bacon-shor --distance 4                       # even
quantum ecc --code bacon-shor --distance 7                       # 91 qubits
quantum ecc --code bacon-shor --distance 5 --backend statevector # dense OOM
quantum ecc --code bacon-shor --distance foo                     # unparseable
```

| Input | Message | Why it must be refused |
|---|---|---|
| `--distance 4` | `needs odd --distance >= 3` | even `n` breaks the logical/stabilizer distinction |
| `--distance 7` | `needs 91 qubits … 64-bit key` | `syndrome_bits` packs outcomes into a `u64`; at 91 qubits the bits alias mod 64 and the syndromes are corrupt |
| `--backend statevector --distance 5` | `would allocate ~5.629e14 bytes` | 2⁴⁵ amplitudes = 512 TiB — aborts the process rather than erroring |
| `--distance foo` | `must be an integer` | silently defaulting to 3 would print a *successful* run for a bad input |

#### 7.1e″ Circuit-level 15-to-1 distillation acceptance (QEC_PLAN §4b — numeric)

`distill_monte_carlo` / `exact_acceptance` are exact *in the Pauli-error model*
but never build a circuit. These run the real stabilizer-measurement circuit —
`|+⟩^⊗15`, injected `Z`s, four weight-8 X-checks each read out through its own
ancilla — and require it to reproduce that acceptance.

```bash
cargo test -q -p quantum-core --features omega-sim --lib reed_muller 2>&1 | tail -3
```

**Expect** `test result: ok.` with **17 tests** (measured 2026-09-03, ~6 s on
linux-x86_64).

| Check | Value |
|---|---|
| weight-1 and weight-2 sweep | 15 + 105 patterns, backend syndrome == algebraic |
| single `Z` errors detected | **15/15** (distance 3 requires it) |
| gate-level acceptance, 600 rounds at `p=0.05` | matches `exact_acceptance(0.05)` = **0.466063**, tolerance 0.08 (≈4σ) |
| per-round cross-check | every one of the 600 rounds also compared to the algebra |

That last row is the point: an aggregate rate can come out right while
individual rounds are wrong, so each round is checked too. Acceptance must also
land in `(0.2, 0.8)` — a degenerate 0 or 1 would prove nothing.

`--features omega-sim` is required. Without it the run drops to **11** tests —
six are `omega-sim`-gated, including both gate-level ones — and still reports
`ok`, so the plain command looks like a pass while skipping the circuit entirely.
(Measured 2026-09-03: **17** with the feature, **11** without.)

The **`35p³` half is measured too**, by `distill_round_circuit`: a fifth ancilla
reads `X̄ = X^⊗15`, which on `|+⟩^⊗15` has eigenvalue `(−1)^{|e|}` and so reports
the logical class of every accepted round (among undetected patterns, logical ⟺
odd weight).

| Check | Value |
|---|---|
| output infidelity, 30000 rounds at `p=0.10` | matches `exact_output_infidelity(0.10)` = **0.04773** within 0.012 (≈4σ), and is required to sit **nearer the exact law than 35p³** |
| true distillation threshold | **0.141480**, *below* the quoted `1/√35 = 0.169031` |
| structural precondition | logical counts non-zero exactly at odd weights — asserted from the weight enumerator *before* any simulation |
| per-round `X̄` check | every round: `X̄` must equal `|e| mod 2` |
| must beat its input | `measured < p`, and `> 0` |

Two things deliberately **not** claimed:

* **Not circuit-level noise.** This is **code-capacity**: `Z` errors are injected
  on the inputs and the extraction circuit is then *ideal* — no faulty gates, no
  hook errors, no ancilla faults spreading through the CX chains. That matches
  the standard 15-to-1 analysis, so the numbers are comparable to the closed
  forms, but a faulty-gate model is a further step.
* **Not an end-to-end encoded-`|T⟩` factory.** The input is `|+⟩^⊗15`, the `+1`
  eigenstate of every X-type observable being read — the `T` supplies the magic,
  not the error propagation, which is why both halves are Clifford and 20 qubits.

**The threshold correction is worth its own line.** `1/√35 ≈ 0.169` solves
`35p³ = p`, but `35p³` is the `p → 0` limit and runs ~30% low at finite `p`.
Solving the *exact* law gives **0.141480**. In the band `0.1415 < p < 0.169` the
two disagree about whether distillation helps at all — at `p = 0.15` the cubic
says yes (`0.118 < 0.15`), the exact law says no (`0.167 > 0.15`), and the
**circuit reproduces the exact law** (0.16908 over 30k gate-level rounds). Found
because a test asserting `measured < p` at `p = 0.15` failed.

#### 7.1f′ Encoded QSVT matrix inversion (QEC_PLAN §6 P3 — numeric)

Runs the full chain: fit QSP angles for `1/x`, run that sequence on a
Steane-encoded logical qubit, invert a diagonal system, and check the answer
against an independent `A⁻¹b`. Self-checking (prints `[ok]`/`[FAIL]` per stage,
exits 1 on any failure) and gated in `ci.sh` **step 2**, next to the
`noise_to_precision` gate — both assert a zero exit *and* the banner, so an
example whose checks were silently deleted would still be caught.

`--release` is load-bearing: it fits degree-63 phases, ~20× slower in debug.

```bash
cargo run -q -p quantum-core --features omega-sim --release \
    --example qsvt_invert_encoded 2>&1 | tail -8
```

**Expect** the banner `QSVT-ENCODED OK — all checks passed`, no `[FAIL]`, and
these five numbers (deterministic — no RNG anywhere in this path):

| Stage | Quantity | Expected | Tolerance |
|---|---|---|---|
| 1 | angle-finder max rel error, κ=4 deg=63 `scale=1/(2κ)` | `7.304e-5` | `< 1e-3` |
| 2 | encoded ⟨Z̄⟩,⟨X̄⟩ vs the classical 2×2 | `~1e-13` (1.085e-13 on 2026-09-24) | `≤ 1e-9` |
| 3 | `‖y_qsvt − y_true‖ / ‖y_true‖` | `1.524e-5` | `< 1e-3` |
| 4 | `max abs(conj(U_Φ) − U_−Φ)` (LCU identity) | `0.000e0` | `≤ 1e-12` |
| 5 | `max abs(P_encoded − P_classical)` (Hadamard test) | `~3e-14` (3.186e-14 on 2026-09-24) | `≤ 1e-9` |
| 5 | inversion from **encoded numbers only**, κ=2 deg=12 | `4.033e-4` | `< 5e-2` |
| 6 | rel error at λ=0.05, outside `[1/κ,1]` | `1.206` | **`> 0.5`** |

Rows 2 and 5 are **machine-precision residuals**: deterministic for a given
build, but their last digits move with codegen (stage 5 read `3.181e-14` on
2026-09-11 and `3.186e-14` on 2026-09-24, both ~5 orders below the gate). The
**tolerance is the check**; the parenthesised figure is the last measured
value, not a golden to match digit-for-digit. Every other number in this
section — and every non-residual column in §7.1f″ — reproduces exactly.

Row 6 is a **falsifier**, not a bonus: the polynomial is fitted only on
`[1/κ, 1]`, so it must fail outside that band. Without it, rows 1–3 would also
pass for a routine that ignored its input.

#### 7.1f″ QSP angle finding — LEAN_EXPORT_PLAN Track E0 (numeric)

`linalg::angle_find` is the real angle finder the plan recorded as "present in
neither repo": a closed-form Childs–Kothari–Somma `1/x` polynomial (exact
Chebyshev coefficients, no fit) plus the Dong–Meng–Whaley–Lin symmetric-phase
Newton solve (square system, analytic Jacobian, start `(π/4,0,…,0,π/4)`). The
fitter in §7.1f′ fits the *non-polynomial* `scale/x` and is degree-limited by
construction; this one targets a polynomial, so it converges to machine
precision. Self-checking, gated in `ci.sh` **step 2** next to §7.1f′.

```bash
cargo run -q -p quantum-core --release --example qsp_angle_find 2>&1 | tail -24
```

**Expect** the banner `QSP-ANGLES OK — all checks passed`, no `[FAIL]`, each
κ line reporting `iters=4` and `residual` `< 1e-14`, and (deterministic — no
RNG):

| κ | ε | degree | reconstruction max err, 100 pts on `[-1,1]` | `|P − scale/x|/scale` on `[1/κ,1]` |
|---|---|---|---|---|
| 2 | 1e-4 | 49  | `~3e-15` (3.442e-15) (`≤ 1e-8`) | `1.751e-5` (`< 2ε`) |
| 4 | 1e-3 | 85  | `~4e-15` (3.775e-15) (`≤ 1e-8`) | `5.638e-4` (`< 2ε`) |
| 8 | 1e-2 | 145 | `~5e-15` (4.774e-15) (`≤ 1e-8`) | `5.633e-3` (`< 2ε`) |
| falsifier | — | old §7.1f′ fitter, κ=8 deg=95 | `4.996e-4` (**`≥ 1e-4`**) | — |

The falsifier pins that the gap E0 closes exists: if the old fitter ever
reached 1e-8 these rows would be measuring nothing.

The CKS scale above is `1/(2‖g_b‖∞)`, a `√ln(κ/ε)` factor below the
conventional `1/(2κ)` (κ=8: `0.0378` vs `0.0625`). The `windowed κ=…` lines
are `inversion_poly_windowed` (`1/x` times an erf window that turns on *at*
`1/κ`, Chebyshev-projected and tail-truncated — the window-at-`1/κ` idea of
Gilyén et al. Lemma 29 / Cor. 69, not their Thm 68 local-Taylor construction)
and must show `scale·2κ ≥ 0.9` (holds for ε ≥ 1e-9; it drifts to ≈0.90 at
the ε = 1e-10 clamp floor) with the same `≤ 1e-8` reconstruction and a
tighter `< ε` inverse error, at 3–4× the CKS degree (deterministic):

| κ | ε | degree | scale (`1/(2κ)`) | `scale·2κ` | reconstruction | `|P − scale/x|/scale` |
|---|---|---|---|---|---|---|
| 2 | 1e-4 | 181 | `2.3326e-1` (`2.5e-1`) | `9.330e-1` (`≥ 0.9`) | `~5e-15` (4.940e-15) (`≤ 1e-8`) | `1.565e-5` (`< ε`) |
| 4 | 1e-3 | 317 | `1.1767e-1` (`1.25e-1`) | `9.414e-1` (`≥ 0.9`) | `~8e-15` (7.772e-15) (`≤ 1e-8`) | `1.149e-4` (`< ε`) |
| 8 | 1e-2 | 511 | `5.9526e-2` (`6.25e-2`) | `9.524e-1` (`≥ 0.9`) | `~2e-14` (2.282e-14) (`≤ 1e-8`) | `1.608e-3` (`< ε`) |

The plan's second E0 gate — the QSVT product on a dense **non-diagonal**
block-encoded `A` equals the classical `p(A)` to `≤ 1e-9` — is a unit test on
8×8 matrices, in the same module as the `erf` reference values (`≤ 1e-14`) and
the windowed-scale gate:

```bash
cargo test -q -p quantum-core --lib linalg::angle_find 2>&1 | tail -3   # 11 passed
```

Stage 4 reports `max abs(Im U₀₀) = 9.922e-1` and **asserts it is large** — that
is *why* stage 5 needs an ancilla: a plain `⟨Z̄⟩` yields `abs(U₀₀)`, whereas the
QSP polynomial is `Re U₀₀`.

Stage 5 does the readout: a Hadamard test across **two** Steane patches
(ancilla `|+⟩` → controlled-`U_Φ` → `H`) puts `Re U₀₀` on the ancilla's `⟨Z̄⟩`.
It carries its own anti-degeneracy guard — the same samples must show
`abs(U₀₀)` and `Re U₀₀` far apart (**0.7500**, required `> 0.05`), otherwise the
two readouts would be indistinguishable and the stage would prove nothing.

#### 7.1g Verifiable UBQC + blind end-to-end + rotation merge (item 11 A2.2 / B2.3 / B4.4 — numeric)

The verifiable-UBQC trap weaving (B4.4), the blind multi-vertex output recovery
(B2.3), and the A2.2 rotation-merge optimization are verified by unit tests in
CI stage 2. To run just those numeric checks:

```bash
cargo test -q -p quantum-core --lib -- mbqc::verify mbqc::ubqc::tests::blind mbqc::pattern::tests::merge mbqc::flow::tests::optimize_merges 2>&1 | tail -3
```

**Expect:** `test result: ok.` covering the FK '17 dotted-graph guarantees
(trap `+`-probability ∈ {0,1} ≤1e-9 inside the entangled register; honest pass
over 64 seeds on `D(K₅)`; measured-`δ` uniform within 15% across 400 rounds with
every lattice bin role-mixed; graph role-independent; orthogonal-basis cheat
caught deterministically; random-basis cheat caught ≈½/round), the blind
end-to-end recovery (`blind_execute` output = `simulate_pattern_deterministic` =
`U|+⟩` ≤1e-9 up to global phase over 24 secret/Born draws × {line, Bell, GHZ};
secret-independent), and the rotation merge (consecutive `Rz` fuse, ρ invariant
≤1e-12, `optimize()` beats the Clifford-only baseline).

### 7.2 Aria DSL files

Every Rust `aria_*.rs` example has an `.aria` companion under
`examples/aria/`. See `examples/aria/README.md` for the surface syntax
and parser roadmap. Mapping table:

| Aria file | Rust counterpart |
|-----------|------------------|
| `bell.aria` | `aria_style.rs` (section 1) |
| `grover3.aria` | `aria_grover.rs`, `grover.rs` |
| `qft.aria` | `aria_qft.rs`, `qft_qpe.rs` |
| `vqe_ansatz.aria` | `aria_vqe.rs`, `vqe.rs` |
| `teleport.aria` | `teleportation.rs` |
| `deutsch_jozsa.aria` | `deutsch_jozsa.rs` |
| `bernstein_vazirani.aria` | `bernstein_vazirani.rs` |
| `simon.aria` | `simon.rs` |
| `superdense.aria` | `superdense.rs` |
| `swap_test.aria` | `swap_test.rs` |
| `qpe.aria` | `qft_qpe.rs` |
| `qaoa_maxcut.aria` | `qaoa_maxcut.rs` |
| `shor_ecdlp.aria` | `shor_ecdlp.rs`, `shor_ecdlp_secp256k1.rs` |
| `qml_classifier.aria` | `qml_classifier.rs` (in quantum-qml) |
| `qgan.aria` | `qgan.rs` (in quantum-qml) |
| `quantum_kernel.aria` | `quantum_kernel.rs` (in quantum-qml) |
| `hhl.aria`, `qsvt_invert.aria`, `qsvd.aria` | `linalg_solve.rs`, `qsvd.rs` |
| `qec_precision.aria` | `logical/{algo,gate_noise,precision}.rs` (`qec_precision_aria_reproduces_the_qpe_distribution`: twin vs `qpe_distribution` state-for-state ≤1e-9; `@bound gate_count = 40` checked) |
| `mbqc_bell.aria`, `mbqc_rotation.aria` | `mbqc_demo.rs` |
| `mbqc_ghz.aria`, `mbqc_grover3.aria`, `mbqc_qft4.aria`, `mbqc_rotations.aria`, `mbqc_u3.aria`, `mbqc_clifford_opt.aria` | `mbqc_verify.rs` (A1/A2/A4 round-trip, ≤1e-9; clifford_opt ≥30% optimize) |
| `teleport.aria`, `mbqc_feedforward.aria` | `aria_examples.rs` (A1.5 conditional→byproduct: terminal `output_corr` vs internal `x_corr_from`, fires-iff-source-1 ≤1e-12) |

> **Before believing any dist-based failure, check the bundle is not stale.**
> Every `$QBIN` check below runs the binary from `$QUANTUM_DIST`, which is an
> *extracted* bundle — it does not move when the repo does. If a row fails
> unexpectedly, look at `MANIFEST.txt`'s `git_sha` first and confirm it is the
> sha you mean to be testing:
>
> ```bash
> grep -E '^(variant|git_sha|omega_sha|source_date_epoch|rustc|libtorch):' "$QUANTUM_DIST/MANIFEST.txt"
> git log --oneline -1            # does git_sha match the sha under test?
> ```
>
> This is not hypothetical. A bundle extracted at `bc83aba` was still in place
> 17 commits later, and one of those commits added the `--code` validation that
> §7.3a‴ asserts — so that row would have failed against the stale binary for a
> reason that has nothing to do with the code being tested. The mac side hit
> the mirror image: a stale staging directory made a *present* MANIFEST field
> look missing, which would have "confirmed" a defect that did not exist. In
> both directions the tell is the same — `git_sha` not matching HEAD.
>
> Note the variant tags differ too: `ci.sh` 7b2 builds without `QUANTUM_TEST`,
> so its bundle is `<os>-<accel>`, while the `-test` bundles carry the demo
> payload. Reading the wrong one is the same class of mistake.

### 7.3 CLI tool

Run from the repo root — the `.qasm`/`.aria` inputs live in the repo, the
binary comes from the dist. `demo/01-bell/bell.qasm` is a real 2-qubit Bell
circuit that ships in the tree (there is no `circuit.qasm`; using a name that
does not exist made this block un-runnable and therefore unchecked).

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
"$QBIN" info     demo/01-bell/bell.qasm
"$QBIN" optimize demo/01-bell/bell.qasm -o /tmp/optimized.qasm
"$QBIN" compile  demo/01-bell/bell.qasm --format ffi -o /tmp/circuit.bin
"$QBIN" spec extract \
    --aria examples/aria/bell.aria --instantiate "Bell" --out /tmp/lean-out
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `info` `Qubits` / `Classical bits` | `2` / `2` | exact |
| `info` `Gate count` / `Depth` / `H-count` / `T-count` | `2` / `2` / `1` / `0` | exact |
| `info` `Instructions` | `4` (2 gates + 2 measures) | exact |
| `optimize` | `Optimized: 2 → 2 gates (0% reduction)` — H·CX has nothing to cancel | exact |
| `compile --format ffi` | `Written /tmp/circuit.bin (4 ops, 192 bytes)` | exact |
| `spec extract` | `Written /tmp/lean-out/Bell.lean`, 1 file | exact |
| every command | exit `0` | exact |

(`spec extract`'s output is *elaborated* by Lean in §8.2 — writing the file is
not the same as it compiling, which is how five elaboration errors survived
undetected until 2026-08-29.)

#### 7.3b Feynman `.qc` benchmark import (TODO §17 step 2 — numeric)

`benchmarks/circuits/feynman-qc/` vendors the 45 Clifford+T benchmark
circuits from Matthew Amy's Feynman repo at a pinned commit (BSD-2-Clause;
provenance and the sha256 manifest are in that directory's `README.md`). The
`.qc` reader must import them with the format's own counting convention —
`Z a b c` / `Zd a b c` is one CCZ = **T 7, H 0** — and must *refuse* the two
files that repeat a qubit inside a CCZ (`Z 8 h 8`) rather than import a
different circuit. Counts are the **input** circuit's; the §17 optimizer
passes are not built yet, so no parity with `qco-oracle-counts.tsv` is
claimed here (the pre-pass gap is recorded in
`docs/bench-baselines/feynman-qc-ours-baseline.tsv`).

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
(cd $D && sha256sum -c MANIFEST.sha256 | grep -c ': OK$')
grep -l '^Zd ' $D/*.qc | wc -l
"$QBIN" info $D/tof_3.qc
"$QBIN" info $D/barenco_tof_3.qc
n=0; for f in $D/*.qc; do "$QBIN" info "$f" >/dev/null 2>&1 && n=$((n+1)); done; echo "importable=$n"
"$QBIN" info $D/cycle_17_3.qc | grep -E 'Qubits|Gate count|T-count|H-count'
printf '.v a b\nBEGIN\ncnot a a\nEND\n' > /tmp/qc_bad.qc; "$QBIN" info /tmp/qc_bad.qc; echo "exit=$?"
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| manifest `OK` count | `46` (45 `.qc` + `LICENSE.md`) | exact |
| files spelling CCZ as `Zd` | `25` | exact |
| `info tof_3.qc` `Qubits` / `Gate count` / `T-count` / `H-count` | `5` / `9` / `21` / `6` | exact |
| `info barenco_tof_3.qc` `T-count` / `H-count` | `28` / `8` | exact |
| `importable=` | `45` (all of them, since 2026-09-24) | exact |
| `info cycle_17_3.qc` `Qubits` / `Gate count` / `T-count` / `H-count` | `35` / `2034` / `4529` / `1354` | exact |
| `info /tmp/qc_bad.qc` | stderr contains ``line 3: `cnot` names qubit `q[0]` twice``, `exit=1` | exact |

**`importable` was 43 until 2026-09-24**, and this table used to assert that
45 would itself be a failure — "the reader started accepting a repeated-qubit
CCZ, which is a *different* gate". That reasoning was wrong, and the two files
it excluded (`cycle_17_3.qc` line 18 `Z 8 h 8`, `mod_adder_1048576.qc` line
1175) were the 2 `parse-error` rows of every optimizer sweep.

`Z`/`Zd` on k qubits is the diagonal phase `(−1)^(x_{a_1}·…·x_{a_k})`, and
that product is **idempotent over F2** (`x·x = x`), so a repeated argument
lowers the arity rather than malforming the gate: `Z a b a == CZ a b`,
`Z a a == Z a`. This is checked as a *unitary*, not by gate kind — the
imported circuit's matrix equals the reference's on all 2³ basis states to
`1e-12` (`z_family_with_a_repeated_qubit_lowers_arity_and_is_unitary_equal`).

The refusal is intact for every **non-diagonal** gate, where a repeated
operand really is malformed (`cnot q q` has no control/target distinction) —
that is the third row above, and `cnot`/`tof`/`swap` are pinned in the same
test. So: `importable` below 45 means a reader arm was lost; a `cnot a a`
that imports means the guard was lost.

#### 7.3c FastTMerge T-count reduction (TODO §17 step 3 — numeric)

`quantum optimize <f> --pass fast-t-merge` runs the clean-room port of the
paper's Algorithm 3 (design note `docs/circuit-optimization/01-fast-t-merge.md`)
alone, and prints `T-count: in -> out` on stderr. `T_out` must equal the
paper's Table 1 **exactly** — the full 30-row comparison is
`docs/bench-baselines/feynman-qc-fast-t-merge.tsv`, and the unit tests assert
FastTMerge == the in-tree TMerge oracle on every importable benchmark (A2)
plus statevector equivalence on all ≤10-qubit inputs. The oracle TSV's `T`
column is the reference's *whole* pipeline (FastTMerge → InternalHOpt →
FastTODD), so parity with it is **not** expected from this pass alone.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
for c in tof_3 mod5_4 qcla_com_7 qft_4; do printf '%s ' $c; "$QBIN" optimize $D/$c.qc --pass fast-t-merge 2>&1 >/dev/null | grep '^T-count'; done
"$QBIN" optimize $D/tof_3.qc --pass fast-t-merge 2>&1 >/dev/null | grep -E '^(H-count|m:)'
"$QBIN" optimize $D/tof_3.qc --pass t-merge-oracle 2>&1 >/dev/null | grep '^T-count'
"$QBIN" optimize $D/tof_3.qc --pass fast-t-merge 2>/dev/null > /tmp/tof3_ftm.qasm; "$QBIN" optimize /tmp/tof3_ftm.qasm --pass fast-t-merge 2>&1 >/dev/null | grep '^T-count'
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `tof_3 T-count:` | `21 -> 15` | exact |
| `mod5_4 T-count:` | `28 -> 8` | exact |
| `qcla_com_7 T-count:` | `203 -> 95` | exact |
| `qft_4 T-count:` | `69 -> 67` | exact |
| `H-count:` (tof_3) | `6 -> 6` (this pass never touches H) | exact |
| `m: … rank(A): … merges: … commutativity-checks:` (tof_3) | `m: 21  rank(A): 2  merges: 3  commutativity-checks: 8` (3 merges × 2 rotations = 21 − 15) | exact |
| `t-merge-oracle` `T-count:` (tof_3) | `21 -> 15` (A2: == FastTMerge) | exact |
| second run on the output | `15 -> 15` (fixed point, §6.5) | exact |

#### 7.3d InternalHOpt internal-Hadamard reduction (TODO §17 step 3b — numeric)

`quantum optimize <f> --pass internal-h-opt` runs the clean-room port of
Algorithm 4 of arXiv:2302.07040 (design note
`docs/circuit-optimization/02-internal-h-opt.md`) alone;
`--pass fast-t-merge+internal-h-opt` runs FastTMerge first — the oracle's own
ordering. Both print `H-count: in -> out` and `internal-H-count: in -> out`
on stderr. Alone, `internal-H-count` out and `T-count` must equal the
paper's Table 1 **exactly** (22 goldens, all reproduced — unit test). After
FastTMerge, the oracle identity must hold on every row of
`docs/bench-baselines/feynman-qc-internal-h-opt.tsv` (30 oracle rows):
**`H_ours + internalH_ours == H_oracle`** — the oracle's default pipeline
gadgetizes each surviving internal H onto a fresh ancilla (+1 H each), so our
`internal-H-count` out is exactly its ancilla count and its own
`internalH` column is 0 by construction.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
"$QBIN" optimize $D/tof_3.qc --pass internal-h-opt 2>&1 >/dev/null | grep -E '^(T-count|internal-H-count|rank)'
for c in tof_3 mod5_4 qcla_com_7 tof_10; do printf '%s ' $c; "$QBIN" optimize $D/$c.qc --pass fast-t-merge+internal-h-opt 2>&1 >/dev/null | grep -E '^(H-count|internal-H-count)' | tr '\n' ' '; echo; done
"$QBIN" optimize $D/tof_3.qc --pass internal-h-opt 2>/dev/null > /tmp/tof3_ih.qasm; "$QBIN" optimize /tmp/tof3_ih.qasm --pass internal-h-opt 2>&1 >/dev/null | grep '^internal-H-count'
awk -F'\t' '$1!~/^#/ && $9=="MISMATCH"{n++} END{print "mismatch rows:", n+0}' docs/bench-baselines/feynman-qc-internal-h-opt.tsv
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `internal-h-opt` alone, tof_3 | `T-count: 21 -> 21`, `internal-H-count: 4 -> 2`, `rank(A): 2` (paper Table 1: 2/21) | exact |
| `tof_3` (after FastTMerge) | `H-count: 6 -> 6 internal-H-count: 4 -> 2` (6 + 2 == oracle H 8) | exact |
| `mod5_4` | `H-count: 6 -> 2 internal-H-count: 4 -> 0` (2 + 0 == oracle H 2, `exact` row) | exact |
| `qcla_com_7` | `H-count: 39 -> 37 internal-H-count: 19 -> 18` (37 + 18 == oracle H 55) | exact |
| `tof_10` | `H-count: 34 -> 34 internal-H-count: 32 -> 16` (34 + 16 == oracle H 50) | exact |
| second run on the output (tof_3) | `internal-H-count: 2 -> 2` (idempotent) | exact |
| `mismatch rows:` | `0` | exact |

#### 7.3e FastTODD T-count reduction (TODO §17 step 3c — numeric)

`quantum optimize <f> --pass fast-todd` runs the clean-room TOHPE + FastTODD
(Algorithms 2/3 of arXiv:2407.08695, design note
`docs/circuit-optimization/05-fast-todd.md`) on every Hadamard-free block of
the circuit; `--pass fast-t-merge+internal-h-opt+fast-todd` is the oracle's
default ordering **minus its gadgetization stage** (internal Hadamards stay in
the circuit, so the emitted circuit uses no ancilla). Both print
`T-count: in -> out` and a report-only `gadgetized-T-count: G` — the T-count
FastTODD reaches when every surviving internal H is gadgetized onto a fresh
ancilla and the whole circuit becomes one parity table. `G` is the paper's
Table 1 "with ancillae" number and exactly what the oracle's default pipeline
prints as `T`, so **`G == T_oracle`** is the parity check; the in-circuit
`T-count` out is the no-ancilla number (paper Table 2 setting differs — no
InternalHOpt — so it is compared in the unit tests, not here). The full sweep
is `docs/bench-baselines/feynman-qc-fast-todd.tsv` (32 oracle rows: 24
`exact`, 1 known `gap+4` row qcla_mod_7 163 vs 159, and 7 `better-by-k` rows
gf2^{5..10,16}_mult where FastTODD lands 4–8 T *below* paper Table 3 and the
oracle — FastTODD is a heuristic whose result is order-dependent, and gf2^5 is
statevector-verified against its input in the unit tests; all pinned, not
tuned. adder_8 (oracle 119 == G_ours) and gf2^16_mult (oracle 797 == paper,
G_ours 789) joined the oracle set in the 2026-09-13 re-run (`ulimit -v 32G`,
6 h budget). The remaining 13 rows have no oracle number: 2 `parse-error`
(cycle_17_3, mod_adder_1048576), 6 `timeout-240s`, 4 `error-rc134` = abort
under the sweep's `ulimit -v 16G`, and fprenorm `no-golden` — the oracle
binary itself panics on it (`src/circuit.rs:51` unwrap on `None`), so there is
no reference number to compare against. **The 2 `parse-error` rows predate the
2026-09-24 reader fix** (§7.3b: `Z a b a` is `CZ a b`); both circuits import
now and would land in `timeout-240s`, as they do in the §7.3f sweep. This TSV
has not been regenerated since — the rows it *gates* all carry oracle numbers
and are unaffected, so the tally below is unchanged.)

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
for c in tof_3 mod5_4 qcla_com_7 tof_10 csum_mux_9 csla_mux_3; do printf '%s ' $c; "$QBIN" optimize $D/$c.qc --pass fast-t-merge+internal-h-opt+fast-todd 2>&1 >/dev/null | grep -E '^(T-count|gadgetized-T-count)' | tr '\n' ' '; echo; done
"$QBIN" optimize "$D/gf2^4_mult.qc" --pass fast-t-merge+internal-h-opt+fast-todd 2>&1 >/dev/null | grep -E '^(T-count|internal-H-count)' | tr '\n' ' '; echo
"$QBIN" optimize $D/csum_mux_9.qc --pass fast-t-merge+internal-h-opt+fast-todd 2>/dev/null > /tmp/csum9_ftd.qasm; "$QBIN" optimize /tmp/csum9_ftd.qasm --pass fast-todd 2>&1 >/dev/null | grep '^T-count'
awk -F'\t' '$1!~/^#/{s=$NF; sub(/[-+][0-9]+$/,"",s); m[s]++} END{printf "exact=%d gap=%d better-by=%d mismatch=%d\n", m["exact"], m["gap"], m["better-by"], m["MISMATCH"]}' docs/bench-baselines/feynman-qc-fast-todd.tsv
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `tof_3` | `T-count: 21 -> 15 gadgetized-T-count: 13 …` (oracle T 13, paper Table 1 13) | exact |
| `mod5_4` | `T-count: 28 -> 7 gadgetized-T-count: 7 …` (no internal H left: in-circuit == gadgetized == oracle 7) | exact |
| `qcla_com_7` | `T-count: 203 -> 95 gadgetized-T-count: 59 …` (oracle 59) | exact |
| `tof_10` | `T-count: 119 -> 71 gadgetized-T-count: 55 …` (oracle 55) | exact |
| `csum_mux_9` | `T-count: 196 -> 77 gadgetized-T-count: 71 …` (FastTMerge+InternalHOpt alone leaves 84; oracle 71) | exact |
| `csla_mux_3` | `T-count: 70 -> 58 gadgetized-T-count: 39 …` (62 before FastTODD; oracle 39) | exact |
| `gf2^4_mult` | `T-count: 112 -> 49 internal-H-count: 0` (Hadamard-free after InternalHOpt: paper Table 3 = oracle = 49) | exact |
| second `fast-todd` run on the csum_mux_9 output | `T-count: 77 -> 77` (fixed point) | exact |
| TSV tally | `exact=24 gap=1 better-by=7 mismatch=0` | exact |

`--budget-secs S` (the `fast-todd` and `fast-todd-gadgetize` passes, alone or
after FastTMerge+InternalHOpt) is a wall-clock budget for the FastTODD search.
Past it the best table so far is emitted and the pass prints
`budget-exhausted: true`. The circuit stays signature-preserving; omitting the
flag runs the search to completion. `S = 0` is already past when the first
iteration would start, so both iteration counts are 0 and the T-count is
unchanged (canonicalise does not, on this circuit, drop a column the resynthesis
would keep).

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
"$QBIN" optimize $D/tof_3.qc --pass fast-todd --budget-secs 0 2>&1 >/dev/null | grep -E '^(T-count|budget-exhausted)'
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `tof_3`, `--budget-secs 0` | `T-count: 21 -> 21` and `budget-exhausted: true` | exact |

#### 7.3e′ `--budget-secs` reaches every table, and the cut keeps the unitary (TODO §17(c) — numeric)

§7.3e's `tof_3` line pins the flag on the block pass. This step pins the rest
of the contract. **Every** FastTODD search the command runs honours the
deadline — the block pass, the gadgetized pass, *and* the report-only
`gadgetized-T-count` (the `(n + h)`-wire table, the largest one the command
builds, so a budget that skipped it would not bound the run); the gadgetized
line carries its own `budget-exhausted` marker when *it* was the one cut, and
the final `budget-exhausted:` line is the OR over all of them. Every stop point
leaves the table signature-preserving (Theorem 6 holds per update), so the
emitted circuit is **still exactly the input unitary** — `verify` says so at
`min-fidelity 1.0000000000000` — and only its T-count optimality is lost. Only
the two endpoints are pinned: `S = 0` is the deadline already past on entry
(TOHPE canonicalises and stops before its first step, so every out-count is
what FastTMerge + InternalHOpt alone leave — 62 on csla_mux_3, 84 on
csum_mux_9, §7.3e), and a budget the run never reaches (60 s; the whole
csum_mux_9 run is ~20 ms) reproduces §7.3e/§7.3f's unbudgeted rows bit for bit.
A cut *inside* a search is a valid but wall-clock-dependent best-so-far and is
not pinned. A missing or non-numeric value is rc 1, never a silently
unbudgeted run.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
for b in 0 60; do printf 'csla_mux_3 budget=%s ' $b; "$QBIN" optimize $D/csla_mux_3.qc --pass fast-t-merge+internal-h-opt+fast-todd --budget-secs $b -o /tmp/csla_b$b.qasm 2>&1 >/dev/null | grep -E '^(T-count|gadgetized-T-count|budget-exhausted)' | tr '\n' ' '; "$QBIN" verify $D/csla_mux_3.qc /tmp/csla_b$b.qasm | grep -E '^(min-fidelity|VERIFY)' | tr '\n' ' '; echo " rc=${PIPESTATUS[0]}"; done
for b in 0 60; do printf 'csum_mux_9 budget=%s ' $b; "$QBIN" optimize $D/csum_mux_9.qc --pass fast-t-merge+internal-h-opt+fast-todd --budget-secs $b 2>&1 >/dev/null | grep -E '^(T-count|gadgetized-T-count|budget-exhausted)' | tr '\n' ' '; echo; done
for b in 0 60; do printf 'csla_mux_3 gadgetize budget=%s ' $b; "$QBIN" optimize $D/csla_mux_3.qc --pass fast-t-merge+internal-h-opt+fast-todd-gadgetize --budget-secs $b 2>&1 >/dev/null | grep -E '^(T-count|gadgetized-T-count|budget-exhausted)' | tr '\n' ' '; echo; done
"$QBIN" optimize $D/tof_3.qc --pass fast-todd --budget-secs abc >/dev/null 2>&1; echo "bad value rc=$?"
"$QBIN" optimize $D/tof_3.qc --pass fast-todd --budget-secs >/dev/null 2>&1; echo "missing value rc=$?"
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `csla_mux_3 budget=0` | `T-count: 70 -> 62 gadgetized-T-count: 62  (internal-H gadgets: 6)  budget-exhausted budget-exhausted: true min-fidelity 1.0000000000000 VERIFY OK … rc=0` (62 = before FastTODD, §7.3e; still the input unitary) | exact |
| `csla_mux_3 budget=60` | `T-count: 70 -> 58 gadgetized-T-count: 39  (internal-H gadgets: 6) budget-exhausted: false min-fidelity 1.0000000000000 VERIFY OK … rc=0` (== §7.3e row) | exact |
| `csum_mux_9 budget=0` | `T-count: 196 -> 84 gadgetized-T-count: 84  (internal-H gadgets: 12)  budget-exhausted budget-exhausted: true` (84 = FastTMerge+InternalHOpt alone, §7.3e) | exact |
| `csum_mux_9 budget=60` | `T-count: 196 -> 77 gadgetized-T-count: 71  (internal-H gadgets: 12) budget-exhausted: false` (== §7.3e row) | exact |
| `csla_mux_3 gadgetize budget=0` | `T-count: 70 -> 62 gadgetized-T-count: 62  (T-count out == this)  budget-exhausted budget-exhausted: true` (§7.3f unbudgeted: 39) | exact |
| `csla_mux_3 gadgetize budget=60` | `T-count: 70 -> 39 gadgetized-T-count: 39  (T-count out == this) budget-exhausted: false` (== §7.3f) | exact |
| `bad value` / `missing value` | `rc=1` / `rc=1` | exact |

Last run 2026-10-02 against `quantum-dist-linux-cpu-182f80f.tar.gz` (sha256
`a974b5a73776f7720fb21f1c018cc844d2761084b967e0c1f3b3542b8f69bcd9`, omega
`ed146b4`, built from a clean worktree, `verify-dist.sh` VERIFY OK, stripped
binary): all 8 lines exact, and §7.3e's `tof_3` budget line exact.

#### 7.3f Internal-Hadamard gadgetization (TODO §17 step 3d — numeric)

`quantum optimize <f> --pass fast-t-merge+internal-h-opt+fast-todd-gadgetize`
is §7.3e's pipeline **with** the oracle's third stage (design note
`docs/circuit-optimization/03-h-gadgetization.md`, arXiv:2407.08695 Fig. 1 /
Eq. 5): every internal Hadamard becomes a measurement gadget on a fresh
ancilla (`|+⟩`, `CZ`, X-basis measurement of the old wire), the whole
`(n+h)`-wire region is **one** parity table for TOHPE + FastTODD, and the
emitted circuit carries the `h` measurements and the conditioned Clifford
corrections (`if (hbK == 1) …`, one 1-bit creg per gadget). So the emitted
circuit's `T-count` **is** §7.3e's report-only `G`, and the pass prints
`gadgetized-T-count: G  (T-count out == this)` as its own cross-check. The
output is not a unitary on `n` wires — it is equivalent **per measurement
outcome**, and that (every one of the `2^h` branches reproduces `U|ψ⟩` with
fidelity `≥ 1 − 1e-10`, each with probability `2^{-h}`) is pinned by the unit
tests on every row with `n + h ≤ 16` wires (`cargo test -p quantum-core
h_gadget`: tof_3, barenco_tof_3, tof_4, mod_mult_55, vbe_adder_3,
barenco_tof_4, tof_5, gf2^4_mult + 120 random circuits); the dist check below
pins the counts and that the exported QASM re-imports exactly.

The full sweep over all 49 `.qc` is `docs/bench-baselines/feynman-qc-h-gadget.tsv`
(regenerate with `scripts/h-gadget-parity-sweep.sh`, 240 s + `ulimit -v 16G` per
circuit). **This is TODO §17(c)(i)'s pair of numbers**: 32 rows have an oracle
value, and **`H_ours == H_oracle` on all 32** — the H half is complete. `T_ours`
is exact on 24, 4–8 *below* the oracle on 7 (`gf2^{5..10,16}_mult`, which also
beat paper Table 3) and 4 above on 1 (`qcla_mod_7` 163 vs 159, the gap inherited
from §7.3e). The 13 rows with no oracle value: **9 `timeout-240s`**, 3
`error-rc134` (abort under the sweep's `ulimit`), and `fprenorm` `no-golden`
(the oracle binary itself panics on it). **Zero `parse-error`** — cycle_17_3
and mod_adder_1048576 joined the timeout rows on 2026-09-24 when the reader
learned that `Z a b a` is `CZ a b` (§7.3b); every one of the 45 benchmarks now
reaches the passes.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
for c in tof_3 mod5_4 qcla_com_7 tof_10 csum_mux_9; do printf '%s ' $c; "$QBIN" optimize $D/$c.qc --pass fast-t-merge+internal-h-opt+fast-todd-gadgetize -o /tmp/${c}_hg.qasm 2>&1 >/dev/null | grep -E '^(T-count|internal-H gadgets|gadgetized-T-count)' | tr '\n' ' '; echo; done
for c in tof_3 mod5_4 qcla_com_7 tof_10 csum_mux_9; do printf '%s ' $c; "$QBIN" info /tmp/${c}_hg.qasm | grep -E 'Qubits|Classical bits|T-count' | tr -s ' ' | tr '\n' ' '; echo; done
grep -cE '^if \(hb[0-9]+ == 1\) (s|sdg|z|cz|x|y) ' /tmp/tof_3_hg.qasm
awk -F'\t' '!/^#/{s=$NF; sub(/[-+][0-9]+$/,"",s); m[s]++} END{printf "exact=%d T-gap=%d T-better-by=%d MISMATCH=%d H-diff=%d\n", m["exact"], m["T-gap"], m["T-better-by"], m["MISMATCH"], m["H-diff"]}' docs/bench-baselines/feynman-qc-h-gadget.tsv
awk -F'\t' '!/^#/ && $8!="-"{t++; if ($5==$9) h++} END{printf "H_ours==H_oracle on %d/%d oracle rows\n", h, t}' docs/bench-baselines/feynman-qc-h-gadget.tsv
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `tof_3` | `T-count: 21 -> 13 internal-H gadgets: 2 wires: 5 -> 7 measurements: 2 gadgetized-T-count: 13 (T-count out == this)` (oracle 13) | exact |
| `mod5_4` | `T-count: 28 -> 7 internal-H gadgets: 0 wires: 5 -> 5 measurements: 0 gadgetized-T-count: 7 …` (h = 0: stays a unitary, no ancilla) | exact |
| `qcla_com_7` | `T-count: 203 -> 59 internal-H gadgets: 18 wires: 24 -> 42 measurements: 18 gadgetized-T-count: 59 …` (oracle 59) | exact |
| `tof_10` | `T-count: 119 -> 55 internal-H gadgets: 16 wires: 19 -> 35 measurements: 16 gadgetized-T-count: 55 …` (oracle 55) | exact |
| `csum_mux_9` | `T-count: 196 -> 71 internal-H gadgets: 12 wires: 30 -> 42 measurements: 12 gadgetized-T-count: 71 …` (oracle 71) | exact |
| `info` re-import, `tof_3` | `Qubits: 7 Classical bits: 2 T-count: 13` | exact |
| `info` re-import, `mod5_4` | `Qubits: 5 Classical bits: 0 T-count: 7` | exact |
| `info` re-import, `qcla_com_7` | `Qubits: 42 Classical bits: 18 T-count: 59` | exact |
| `info` re-import, `tof_10` | `Qubits: 35 Classical bits: 16 T-count: 55` | exact |
| `info` re-import, `csum_mux_9` | `Qubits: 42 Classical bits: 12 T-count: 71` | exact |
| conditioned corrections in `tof_3_hg.qasm` | `5` (2 gadgets: `cz`, `x`, `z` on `hb0`; `cz`, `x` on `hb1`) | exact |
| sweep tally | `exact=24 T-gap=1 T-better-by=7 MISMATCH=0 H-diff=0` | exact |
| sweep H parity | `H_ours==H_oracle on 32/32 oracle rows` | exact |

Last run 2026-09-19 against `quantum-dist-linux-cpu-97f425b.tar.gz` (sha256 `858af179765585df3dccc9892a7ad74044e38ec890a1de25d1abc108359b6885`, `verify-dist.sh` VERIFY OK): all 13 lines exact.

#### 7.3g Unitary equivalence of the optimized circuits (TODO §17 (c)(ii)/(iii) — numeric)

`quantum verify <a> <b> [--states N] [--seed S] [--tolerance T] [--backend
statevector|mps [--bond B]]` is the fidelity column TODO §17(c) asks for: the
optimizer's *T-count* is pinned by §7.3c–§7.3f, this pins that the optimized
circuit is **the same unitary**. It runs both circuits on `N` seeded
random product states (`--states 8`, `--seed 42` by default; `|ψ⟩ = ⊗_q
(cos θ_q |0⟩ + e^{iφ_q} sin θ_q |1⟩)`), takes the min over them of
`|⟨a|b⟩|² / (‖a‖² ‖b‖²)` (global phase quotiented out, so a `−U` is OK), and
prints `VERIFY OK` (rc 0) iff `min-fidelity ≥ 1 − tol`, `VERIFY MISMATCH`
(rc 1) otherwise. The binary's default `tol` is `1e-10` regardless of `n`; the
sweep script passes `--tolerance 1e-10` for `n ≤ 12` and `1e-8` above (the
statevector rounding budget at 28 wires); statevector is used for `n ≤ 28`,
`mps` above, and the `mps` truncation certificate **refuses** (rc 2) rather
than passes when the bond dimension cannot carry the state. Two negative
paths are part of the contract and are checked below: a gadgetized circuit
(§7.3f) has `n + h` wires and is *not* unitary-equivalent to its input —
`verify` says so and exits 1 instead of computing a meaningless number — and a
circuit containing `Measure` does not denote a unitary at all (rc 2; that
equivalence is per outcome, pinned by the `h_gadget` unit tests).

The full sweep over all 45 `.qc` (`docs/bench-baselines/feynman-qc-fidelity.tsv`,
regenerate with `scripts/verify-fidelity-sweep.sh <quantum-binary>`, ~1.5 h on
the Linux box — the 27-qubit `gf2^9_mult` verify alone is 1572 s) optimizes
each circuit with §7.3e's pipeline (240 s + `ulimit -v 16G`) and verifies the
result against the input with `--states 8` (3600 s + `ulimit -v 32G` per
circuit). **This is TODO §17(c)(ii)/(iii)'s column.** Measured: 29 rows ran
and all 29 are `OK`; the 4 `mps` rows (`csum_mux_9`/`gf2^10_mult` n = 30,
`qcla_adder_10` n = 36, `gf2^16_mult` n = 48) are **refused** by the backend
(the truncation certificate, or the 2^n dense contraction an analytic run
needs — 1 TiB at n = 36) and recorded as `SKIP-mps-refused`, never as a pass;
the 12 rows with no fidelity are the *optimize* step's own 240 s timeouts (8)
and 16 GiB OOM aborts (4: `gf2^64_mult`, `gf2^128_mult`, `hwb10`, `hwb11`) —
the same circuits the T-count sweeps cannot finish at that budget.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
D=benchmarks/circuits/feynman-qc
for c in tof_3 mod5_4 vbe_adder_3 tof_10; do "$QBIN" optimize $D/$c.qc --pass fast-t-merge+internal-h-opt+fast-todd -o /tmp/${c}_u.qasm >/dev/null 2>&1; printf '%s ' $c; "$QBIN" verify $D/$c.qc /tmp/${c}_u.qasm | grep -E '^(qubits|min-fidelity|VERIFY)' | tr '\n' ' '; echo " rc=${PIPESTATUS[0]}"; done
"$QBIN" verify $D/tof_3.qc $D/mod5_4.qc | grep -E '^(min-fidelity|VERIFY)' | tr '\n' ' '; echo " rc=${PIPESTATUS[0]}"
"$QBIN" optimize $D/tof_3.qc --pass fast-t-merge+internal-h-opt+fast-todd-gadgetize -o /tmp/tof_3_hg.qasm >/dev/null 2>&1; "$QBIN" verify $D/tof_3.qc /tmp/tof_3_hg.qasm 2>&1 | cut -c1-25; echo "rc=${PIPESTATUS[0]}"
"$QBIN" verify /tmp/tof_3_hg.qasm /tmp/tof_3_hg.qasm 2>&1 | head -c 35; echo "rc=${PIPESTATUS[0]}"
awk -F'\t' '!/^#/{s=$NF; sub(/\(n=[0-9]+\)$/,"",s); m[s]++} END{printf "OK=%d MISMATCH=%d SKIP-mps-refused=%d timeout-240s=%d verify-timeout-3600s=%d error=%d\n", m["OK"], m["MISMATCH"], m["SKIP-mps-refused"], m["timeout-240s"], m["verify-timeout-3600s"], m["error-rc134"]+m["verify-error-rc1"]+m["verify-error-rc2"]}' docs/bench-baselines/feynman-qc-fidelity.tsv
awk -F'\t' '!/^#/ && $NF=="OK"{ if ($7+0 < 1-$6) bad++; if ($2+0 <= 12 && $7 != "1.0000000000000") bad++; if ($7+0 < min || min=="") min=$7 } END{printf "min over OK rows %s bad=%d\n", min, bad}' docs/bench-baselines/feynman-qc-fidelity.tsv
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `tof_3` | `qubits: 5 min-fidelity 1.0000000000000 VERIFY OK  (min-fidelity >= 1 - 1e-10)  rc=0` (T 21 → 15) | exact |
| `mod5_4` | `qubits: 5 min-fidelity 1.0000000000000 VERIFY OK … rc=0` (T 28 → 7) | exact |
| `vbe_adder_3` | `qubits: 10 min-fidelity 1.0000000000000 VERIFY OK … rc=0` (T 70 → 24) | exact |
| `tof_10` | `qubits: 19 min-fidelity 1.0000000000000 VERIFY OK  (min-fidelity >= 1 - 1e-10)  rc=0` (T 119 → 71) — the default `1e-10`, tighter than the sweep's `1e-8` for n > 12, and it holds exactly | exact |
| `tof_3` vs `mod5_4` (different unitaries) | `min-fidelity 0.0060676371586 VERIFY MISMATCH  (min-fidelity < 1 - 1e-10)  rc=1` | `± 1e-12` |
| gadgetized `tof_3` vs its input | `qubit counts differ: 5 vs 7` `rc=1` (not a unitary on 5 wires) | exact |
| gadgetized `tof_3` vs itself (contains `Measure`) | `circuit a contains Measure — it d` `rc=2` | exact |
| sweep tally | `OK=29 MISMATCH=0 SKIP-mps-refused=4 timeout-240s=8 verify-timeout-3600s=0 error=4` (29 + 4 + 8 + 4 = 45 rows) | exact |
| min over OK rows | `min over OK rows 0.9999999999836 bad=0` — every `n ≤ 12` row is exactly `1.0000000000000`; the one wide statevector row below 1 is `adder_8` (n = 24: `0.9999999999836`), the `1e-11` rounding of a 2^24-amplitude sum, inside its `1e-8` tol | exact |

#### 7.3h Per-circuit fidelity gate with a negative control (TODO §17 (c) — numeric)

§7.3g pins the sweep as a tally; this pins **every cheap circuit on its own**,
and proves the tolerance is not vacuous on each one. `scripts/verify-fidelity-gate.sh`
takes the sweep's `OK` rows with `secs_verify ≤ 5` (24 circuits), re-runs the
§7.3e pipeline, checks `verify` against the recorded `min_fid_ok`
(`1.0000000000000` on every row, `≥ 1 − tol`, `tol = 1e-10` for `n ≤ 12` and
`1e-8` above), then flips the **first `t` to `tdg`** in the optimized circuit
— one wrong T-phase, the smallest edit a broken optimizer could make — and
requires `MISMATCH rc=1` at the recorded `min_fid_bad` (`± 1e-9`). Golden table:
`docs/bench-baselines/feynman-qc-fidelity-gate.tsv` (written by `--record`
from a real run, not hand-edited). ~25 s wall on the release dist binary
(the statevector runs in parallel), ~2.5 min on a debug build.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
bash scripts/verify-fidelity-gate.sh "$QBIN" | tail -4; echo "rc=${PIPESTATUS[0]}"
awk -F'\t' '!/^#/ && NR>1 && $1!="circuit"{n++; if ($4!="1.0000000000000") bad++; if ($5+0 >= 1-$3) weak++; if ($5+0>max) max=$5} END{printf "rows=%d ok!=1:%d mutant>=1-tol:%d max_mutant=%s\n", n, bad+0, weak+0, max}' docs/bench-baselines/feynman-qc-fidelity-gate.tsv
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| last gate line | `verify-fidelity-gate: 24 circuits, fail=0` `rc=0` — the three lines above it end `ok   tof_4 … mutant=0.5004286046900`, `ok   tof_5 … mutant=0.5001306654379`, `ok   vbe_adder_3 … mutant=0.5000170224888` | exact |
| golden summary | `rows=24 ok!=1:0 mutant>=1-tol:0 max_mutant=0.6216828578163` — every optimized circuit is exactly its input; every one-T-phase mutant is far below `1 − tol` (the closest is `barenco_tof_10` at `0.6216828578163`, the rest `≤ 0.5169`) | exact |
| a `FAIL` line | none. To see the gate bite: `sed -i 's/^tof_3\t5\t1e-10\t1.0000000000000\t/tof_3\t5\t1e-10\t0.9999999999999\t/' docs/bench-baselines/feynman-qc-fidelity-gate.tsv` → `FAIL tof_3 (n=5 tol=1e-10): optimized vs input min-fidelity '1.0000000000000' OK rc=0, expected '0.9999999999999' OK rc=0` and `fail=1`; `git checkout` the TSV afterwards | exact |

#### 7.3a Surface-code error correction (`quantum ecc` — numeric, multi-backend)

`quantum ecc` builds a rotated surface code `[[d²,1,d]]`, injects a Pauli error,
extracts the stabilizer syndrome on a selectable simulator backend
(`statevector` / `stabilizer`|`pauli` / `mps`), minimum-weight (MWPM) decodes,
and reports the result numerically. It requires the `omega-sim` feature (the
omega-functions statevector/stabilizer/MPS backends); the **stripped dist build
links it in** (see §0b — `build-dist.sh` adds `--features omega-sim` on native
builds). Source build:

```bash
cargo run -p quantum-core --features omega-sim --bin quantum -- ecc --distance 3 --backend stabilizer
```

**Run against the stripped dist artefact** (the manual's source of truth):

```bash
QBIN="$QUANTUM_DIST/bin/quantum"          # from a build-dist.sh tarball
"$QBIN" ecc --distance 3 --backend stabilizer
"$QBIN" ecc --distance 3 --backend statevector
"$QBIN" ecc --distance 3 --backend mps
"$QBIN" ecc --distance 3 --backend stabilizer --p 0.01 --shots 8000 --seed 7
```

Expected output (deterministic; the default error is an X on the centre qubit):

| Line | Expected | Tolerance |
|------|----------|-----------|
| `clean_syndrome_weight` | `0` | exact |
| `z_syndrome` (X@4, d=3) | `1,1,0,0` | exact |
| `correction_x` | `4` | exact |
| `residual_syndrome_weight` | `0` | exact |
| `logical_failure` | `0` | exact |
| `backend_agreement` | `1` (statevector = stabilizer = mps = pauliprop, bit-for-bit) | exact |
| `backends_checked` (d=3) | `statevector,stabilizer,mps,pauliprop` (4-way) | exact |
| `single_error_decode` | `18/18` (all single X & Z errors corrected) | exact |
| `suppressed` (p=0.01, seed 7) | `1` (logical_rate `0.0032` < physical `0.01`) | logical_rate ≤ 0.006 |

The `backend_agreement 1` line is the headline numeric: the exact statevector,
the MPS tensor-network and the Clifford stabilizer simulators return identical
syndromes. The Rust twin is the `ecc_surface` example
(`cargo run -p quantum-core --features omega-sim --example ecc_surface`), and the
dist demo is `quantum-examples/demo/12-ecc/run.sh`.

> If the dist was built without `omega-sim` (a `cross`/Docker Linux build, where
> the sibling `../aria-quantum-language-oss` path is not mounted), `quantum ecc` prints a
> rebuild hint and exits 2 — by design; the rest of the dist is unaffected.

##### Distance 5 `[[25,1,5]]` — scalable backends only (the RAM-safe path)

At `--distance 5` each CSS sector is a **37-qubit** circuit
(`25` data `+ 12` checks). A *dense statevector* of 37 qubits is `2³⁷ ≈ 1.37e11`
complex amplitudes `≈ 2 TB` — it will exhaust RAM and be OOM-killed. `quantum
ecc` therefore **refuses** the statevector backend past `ECC_STATEVECTOR_MAX_QUBITS
= 26` and runs only the simulators that scale: the **Clifford stabilizer**
(`stabilizer`/`pauli`, an Aaronson–Gottesman tableau, O(n²)) and the **MPS**
tensor network (bond-capped). Both run d=5 in **a few MB** (measured peak RSS
4.8 MB stabilizer / 5.3 MB mps; the gate in the table below is < 100 MB).

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
"$QBIN" ecc --distance 5 --backend stabilizer
"$QBIN" ecc --distance 5 --backend mps
"$QBIN" ecc --distance 5 --backend statevector            # must refuse, exit 2
"$QBIN" ecc --distance 5 --backend stabilizer --p 0.05 --shots 2000 --seed 7
```

Expected (default error is an X on the centre data qubit, index 12):

| Line | Expected | Tolerance |
|------|----------|-----------|
| header | `ecc surface d=5 [[25,1,5]] data=25 x_checks=12 z_checks=12` | exact |
| `z_syndrome` (X@12) | `0,0,1,0,0,1,0,0,0,0,0,0` | exact |
| `correction_x` / `mwpm_weight` | `12` / `1` | exact |
| `residual_syndrome_weight` / `logical_failure` | `0` / `0` | exact |
| `backend_agreement` | `1` (stabilizer = mps = pauliprop, bit-for-bit) | exact |
| `backends_checked` | `stabilizer,mps,pauliprop` (statevector skipped) | exact |
| `single_error_decode` | `50/50` (all `2·25` single X & Z errors corrected) | exact |
| `suppressed` (p=0.05, seed 7) | `1` (logical_rate `0.044` < physical `0.05`) | logical_rate ≤ 0.05 |
| statevector run | exits **2**, prints `infeasible for distance 5 (37 qubits)` | exact |
| peak RSS (stabilizer or mps) | a few MB | `< 100 MB` |

> **Why this matters for the dist artefact.** The statevector gate
> (`ecc_backend_feasible`) lives in `quantum.rs`; a binary built *before* it
> existed runs the 2 TB statevector at d=5 and is OOM-killed (`exit 137`). The
> manual is run against the **freshly built** stripped dist binary precisely so a
> stale build cannot pass.

##### Distance 7 `[[49,1,7]]` and beyond — Pauli propagation (`pauliprop`)

The measurement backends key their syndrome on a 64-bit `Counts` integer, so a
73-qubit d=7 sector is refused (`exit 2`). The **`pauliprop`** backend (Pauli
propagation — a Heisenberg-picture tree of weighted Pauli strings,
[arXiv:2505.21606](https://arxiv.org/abs/2505.21606); engine in
`../aria-quantum-language-oss/crates/omega-backend-pauliprop`) reads each check's
**expectation value** `⟨C⟩ = ±1` on the bare data state — no ancilla, no
measurement key — so it is exact and `O(MB)` for the Clifford syndrome at *any*
distance.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
"$QBIN" ecc --distance 7 --backend pauliprop
"$QBIN" ecc --distance 7 --backend stabilizer                    # must refuse, exit 2
"$QBIN" ecc --distance 7 --backend pauliprop --p 0.03 --shots 1500 --seed 7
"$QBIN" ecc --distance 9 --backend pauliprop                     # [[81,1,9]]
# NOTE: d=9 is 81 qubits. A QUANTUM_TEST *evaluation* bundle (variant
# `<os>-<accel>-test`) caps `ecc` at 64 qubits, so this one line exits 2 there
# with "limited to 64 qubit(s)" (§10.1a pins that refusal). The d=9 row below
# needs a full bundle -- `build-dist.sh cpu` without QUANTUM_TEST. Every other
# line in this section runs on both.
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| header (d=7) | `ecc surface d=7 [[49,1,7]] data=49 x_checks=24 z_checks=24` | exact |
| `syndrome_weight` (X@24) | `2` | exact |
| `logical_failure` | `0` | exact |
| `backends_checked` (d=7) | `pauliprop` (sole feasible backend) | exact |
| `single_error_decode` (d=7) | `98/98` | exact |
| `single_error_decode` (d=9) | `162/162` (full bundle only -- see the note above) | exact |
| `suppressed` (d=7, p=0.03, seed 7) | `1` (logical_rate `0.0080` < physical `0.03`) | logical_rate ≤ 0.03 |
| `decode_success_rate` (d=7) | `1.0000` | **exactly 1** |

> **Decoder by distance.** Exhaustive minimum-weight search reaches its full
> weight cap only to d=5 (245,505 candidates; d=7 needs ≈5.5e8). Past that,
> `ecc::mwpm` completes whole weight levels up to what its budget allows and
> refuses beyond — so the statement a refusal makes stays order-independent
> ("no error of weight ≤ w\* produces this syndrome"), and **low-weight errors
> still decode at any distance**, which is why the d=9 battery below is
> `162/162`. For a *rate*, `ecc::run` falls back to BP+OSD where it fits (d=7:
> 24 checks, 49 qubits); at d=9 (40 checks, 81 qubits) it does not, so a
> Monte-Carlo sweep is **refused with exit 2** rather than run for hours. Add
> `--p`/`--shots` to the d=9 line to see that refusal. Before 2026-08-12 the exact decoder
> returned an empty correction on failure — indistinguishable from "no error" —
> and the Monte-Carlo scored those rounds by the raw error's overlap parity,
> which is meaningless outside the codespace: 8 rounds of this very command
> never returned to it. `decode_success_rate` is now `1.0000` and the bar above
> is genuinely earned rather than coincidentally met.
| stabilizer/mps/statevector at d=7 | exit **2**, message points to `pauliprop` | exact |
| peak RSS (pauliprop d=7) | a few MB | `< 100 MB` |

> The `pauliprop` agreement is the strongest cross-check in the suite: at d=3 it
> is the **fourth** backend in `backends_checked` and reproduces the
> statevector/stabilizer/mps syndrome bit-for-bit, then carries the *same* code
> to distances no other backend can simulate.

##### Triangular 6.6.6 color code (`quantum ecc --code color` — two decoders)

`quantum ecc --code color` builds the triangular 6.6.6 color code
(`[[7,1,3]]`/`[[19,1,5]]`/`[[37,1,7]]` for d=3/5/7) and decodes an injected Pauli
error with **both** the exact minimum-weight decoder and the SOTA **BP+OSD**
decoder (MWPM does not apply to color codes). The color-code syndrome is
deterministic (parity of each face with the error), so this path is
self-contained — no simulator backend — but it still ships only under
`omega-sim` (it lives in the same `ecc` subcommand). Run against the stripped
dist artefact:

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
"$QBIN" ecc --code color --distance 5 --error "X4,Z10"
"$QBIN" ecc --code color --distance 7 --decoder bposd --p 0.02 --shots 3000 --seed 3
```

Expected output (deterministic):

| Line | Expected | Tolerance |
|------|----------|-----------|
| `self_dual_css` (d=5) | `1` | exact |
| `[[..]]` header (d=5) | `[[19,1,5]] data=19 faces=9` | exact |
| `clean_syndrome_weight` | `0` | exact |
| `exact_logical_failure` (X4,Z10 @ d=5) | `0` | exact |
| `bposd_logical_failure` (X4,Z10 @ d=5) | `0` | exact |
| `exact_correction_weight` / `bposd_correction_weight` | `2` | exact |
| `single_error_decode_exact` (d=5) | `38/38` | exact |
| `single_error_decode_bposd` (d=5) | `38/38` | exact |
| `single_error_decode_bposd` (d=7) | `74/74` | exact |
| `[[..]]` header (d=7) | `[[37,1,7]] data=37 faces=18` | exact |
| `suppressed` (d=7, p=0.02, seed 3) | `1` (logical_rate `≈ 0.0003` « physical `≈ 0.78`) | logical_rate ≤ 0.01 |

The headline is that **both decoders correct every weight-1 error**
(`38/38` at d=5, `74/74` at d=7) and agree on the injected error, and the SOTA
BP+OSD logical rate sits far below the physical rate at d=7 — the code's
distance is exactly `d`, proved in Rust by stabilizer-coset enumeration and (for
d=3) in Lean (`QuantumProofs/QEC/Codes/Color.lean`, `distance = 3`).

#### 7.3a′ Transversal low-overhead QEC — logical algorithms (`quantum logical`)

`quantum logical` runs textbook algorithms as **logical** circuits on the
transversal low-overhead QEC layer (neutral-atom "Transversal STAR" /
trapped-ion small codes, arXiv:2509.18294), plus surface-code memory
logical-error curves and effective-logical-channel extraction. Encoded 2-qubit
Grover is pure Clifford (H, X, CZ), so it runs **exactly** on Pauli-propagation
and statevector on encoded Steane `[[7,1,3]]` qubits. Needs `omega-sim` (linked
in the native dist; a cross build ships it inert and exits 2). Source build:

```bash
cargo run -p quantum-core --features omega-sim --bin quantum -- logical grover --marked 2
```

**Run against the stripped dist artefact:**

```bash
QBIN="$QUANTUM_DIST/bin/quantum"
for m in 0 1 2 3; do "$QBIN" logical grover --marked $m; done
"$QBIN" logical grover --marked 2 --backend statevector      # backend cross-check
"$QBIN" logical qft --n 4 --input 5
"$QBIN" logical qpe --counting 3 --phase 0.25
"$QBIN" logical qpe --counting 4 --phase 0.625
"$QBIN" logical memory --distance 3 --noise neutral-atom --p 0.06 --shots 40000
"$QBIN" logical memory --distance 5 --noise neutral-atom --p 0.06 --shots 40000

# --- added 2026-08-02: colour code, [[15,1,3]] transversal T, encoded QSP ---

# Same logical Grover on the triangular 6.6.6 COLOUR code. The payoff over the
# surface code is a transversal FULL Clifford group (incl. S), which needs d>3
# to be a real claim — Steane IS the d=3 colour code.
for d in 3 5 7; do "$QBIN" logical grover --code color --distance $d --marked 2; done
# Every exact backend must agree (dense amplitudes / tensor train / Pauli tree):
for be in statevector mps pauliprop; do
  "$QBIN" logical grover --code color --distance 3 --marked 2 --backend $be
done

# The [[15,1,3]] punctured Reed-Muller code: TRANSVERSAL T (the gate no 2D
# topological code gives you) + 15-to-1 distillation RUN, not just quoted.
"$QBIN" logical magic --p 1e-3

# QSP on an encoded qubit. Zero phases make the sequence W^d, whose top-left
# entry is exactly T_d(x), so <Zbar> must equal 2*T_d(x)^2 - 1. Use INTERIOR x:
# at the extremal cos(k*pi/d) points T_d = +-1 and the agreement is free.
for x in 0.3 0.7 0.9 -0.35; do
  "$QBIN" logical qsp --degree 3 --x $x --backend statevector
done

# --- added 2026-08-04: colour-code memory + the noise→precision through-line ---

# Does the colour family actually buy error suppression? MWPM does not apply to
# colour codes, so this decodes with BP+OSD.
for d in 3 5 7; do
  "$QBIN" logical memory --code color --distance $d --noise depolarizing \
      --p 0.02 --shots 4000 --seed 99
done

# --- added 2026-09-04: the colour sub-threshold SLOPE (QEC_PLAN §6 P2) ---
# The rows above show pL FALLS with distance. This shows it falls at the rate
# the distance promises: the log-log slope of pL(p) should track (d+1)/2 and
# must STEEPEN with d. A code could pass the ordering check while suppressing
# error no faster at d=7 than at d=3.
cslope() {  # $1=distance $2=shots, rest = physical rates
  D=$1; SH=$2; shift 2; ACC=""
  for P in "$@"; do
    R=$("$QBIN" logical memory --code color --distance "$D" --noise depolarizing \
        --p "$P" --shots "$SH" --seed 11 | awk '/^logical_rate /{print $2}')
    # An empty or zero rate is the shot floor, not a measurement.
    [ -n "$R" ] && awk -v a="$R" 'BEGIN{exit !(a>0)}' || { echo MISSING; return; }
    ACC="$ACC $P:$R"
  done
  echo "$ACC" | awk '{n=0;sx=0;sy=0;sxx=0;sxy=0
    for(i=1;i<=NF;i++){split($i,a,":"); p=a[1]+0; pl=a[2]+0
      if(pl>0){x=log(p);y=log(pl);n++;sx+=x;sy+=y;sxx+=x*x;sxy+=x*y}}
    if(n>=2) printf "%.4f\n", (n*sxy-sx*sy)/(n*sxx-sx*sx); else printf "MISSING\n"}'
}
for d in 3 5 7; do echo "d=$d sub-threshold slope $(cslope $d 6000 0.04 0.06 0.09)"; done
# The falsifier: above threshold a bigger patch is WORSE, so the ordering must
# not merely weaken — it must invert.
for d in 3 5 7; do echo "d=$d above-threshold slope $(cslope $d 4000 0.20 0.25 0.30)"; done
# And the typo guard: anything that is not color|surface must be REFUSED, not
# silently run as the surface code (which is what this arm used to do).
"$QBIN" logical memory --code colour --distance 3 --shots 10; echo "rc=$?"

# THE THROUGH-LINE: hardware noise → residual logical error → end-to-end
# precision, with the encoded and unencoded answers at the SAME physical rate.
for d in 3 5 7; do "$QBIN" logical precision --distance $d --p 0.02 --algo grover; done
# The crossover — above threshold the benefit must DISAPPEAR. Without this row
# "encoding helps" holds at whatever p you pick and proves nothing.
"$QBIN" logical precision --distance 3 --p 0.30 --algo grover

# --- added 2026-09-03: the SAME chain with per-gadget circuit noise ---
# Everything above applies the residual logical rate ONCE, at readout. Every
# algorithm there has a delta ideal, so its metric collapses to 1-(1-b)^n and
# `--algo qft` and `--algo qpe` return byte-identical numbers: that path is the
# memory rate in algorithm-facing units, nothing more. `--method circuit`
# applies noise at every logical gadget and lets it PROPAGATE through the rest
# of the circuit, so depth and connectivity move the answer.
for a in qft qpe; do
  "$QBIN" logical precision --method circuit --algo $a --distance 3 \
      --p 0.02 --shots 400 --seed 99
done
# The falsifier, at the one p where it is testable — see the caution below.
"$QBIN" logical precision --method circuit --algo grover --distance 3 \
    --p 0.15 --shots 2000 --seed 99
# And the refusal: the surface family has no transversal H, which Grover opens
# with, so there is no honest noise schedule for it.
"$QBIN" logical precision --method circuit --algo grover --code surface \
    --distance 3 --p 0.02 --shots 50; echo "rc=$?"
```

Expected output (numeric; Grover/QFT/QPE are deterministic, memory is seeded):

| Line | Expected | Tolerance |
|------|----------|-----------|
| `grover … success` (all 4 marked) | `1` | exact |
| `grover marked=2 zbar0/zbar1` | `1.000000` / `-1.000000` | ± 1e-6 |
| grover pauliprop vs statevector `zbar1` | equal | ± 1e-6 |
| `qft_uniform_maxdev` (n=4) | `~2.8e-17` (QFT of a basis state is uniform) | ≤ 1e-9 |
| `roundtrip_recovered` | `1.000000` (QFT∘QFT⁻¹ = id) | ≥ 0.999999 |
| `qpe phase_error` (φ=0.25, m=3) | `0` | ≤ 1e-6 |
| `qpe estimate/peak_prob` (φ=0.625, m=4) | `0.625` / `1.0` | est ± 1e-6, peak ≥ 0.999 |
| `memory logical_rate` d=3 (neutral-atom, p=0.06) | `~0.064` | ≤ 0.09 |
| `memory logical_rate` d=5 vs d=3 | d=5 **<** d=3 (distance suppression) | strict `<` |
| `p_lz > p_lx` (extracted channel, neutral-atom) | ZZ-biased ⇒ phase errors dominate | strict `>` |
| `grover --code color -d 3/5/7` `data_qubits` | `14` / `38` / `74` (= `2·(3d²+1)/4`) | exact |
| `grover --code color` `zbar0`/`zbar1` (marked=2) | `1.000000` / `-1.000000` | ± 1e-6 |
| colour Grover across statevector / mps / pauliprop | identical `zbar0`,`zbar1` | ± 1e-6 |
| `magic logical_zero_codewords` | `16 weights [0, 8]` | exact |
| `magic transversal_t phase0` / `phase1` | `-0.000000` / `-0.785398` (= −π/4 ⇒ logical **T†**) | ± 1e-6 |
| `magic transversal_t norm0` / `norm1` | `1.000000` / `1.000000` | ± 1e-6 |
| `magic derived_exponent` / `derived_coeff` / `weight4_logical` | `3` / `35` / `0` | exact |
| `magic mc_accept` vs `exact_accept` (2e6 rounds, p=0.05) | `0.4655` vs `0.4661` | \|Δ\| ≤ 0.002 |
| `magic mc_p_out` vs `exact_p_out` | `5.110e-3` vs `5.140e-3` | rel ≤ 0.05 |
| `magic cubic_p_out` vs `exact_p_out` | `4.375e-3` **<** `5.140e-3` (cubic law is optimistic) | strict `<` |
| `magic p_out` (p=1e-3, 1 round) | `3.500000e-8` (= 35p³) | exact |
| `qsp zbar` vs `classical` vs `cheb_2t2m1` | all equal (x=0.3 ⇒ `0.254528000`) | ± 1e-9 |
| `qsp` \|`zbar`\| at interior x | **< 0.999** (not an extremal point) | strict `<` |
| `memory --code color` `logical_rate` d=3/5/7 | `0.014000` / `0.002750` / `0.000750` | strictly decreasing |
| `memory --code color` `n_data` d=3/5/7 | `7` / `19` / `37` (= `(3d²+1)/4`) | exact |
| colour **sub-threshold slope** d=3/5/7 (p∈{0.04,0.06,0.09}, 6000 shots, seed 11) | `1.7751` / `2.2811` / `3.0734` | ± 0.05, and **strictly increasing** |
| colour sub-threshold slope vs `(d+1)/2` = 2/3/4 | each within `[(d+1)/2 − 1.0, (d+1)/2 + 0.5]` | see the caution below |
| colour **above-threshold slope** d=3/5/7 (p∈{0.20,0.25,0.30}, 4000 shots) | `0.5849` / `0.4481` / `0.2810` | strictly **decreasing**, all < 1.0 |
| `memory --code colour` (British spelling) | `--code must be color or surface (got colour)` | `rc=1` |
| `precision` `p_physical` (neutral-atom, p=0.02) | `0.010000` (= `p_bit`, the bare READOUT-flip rate) | ± 1e-6 |
| `precision` `p_logical` d=3/5/7 (X-sector) | `0.002750` / `0.000750` / `0.000000` | strictly decreasing |
| `precision` `p_logical_total` d=3/5/7 (both sectors) | `0.011250` / `0.002250` / `0.000000` | strictly decreasing |
| `precision` `error_encoded` d=3/5/7 | `0.005492` / `0.001499` / `0.000000` | ± 1e-6 |
| `precision` `error_unencoded` (all d) | `0.019900` | ± 1e-6 |
| `precision` `error_clean` (all d) | `0.000000` | ≤ 1e-9 |
| `precision` `encoding_helped` at p=0.02 | `1` | exact |
| `precision` at **p=0.30**: `p_logical` vs `p_physical` | `0.234000` **>** `0.150000` | strict `>` |
| `precision` at **p=0.30**: `encoding_helped` | **`0`** — the benefit vanishes | exact |
| `precision --distance 9` / `--shots 0` / `--p 2.0` | rejected, exit 1 | non-zero exit |
| `precision --method circuit` `exposures` qft / qpe (d=3) | `60` / `54` | exact |
| `precision --method circuit` `error_encoded` qft / qpe | `0.318125` / `0.273750` | ± 1e-6 |
| `precision --method circuit` `error_encoded` qft **vs** qpe | **differ** by `0.044375` | \|Δ\| > 0.01 |
| `precision --method circuit` `error_unencoded` qft / qpe | `0.619987` / `0.545076` | ± 1e-6 |
| `precision --method circuit` `error_clean` (both) | `0.000000` | ≤ 1e-9 |
| `precision --method circuit` `clean_frac_encoded` qft / qpe | `0.5400` / `0.5800` | ± 0.001, and **< 1** |
| `precision --method circuit` `encoding_helped` at p=0.02 | `1` | exact |
| `precision --method circuit` at **p=0.15** (grover, 2000 shots) | `error_encoded 0.744000` **>** `error_unencoded 0.675500` | strict `>` |
| `precision --method circuit` at **p=0.15**: `encoding_helped` | **`0`** | exact |
| `precision --method circuit --code surface` (grover) | refuses, naming the missing transversal H | `rc=2` |

Six cautions on the rows above, each of which was a trap:

* **d=7's `p_logical 0.000000` is the Monte-Carlo floor, not an exact claim** —
  zero failures in 4000 shots. Check the *non-zero* d=3/d=5 rows; a comparison
  against a shot-floor zero would pass for any implementation.
* **The p=0.30 row is the falsifier and is not optional.** Encoding helps
  exactly when the residual falls below the physical rate; a manual that only
  showed the p=0.02 rows would demonstrate a tautology.
* **The colour slope sits ~20% BELOW (d+1)/2, and that is physics, not a bug.**
  The `p^((d+1)/2)` law only dominates as `p → 0`, and this window is close to
  threshold. The same fit over the lower window {0.03, 0.04, 0.06} at 20 000
  shots gives `1.79 / 2.65 / 3.44` — converging toward 2/3/4 from below. The
  lower window is not what the manual runs, because deeper sub-threshold d=7
  hits the **shot floor** (~21 failures in 20 000 shots) and its slope swings
  `3.78 / 3.36 / 3.14` across seeds 11/99/4242 — a tolerance tight enough to
  mean anything would be flaky. What is checked is the ordering (which is
  rock-stable) plus a band wide enough to admit the approach from below.
* **The `--code colour` row is not pedantry.** Until 2026-09-04 this arm treated
  *any* value that was not exactly `color` as **surface**, so a typo — and this
  document spells it "colour" in prose throughout — silently measured the wrong
  code family. The header line said `code=surface`, but a gate grepping
  `logical_rate` (ci.sh has several) would have taken surface numbers as colour
  ones. Verified: before the guard, the CI slope gate run with `--code colour`
  produced surface slopes instead of failing.
* **The `--method circuit` falsifier is at p=0.15, and the p matters.** That is
  the one regime where the claim is testable, and both guards are printed: the
  per-round rates have genuinely crossed — `p_logical` measures 0.083–0.087
  against `p_bit 0.075` across seeds 1/99 at 2000 and 4000 shots, so the
  inequality holds however you sample it rather than at one lucky invocation
  (`0.086` from `logical precision --distance 3 --p 0.15 --algo grover
  --shots 2000 --seed 99`; `0.082750` at `--shots 4000`)
  AND `error_unencoded 0.6755` is still under this metric's own ceiling (a
  uniform 2-qubit output scores 0.75). At **p=0.10** the rates have *not*
  crossed (`p_logical 0.0465 < p_bit 0.05`) yet `encoding_helped` already reads
  `0` — the metric saturates before the rates do — so the verdict there is not
  attributable to the crossover and shows nothing. (It is not stable either,
  but that is the lesser objection: 20/20 seeds read `0` at `--shots 400` and
  at `--shots 2000`, while at `--shots 800` one seed in 20 reads `1`.) At
  **p=0.25** both sides sit on the ceiling (`0.735` vs `0.7275` at
  `--shots 400 --seed 99`) and the verdict genuinely flips with the seed —
  7 of 20 seeds say helped in one sample, 13 of 30 in another — so the
  comparison resolves nothing. Neither would be evidence, and a manual that
  used one of them would look green for the wrong reason.

  The chosen point, by contrast, is **stable**: at p=0.15 with `--shots 2000`,
  `encoding_helped` reads `0` for **20 of 20** seeds. That is the row to
  re-measure if this ever starts failing — a flip there means the crossover
  moved, not that the seed was unlucky.
* **The two methods are not interchangeable and their numbers are not
  comparable.** `--method delta` reports `error_encoded 0.005492` at d=3 where
  `--method circuit` reports `0.318125` for qft — a factor of 58, because the
  noise acts across 60 gadget exposures instead of once at readout. Neither is
  wrong; they answer different questions. The method is printed on the header
  line for exactly this reason.
* **`p_logical` is the X-sector rate, `p_logical_total` both sectors.** A
  logical Z failure does not flip a Z-basis readout, and the neutral-atom preset
  makes Z dominant by design, so the total overstates the readout error ~4x
  (`0.011250` vs `0.002750` at d=3). Likewise the bare baseline is `p_bit`, not
  `p_bit + p_phase` — the latter is a union *bound*, counts the readout-inert Z
  sector, and exceeds 1 for `p > 2/3`.
* **`precision` uses the default `--seed 1`** while the `memory --code color`
  block above passes `--seed 99`, which is why d=3 reads `0.011250` there and
  `0.014000` here — different seeds *and* different noise models
  (neutral-atom `p_bit+p_phase = 0.03` vs depolarizing `0.04` at the same `p`).
  Both are correct; do not "fix" one to match the other.

Reference values for the added lines (x=0.3/0.7/0.9/−0.35 respectively):
`zbar = 0.254528000 / 0.059968000 / -0.906688000 / 0.543524500`.

Three things these numbers are chosen to make falsifiable rather than
decorative. The colour-code rows pin the **physical width** as well as the
logical readout, because a wrong code would still "succeed" on ⟨Z̄⟩ at the wrong
size. The `magic` phase is read as the relative phase of the two logical
amplitudes, *not* as ⟨Y^⊗15⟩ — the logical `Ȳ ≡ iX̄Z̄ = −Y^⊗15`, so a naive
Y-string measurement returns `+1/√2` and yields the opposite (wrong) conclusion
about which gate transversal T implements. And the QSP rows use interior `x`,
because at `x = cos(kπ/d)` the polynomial is `±1` and any implementation agrees.

The headline numerics: **encoded Grover recovers every marked state exactly**
(the algorithm runs correctly *through* the code), **QPE resolves `φ=k/2ᵐ` to a
clean delta**, and the **surface-code memory suppresses logical error with
distance** under a hardware-flavored (ZZ-biased) noise model whose extracted
effective logical channel is phase-dominated. The dist demo is
`quantum-examples/demo/14-logical/run.sh` (15 numeric checks); the Rust twins are
the `logical::` unit tests (`cargo test -p quantum-core --features omega-sim
--lib logical::`).

#### 7.3a″ The §6 through-line as ONE story (stripped dist binary)

`QEC_PLAN.md` §6 is a chain of three arrows — **hardware noise → residual
logical error → end-to-end precision**. §7.3a′ above checks the endpoints; this
checks the **links**, which is the part that can rot silently. Everything here
runs from `$QBIN`, i.e. the shipped stripped binary, not `cargo run`.

The `noise_to_precision` example walks the same chain with more commentary, but
it is a **cargo example and is therefore not in a binary-only dist** — so it is
gated in `ci.sh` step 2 instead, and this section is the dist-artefact half.

```bash
QBIN="$QUANTUM_DIST/bin/quantum"

# Arrow 1 -> 2 -> 3, one line per algorithm. d=5, neutral-atom, p=0.02.
for a in grover qft qpe; do
  "$QBIN" logical precision --distance 5 --p 0.02 --algo $a --shots 4000 --seed 1
done

# The LINK from arrow 2 to arrow 3, checked rather than asserted: under
# --method delta every algorithm here has a delta ideal, so its error is
# exactly 1-(1-p_logical)^n. Recompute it independently and compare.
for a in grover:2 qft:3 qpe:3; do
  ALGO=${a%%:*}; N=${a##*:}
  OUT=$("$QBIN" logical precision --distance 5 --p 0.02 --algo $ALGO \
        --shots 4000 --seed 1 | tail -1)
  echo "$OUT" | awk -v n="$N" -v algo="$ALGO" '{
    seen=1
    for(i=1;i<=NF;i++){if($i=="p_logical")pl=$(i+1); if($i=="error_encoded")ee=$(i+1)}
    want=1-(1-pl)^n; d=ee-want; if(d<0)d=-d
    printf "%s: error_encoded %.6f vs 1-(1-%.6f)^%d = %.6f  |delta| %.2e\n", algo, ee, pl, n, want, d
    if(d>5e-6) print "  LINK BROKEN"}
    END{if(!seen) print "NO OUTPUT — gate would have passed on nothing"}'
done

# And the contrast: --method circuit BREAKS that link on purpose, because the
# noise acts at every logical gadget instead of once at readout.
"$QBIN" logical precision --method circuit --algo qft --distance 3 --p 0.02 \
    --shots 400 --seed 99
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `p_physical` (all three algorithms) | `0.010000` — hardware `p=0.02` ⇒ `p_bit = p/2` on the neutral-atom preset | ± 1e-6 |
| `p_logical` at d=5 (all three) | `0.000750` — decoded residual, BP+OSD | ± 1e-6 |
| `error_encoded` grover / qft / qpe | `0.001499` / `0.002248` / `0.002248` | ± 1e-6 |
| `error_unencoded` grover / qft / qpe | `0.019900` / `0.029701` / `0.029701` | ± 1e-6 |
| **the link** `error_encoded` vs `1−(1−p_logical)^n` | equal for all three (measured Δ 4.4e-7 / 3.1e-7 / 3.1e-7) | \|Δ\| ≤ 5e-6 — see the caution |
| `qft` vs `qpe` under `--method delta` | **identical** (`0.002248` both) — same width, and width is all this path sees | exact |
| `qft` under `--method circuit` | `0.318125` — 141× the delta value, because 60 gadget exposures replace one readout flip | ± 1e-6 |

Two things this section exists to catch, neither visible from the endpoints:

* **Why 5e-6 and not 1e-9.** The identity is EXACT in the code, and the unit
  test `every_metric_is_the_same_closed_form_so_the_layer_adds_no_information`
  checks it at 1e-9 on the real numbers. From the CLI you cannot: `p_logical` is
  printed rounded to six decimals and `d(error)/d(p_logical) ≈ n`, so
  recomputing from the printed value can only agree to about `n × 5e-7`. A 1e-9
  threshold here reports LINK BROKEN on a perfectly correct build — measured, on
  the first run of this block. The tolerance tracks the printed precision, not
  the physics.
* **A broken link.** If `error_encoded` ever stops equalling `1−(1−p_logical)^n`
  under `--method delta`, something between the decoder and the metric changed
  — and because both endpoints would still look plausible, nothing else in the
  manual would notice. The awk carries a `seen` flag, so a subcommand that
  disappears prints `NO OUTPUT` instead of passing silently.
* **The two methods collapsing into one.** `qft` and `qpe` MUST agree under
  `delta` (that path sees only the width) and MUST differ under `circuit`. If
  they ever agree under `circuit`, the per-gadget layer has quietly degenerated
  back into a readout flip and the whole §6 P4 follow-up is decorative again.

#### 7.3a‴ External cross-validation: colour decoder vs chromobius (opt-in)

`QEC_PLAN.md` §6 P6. Checks our BP+OSD colour-code decoder against
[chromobius](https://github.com/quantumlib/chromobius), the purpose-built
colour-code decoder, **on the same syndromes**. Opt-in because it needs a Python
venv; the repo's default posture is pure Rust.

```bash
# Needs stim + chromobius + qiskit; run.sh creates tools/qec_cross_check/.venv
# itself. Behind a TLS-intercepting proxy, point pip at the proxy CA rather than
# disabling verification -- pip reads PIP_CERT natively. On the Linux/CUDA box
# that CA is /home/pc/.config/pxpipe/mitm-ca.pem. Verified both ways: a fresh
# --no-cache-dir download succeeds with it and fails CERTIFICATE_VERIFY_FAILED
# without it. QEC_XCHECK_PIP_ARGS (--trusted-host) is a LAST resort, for a host
# where no CA can be obtained at all.
PIP_CERT=/home/pc/.config/pxpipe/mitm-ca.pem \
    bash tools/qec_cross_check/run.sh 3000 11

# Same thing through CI:
QUANTUM_QEC_XCHECK=1 ./scripts/ci.sh
```

Expect the banner `QEC-XCHECK OK — chromobius (decoder), stim (Clifford), Qiskit (QSP)`, exit
`0`, and these numbers (depolarizing p=0.02, 3000 shots, seed 11):

| Line | Expected | Tolerance |
|------|----------|-----------|
| d=3 non-trivial agreement X / Z | `1.0000` / `1.0000` (424 / 389 shots) | ≥ 0.99 |
| d=5 non-trivial agreement X / Z | `0.9980` / `0.9979` (985 / 974 shots) | ≥ 0.99 |
| d=7 non-trivial agreement X / Z | `0.9994` / `1.0000` (1613 / 1605 shots) | ≥ 0.99 |
| d=3 pL ours / chromobius | `0.013667` / `0.013667` | \|Δ\| ≤ 3σ = 0.008993 |
| d=5 pL ours / chromobius | `0.005000` / `0.005000` | \|Δ\| ≤ 3σ = 0.005464 |
| d=7 pL ours / chromobius | `0.001333` / `0.001000` | \|Δ\| ≤ 3σ = 0.002644 |
| d=7 disagreements X | `1`, bounded by "ours 1 + theirs 0" | see the theorem below |
| non-trivial syndrome count, every d | ≥ 20 per sector, else the run **fails** | exact |

The same run also checks the **transversal Clifford gadgets** against stim, by
conjugation (exact — no sampling):

| Line | Expected | Tolerance |
|------|----------|-----------|
| `H^n logical` d=3/5/7 | `True` — preserves the code and swaps the CSS sectors | exact |
| `S^n flips == weight-6 faces` | `True` at every d; flipped sets `[]` / `[1,5,6]` / 9 of 18 | exact set equality |
| `split-S logical` d=3/5/7 | `True` — `S` on sublattice 0, `S†` on sublattice 1 | exact |
| random 2-colourings passing, d=5 / d=7 | `0/200` / `0/200` | must be **0** |
| random 2-colourings passing, d=3 | `20/200` — not gated, see below | — |
| `H maps Xbar->Zbar` | `True` | exact |
| banner | `STIM-XCHECK OK` | exact |

`S^n` failing on exactly the weight-6 faces is an independent confirmation of
§4a *and of its mechanism*: `S X S† = Y`, and `Y^⊗6 = −X^6Z^6` while
`Y^⊗4 = +X^4Z^4`. Steane (d=3) has only weight-4 faces, which is precisely why
`S^⊗7` works there and nowhere above. The `0/200` rows are the falsifier for
the split gadget — "some 2-colouring works" is much weaker than "this one
does", and without them check (3) would not distinguish the two. At d=3 the
count is `20/200` and deliberately ungated: with no weight-6 faces `S^⊗n`
already works, so the constraint really is weak there and demanding `0` would
assert something false.

The same run also cross-checks the **encoded QSP circuit against Qiskit**. This
is the non-Clifford half: QSP's `Rz` rotations mean a stabilizer simulator
cannot represent the circuit at all, so stim structurally cannot check it.

| Line | Expected | Tolerance |
|------|----------|-----------|
| steane d=3 deg 3 x=0.3 — ours / qiskit / analytic | `+0.254528000` all three | \|q−a\| ≤ 1e-9 (measured 1.19e-10) |
| steane d=3 deg 3 x=0.7 | `+0.059968000` all three | measured 9.50e-11 |
| steane d=3 deg 4 x=−0.35 | `−0.960771995` all three | measured 2.13e-11 |
| steane d=3 deg 5 x=0.42 | `+0.369002712` all three | measured 2.32e-10 |
| color d=5 deg 3 x=0.3 | `+0.254528000` all three | measured 1.19e-10 |
| color d=5 deg 4 x=0.65 | `+0.812417605` all three | measured 9.11e-11 |
| `\|ours − analytic\|`, every config | `0.00e+00` exactly | exact |
| banner | `QISKIT-XCHECK OK` | exact |

**Three-way, not simulator-vs-simulator.** With all-zero phases the sequence is
`W^d`, so `⟨Z̄⟩ = 2·T_d(x)² − 1` is arithmetic. Two simulators agreeing with
each other is weaker evidence than either agreeing with the closed form, so both
edges are checked and both are in the table.

**Interior `x` only, enforced.** At `|T_d(x)| = 1` the expectation is `+1` for a
correct circuit *and* for one broken by a sign. The script **fails** on an
extremal `x` rather than banking the free pass — verified: `--x 1.0` exits 1
with "an extremal point where the comparison is free".

**Endianness is checked before anything else.** Qiskit Pauli labels are
little-endian (rightmost character is qubit 0); building the label in index
order evaluates a different-but-valid Pauli string, so nothing raises and every
number is silently wrong. The script proves the convention on `|01⟩` first —
verified that the index-order label gives `+1` where the correct one gives `−1`.

**Capped at d=5.** The colour code is 37 physical qubits at d=7, so a
statevector would be 2³⁷ amplitudes.

Three things about this section that are not decoration:


* **Agreement is reported on NON-TRIVIAL syndromes.** Counting all-zero
  syndromes measures how often the error was undetectable, not whether the
  decoders agree — at p=0.02 they are the large majority of shots, and including
  them inflates d=5 from `0.9980` to `0.9993`. A batch with fewer than 20
  non-trivial syndromes per sector exits 2 rather than reporting a vacuous
  100%.
* **The theorem is the real check.** If both decoders succeed on a shot, both
  predictions equal the actual logical flip, so they *cannot* disagree — hence
  every disagreement must be a shot where at least one decoder failed. The
  script asserts it, and it is what catches a mis-wired comparison (wrong
  detector order, swapped sector, mis-indexed observable), all of which would
  produce disagreements on shots both decoders got right. At d=7 the single
  X-sector disagreement is bounded by "ours 1 + theirs 0" — exactly the one shot
  our decoder lost and chromobius did not.
* **p=0.05 is deliberately NOT gated.** The ≥99% criterion is a statement about
  decoders that mostly succeed. There both fail several percent of the time and
  agreement drops to `0.9899`/`0.9878` — while **both rate matches still pass at
  3σ** and disagreements stay well inside the combined failure count (d=7: 31
  against ours 47 + theirs 62). That is the criterion expiring outside its
  regime, not a decoder defect. Gating it would be measuring the wrong thing.

#### 7.3b Pauli-propagation expectation values (`quantum expect`)

`quantum expect <circuit> --observable "Z0,Z1Z2" [--backend B] [--truncate C]
[--max-weight W] [--max-dropped-mass M]`
computes `⟨O⟩` for Pauli observables. The headline backend is **`pauliprop`**
(Pauli propagation — a Heisenberg-picture Pauli-string tree): exact and
width-unbounded for Clifford circuits, a `--truncate`-tunable approximation for
non-Clifford ones (`statevector`/`mps` are the dense cross-checks). Like `ecc`
it needs `omega-sim`; the expectation backend gets the larger ECC qubit cap, the
dense backends the general cap.

```bash
# The binary comes from the dist, but these .qasm inputs live in the REPO —
# only the `QUANTUM_TEST` bundle ships a `demo/` directory. Run this block
# from the repo root (or point QDEMO at a checkout).
QBIN="$QUANTUM_DIST/bin/quantum"
QDEMO="${QDEMO:-$PWD}"
cd "$QDEMO"
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend pauliprop  --observable "Z0,Z2,Z0Z5,Z1Z2Z3"
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend statevector --observable "Z0,Z2,Z0Z5,Z1Z2Z3"
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend pauliprop  --observable "Z2" --truncate 1e-2
"$QBIN" expect demo/13-pauliprop/ghz24.qasm         --backend pauliprop  --observable "Z0Z23,Z0"

# A truncation whose bound EXCLUDES NOTHING is refused, not returned. The
# engine reports <O> in [v-m, v+m]; a Pauli string already satisfies
# <O> in [-R, R] with R = 1, so the run learns nothing exactly when
# m >= R + |v|. Here m = 2.0611 against a ceiling of 1 + 0.7055 = 1.7055.
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend pauliprop  --observable "Z2" --truncate 1e-1
echo "exit=$?   # expect 1"

# The escape hatch, for a deliberate cutoff sweep where the loose rows are the
# point — they are what shows that tightening the cutoff buys information.
"$QBIN" expect demo/13-pauliprop/trotter_ising.qasm --backend pauliprop  --observable "Z2" --truncate 1e-1 --max-dropped-mass inf
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `observable …` (pauliprop) vs (statevector) on the Ising circuit | identical for every observable | exact (≤ 1e-9) |
| `observable Z2` / `dropped_mass` (Ising, `--truncate 1e-2`) | `0.6945467372` / `0.4700564981`, and `\|approx − exact\| ≤ dropped_mass` | exact bound |
| `--truncate 1e-1` with no ceiling override | **refused**, `exit=1`, message naming `2.0611e0` against ceiling `1.7055e0` | exact |
| `--truncate 1e-1 --max-dropped-mass inf` | `observable Z2 = 0.7054827807`, `dropped_mass 2.0611179454` | exact |
| `observable Z0Z23` / `Z0` (24-qubit GHZ, pauliprop) | `1.0000000000` / `0.0000000000` | exact |
| statevector on the 24-qubit GHZ | refused under the eval cap (exit 2) — or, uncapped, equals pauliprop | exact |

The Rust twin is `omega-backend-pauliprop`'s `tests/expectation.rs` (8 checks);
the dist demo is `demo/13-pauliprop/run.sh` (5 checks). The same backend is
selectable in `omega-run --backend pauliprop --expectation "<Pauli>"`.

### 7.4 Benchmarks (criterion)

```bash
# Compile check only (fast):
cargo bench -p quantum-core --bench optimizer   --no-run
cargo bench -p quantum-core --bench statevector --no-run

# Full run (slow — statistical sampling):
cargo bench -p quantum-core --bench optimizer
```

Coverage:
- `optimizer` — `passes_random_clifford_t/{default_pipeline,internal_h_opt}` on Clifford+T at 4q/64g, 6q/128g, 8q/256g; `qft_roundtrip_optimize` for n ∈ {3,5,7}
- `statevector` — CPU baseline for n ∈ {12,14,16,18} (GPU baseline for the item-8 doc)

### 7.4b QML benchmark matrix + regression gate (GPU_PLAN Phase 9)

Times forward eval + three gradient methods per `{device, n}` on a
data-reuploading circuit, emits JSON, and gates on regression vs a committed
per-host baseline. Requires libtorch (`source scripts/env.sh`).

```bash
# Print the bench matrix as JSON:
cargo run -q -p quantum-qml --example bench_matrix

# Regenerate this host's baseline (only when intentionally re-baselining):
./scripts/bench-compare.sh --regen

# Run the regression gate against the committed baseline (what CI stage 12 does):
./scripts/bench-compare.sh ; echo "exit=$?"
```

**Numeric checks** (the gate compares against **this host's** baseline —
`docs/bench-baselines/macos-aarch64.json` on the mac box,
`docs/bench-baselines/linux-x86_64.json` on the Linux box):
- Gate exit code is **0** (no metric ≥ 1.5× its baseline). Re-run 2–3×: stays 0.
- The scaling signature holds on every run: **`adjoint_ms_per_param` is roughly
  flat in `n`** while **`param_shift_ms_per_param` grows steeply** — adjoint is
  one reverse sweep, param-shift is `2k` full simulations. The absolute
  milliseconds and the ratio are **host-specific**; gate on the shape, not on
  the mac's constant:

  | Host | adjoint n=4/6/8 (ms) | param_shift n=4/6/8 (ms) | ratio at n=8 | Gate |
  |---|---|---|---|---|
  | macos-aarch64 | ~0.04 → ~0.05 → ~0.05 | ~0.43 → ~2.0 → ~10 | ~200 | `> 100` |
  | linux-x86_64 (measured 2026-09-03) | 0.048 → 0.052 → 0.079 | 0.270 → 1.223 → 5.966 | **64–76** | `> 40` |

  On **either** host `param_shift_ms_per_param` must grow by **≥ 15×** from
  n=4 to n=8 while `adjoint_ms_per_param` grows by **≤ 3×**. That is the claim
  ("adjoint is asymptotically cheaper"); the `> 100` figure was measured only
  on the mac and does **not** hold on linux-x86_64 — its faster
  param-shift path puts the ratio at ~75, and gating on `> 100` there fails a
  correct build.
- `batched_ms_per_param < param_shift_ms_per_param` at every `n` (batching the
  `2k` shifted vectors beats sequential evaluation).
- Strict 20% gate on a quiesced host: `QUANTUM_BENCH_FACTOR=1.20
  ./scripts/bench-compare.sh` also exits 0.

> **No GitHub CI.** GPU_PLAN Phase 9.4 (`gpu-ci.yml`) is intentionally **not**
> created — per the project rule, CI is the local `scripts/ci.sh` only. The
> gate runs as ci.sh **stage 12**, opt-in via `QUANTUM_BENCH=1`.

### 7.4c Reproduced-papers parity runner (item 12b)

Runs each ported gate-model paper and reports a headline metric vs a reference
with PASS/FAIL (`docs/reproduced-papers.md`). Requires libtorch.

```bash
source scripts/env.sh
cargo run -q -p quantum-qml --example papers_runner ; echo "exit=$?"
cargo run -q -p quantum-qml --example papers_runner -- qSSL     # single paper
# Recurrent rows are gated on the WORST of seeds 0–4 (TODO §24(a3)); the spread
# line prints above each row. Expect, verbatim (deterministic on CPU):
cargo run -q -p quantum-qml --example papers_runner -- QLSTM | grep 'seeds\|frozen'
#   QLSTM seeds [0, 1, 2, 3, 4]: l₁/l₀ min 0.0319 median 0.1451 max 0.3318 (worst seed 0)
#   QLSTM frozen-quantum (head-only): s0 0.4929 s1 0.7663 s2 0.3090 s3 0.3543 s4 0.7401 — min 0.3090 max 0.7663 (worst seed 1); 3/5 seeds clear 0.6
cargo run -q -p quantum-qml --example papers_runner -- QRNN | grep 'seeds\|frozen'
#   QRNN  seeds [0, 1, 2, 3, 4]: l₁/l₀ min 0.0084 median 0.0143 max 0.0437 (worst seed 0)
#   QRNN  frozen-quantum (head-only): s0 0.1684 s1 0.1299 s2 0.3414 s3 0.1051 s4 0.1969 — min 0.1051 max 0.3414 (worst seed 2); 5/5 seeds clear 0.6
# Seed plumbing + worst-of-5 gates (3 new tests; the two seed-0 tests are kept):
cargo test -q -p quantum-qml --test papers -- qlstm qrnn recurrent 2>&1 | grep -E '^test result'
#   test result: ok. 5 passed; 0 failed; ...
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| QLSTM seeds line | `min 0.0319 median 0.1451 max 0.3318 (worst seed 0)` | exact (4 dp) |
| QRNN seeds line | `min 0.0084 median 0.0143 max 0.0437 (worst seed 0)` | exact (4 dp) |
| QLSTM frozen-quantum line | `s0 0.4929 s1 0.7663 s2 0.3090 s3 0.3543 s4 0.7401`, `3/5 seeds clear 0.6` | exact (4 dp); comparator only, not a gate |
| QRNN frozen-quantum line | `s0 0.1684 s1 0.1299 s2 0.3414 s3 0.1051 s4 0.1969`, `5/5 seeds clear 0.6` | exact (4 dp); comparator only, not a gate |
| QLSTM / QRNN table rows | `0.331824 ≤ 0.600000 … PASS` / `0.043677 ≤ 0.600000 … PASS` | exact (6 dp) |
| last line | `PAPERS PARITY OK — 16/16 within reference`, `exit=0` | exact |

**Classical baseline column (TODO §24(a4)).** Every row prints one
`classical_baseline:` line, a number or `none (<reason>)`. It is a
comparator, not a gate on the row, and not an advantage claim.

```bash
OUT=$(cargo run -q -p quantum-qml --example papers_runner 2>/dev/null)
echo "$OUT" | grep '^CLASSICAL BASELINE'
#   CLASSICAL BASELINE: 16/16 rows reported (2 value, 14 none); 7 flagged CLASSICALLY-TRIVIAL
echo "$OUT" | grep -c '^  classical_baseline: '
#   16
echo "$OUT" | grep -c '^  classical_baseline: none (not computed yet'
#   6
echo "$OUT" | grep '^  classical_baseline: 0\.' | cut -c1-30
#     classical_baseline: 0.766263      (QLSTM)
#     classical_baseline: 0.341386      (QRNN)
```

| Check | Expected | Tolerance |
|------|----------|-----------|
| summary line | `16/16 rows reported (2 value, 14 none); 7 flagged CLASSICALLY-TRIVIAL` | exact |
| baseline lines | `16`, one per row | exact count |
| rows with no comparator yet | `6` (QCNN, HQNN, nn_embedding, QRKD, HQPINN, qLLM) | exact count |
| QLSTM baseline | `0.766263`, `baseline does not clear the bar` | exact (6 dp) |
| QRNN baseline | `0.341386`, `CLASSICALLY-TRIVIAL (baseline clears the bar)` | exact (6 dp) |

> `tch::manual_seed` is **process-global**. Under the default parallel test
> harness two seed-dependent tests clobber each other's RNG stream — measured:
> "seed 0" gave `0.0405` in one run and `0.3318` in another, same binary. CI
> runs this crate with `--test-threads=1`; the recurrent helpers additionally
> hold a `TCH_RNG` mutex from `manual_seed` through the last optimizer step,
> so the five tests above pass at any thread count (`16 passed` for the whole
> file at default threads). The reproducibility check in
> `recurrent_seed_sweep_is_not_one_seed_repeated` is an unconditional
> `assert!` (no `#[ignore]`, no thread-count branch): without the lock, a
> parallel run fails it loudly with both numbers rather than skipping. Any
> *new* seeded test in this file that does not take that lock is only
> deterministic in CI.
>
> The `frozen-quantum (head-only)` lines are the same five seeds with every
> quantum block's output `.detach()`ed (only the linear head trains). They are
> printed, not gated: QLSTM frozen fails 0.6 on seeds 1 and 4, QRNN frozen
> clears it on all five — the QRNN bar is a learnability bar, not evidence the
> quantum block contributes (`docs/reproduced-papers.md` § seed spread).

**Numeric checks:**
- Final line is `PAPERS PARITY OK — 16/16 within reference`, exit code **0**.
- Analytic metrics hit their closed form exactly: qSSL `max|⟨Z_i⟩−cos(x_i)| ≈ 0`
  (≤ 1e-10), data_reuploading `|⟨Z⟩ − cos(w₁)| ≈ 0` (≤ 1e-10), AA_study trace
  distance ≤ 0.01.
- Two entries were rewritten because their headline could not fail, and they are
  no longer analytic identities: **adversarial** (2026-08-08) now reports
  realized ÷ predicted FGSM margin `≈ 1.0` (tol 0.1) — the old `margin ≥ 0` was
  Hölder's inequality, non-negative for every finite vector; **QCNN**
  (2026-08-09) now reports held-out accuracy minus a shuffled-label control,
  `0.6458 ≥ 0.35` — the old `|⟨Z⟩| ≤ 1` was true for any normalized state and
  was evaluated on a circuit fed no input.
- Training-bar metrics clear their bars: HQNN loss ratio ≤ 0.8, nn_embedding
  separation gain ≥ 1.2, QRKD loss ratio ≤ 0.5, QLSTM/QRNN sequence loss ratio
  ≤ 0.6, HQPINN rel-L2 vs the analytic damped-oscillator solution ≤ 0.42,
  qLLM quantum-adapter accuracy ≥ 0.85 on an XOR task (all deterministic under
  `tch::manual_seed(0)`).
- These are also gated as unit tests: `cargo test -p quantum-qml --test papers -- --test-threads=1` → `13 passed`.

### 7.5 WASM guests

```bash
# All three:
for g in vqe qaoa ecc; do
  (cd examples/wasm-guests/$g && cargo build --release --target wasm32-wasip1)
done

# Sizes (expected):
ls -lh examples/wasm-guests/*/target/wasm32-wasip1/release/*.wasm
# vqe.wasm  ~90 KB,  qaoa.wasm similar, ecc.wasm uses omega_execute_shots

# Host imports must land in module "env" (what omega-wasm-runtime registers).
# rustc ≥ 1.97 / wasm-ld drops bare `extern "C"` imports unless the block is
# tagged `#[link(wasm_import_module = "env")]`; this counts the import-section
# entries (module name immediately followed by field name):
for g in vqe qaoa ecc; do
  printf '%s %s\n' "$g" "$(grep -a -o -E 'env.{1,2}omega_[a-z_]+' \
    examples/wasm-guests/$g/target/wasm32-wasip1/release/$g.wasm | sort -u | wc -l)"
done
# Expected (exact): vqe 5, qaoa 4, ecc 3
```

The ECC guest uses `omega_execute_shots` + repetition-code majority
vote across 5 physical-error probabilities; confirm with:

```bash
grep -n omega_execute_shots examples/wasm-guests/ecc/src/main.rs
```

---

## 8. Formal proofs

### 8.1 Lean4 — standalone (no mathlib, in CI stage 9)

23 Float-level theorems covering Pauli self-inverse, H² = I, HXH = Z,
HZH = X, XZ anti-commutation, S² = Z, Grover probability bounds,
DFT = Hadamard up to sign, CX/CZ correctness, QPE phase accuracy.

```bash
cd proofs/lean4
lean --run Standalone.lean | tail -2
# Expected trailing line: ✓ All quantum theorems verified (23 total)
```

Also: `lean --run Generated_Closed.lean` runs the closed-form Bell /
Deutsch-Jozsa / GHZ proofs (extracted from Aria via `spec extract`,
then hand-finished with `native_decide`) **plus the MBQC C4 circuit↔pattern
correspondence for Bell and GHZ** — `mbqc_cx_correct` (the gadget `(I⊗H)·CZ·(I⊗H)`
= CNOT), `bell_mbqc_correct` (Bell via MBQC primitives = (|00⟩+|11⟩)/√2),
`mbqc_ghz_gadgets_correct` (both CX gadgets = CX(0,1)/CX(1,2)), and
`ghz_mbqc_correct` (GHZ via primitives = (|000⟩+|111⟩)/√2), all `native_decide`
— **plus the general `denote_pattern` obligations** `bell_pattern_correct` /
`ghz_pattern_correct` (`denote_pattern` of the actual `circuit_to_pattern`
output = the circuit on the |+⟩ input, for Bell n=5 and GHZ n=8 patterns).
Expect six extra `✓ MBQC: …` lines before `All Generated_Closed proofs verified`.

### 8.2 Lean4 — mathlib-backed (opt-in, CI stage 11)

**Use the precompiled olean cache — never let lake rebuild from source.**
`./scripts/setup-mathlib.sh` calls `lake exe cache get` which pulls the
~500 MB of compiled `.olean` files from mathlib's Azure blob storage.

```bash
./scripts/setup-mathlib.sh             # idempotent; --force to re-resolve

# Then build the project's proofs (links against the cached oleans):
(cd proofs/lean4 && lake build QuantumProofs)
```

`Mathlib.olean` lands at `proofs/lean4/.lake/packages/mathlib/.lake/build/lib/lean/Mathlib.olean`.
The setup script also smoke-tests `QFT.lean` to verify the pin resolves
before declaring success.

Stage 11 is not mac-only: on the Linux box (akilles, 123 GB / 32 cores)
`QUANTUM_MATHLIB=1 ./scripts/ci.sh` went green end-to-end on 2026-09-29
(`=== CI completed in 1852s (7 skipped) ===`, the 7 being the Metal/OpenCL/
dist/Rocq/bench/scale opt-ins, not stage 11). Expected gate line, verbatim:
`✓ mathlib-backed proofs compile (QuantumProofs root sorry-free)`.

Current sorry count — **zero, in every file**. The table below used to list 11
deliberate sorries; `CircuitSemantics`, `QFT` (`qft_correct`), `QPE`, `Grover`,
`MBQC` (`gflow_determinism`) and `UBQC` have all since been closed, so the
whole `QuantumProofs` root is sorry-free. Verify it rather than trusting this
paragraph:

```bash
# Every file must print 0. Any non-zero is a regression.
for f in proofs/lean4/QuantumProofs/*.lean; do
    printf "%-28s %s\n" "$(basename "$f")" \
        "$(grep -cE '^[[:space:]]*sorry[[:space:]]*$' "$f")"
done
# Or as a single gate — expected output: `live_sorries 0`
echo "live_sorries $(cat proofs/lean4/QuantumProofs/*.lean \
    | grep -cE '^[[:space:]]*sorry[[:space:]]*$')"
```

(26 files as of 2026-07-31; the `sorry` substring still appears in prose
comments such as "Everything is sorry-free", which is why the check anchors on
a whole line.)

**Per-theorem `#print axioms` gates (stage 11a-corr1 / 11a-trackA / 11a-hgadget,
the gate-model specs, QEC).** The line-grep above is a text check; the real
enforcement is `#print axioms` on each named theorem, which must not mention
`sorryAx`. `HGadget.lean` (TODO §17(d) first lemma, 2026-09-29) got its own
block 2026-09-30 — all 10 theorems of the file, plus (2026-10-01) four
**non-vacuity witnesses**. `#print axioms` cannot see vacuity (a theorem whose
hypothesis is unsatisfiable is sorry-free and axiom-clean yet says nothing —
leanlift found three such adequacy theorems this week). The ten HGadget
statements were read for that: none carries a hypothesis (binders are only
`b : Fin 2`, `i j : Fin 4`), and every conclusion is an equality of closed
matrices. `braXcore_zero_ne_one`, `s_ne_zero`, `branch_ne_zero`, `branch_zero_ne_one`
pin the objects as non-degenerate (the two outcome projectors differ, `s ≠ 0`,
the branch map is not `0`, and the two outcome branches are different
operators), so `h_gadget_branch_prob`'s `1/2` is a real `1/2` and not `0 = 0`,
and the per-outcome theorems are two claims rather than one repeated.
Expected CI line, verbatim:
`✓ HGadget axiom-clean (14/14 theorems: per-branch (1/√2)·X^b·H + weight 1/2 + 4 non-vacuity witnesses, sorry-free)`.
Run it standalone (≈10 s once the mathlib cache is warm), expected output is
exactly 14 lines, none containing `sorryAx`:

```bash
( cd proofs/lean4 && printf 'import QuantumProofs.HGadget\nopen QuantumProofs.HGadget\n#print axioms denote_gadget\n#print axioms denote_gadget_apply\n#print axioms denote_gadget_eq\n#print axioms H_eq_smul_HCore\n#print axioms h_gadget_core\n#print axioms h_gadget_branch\n#print axioms core_conjTranspose_mul\n#print axioms star_s\n#print axioms s_mul_s\n#print axioms h_gadget_branch_prob\n#print axioms braXcore_zero_ne_one\n#print axioms s_ne_zero\n#print axioms branch_ne_zero\n#print axioms branch_zero_ne_one\n' \
    | lake env lean --stdin 2>&1 | tee /tmp/hg_ax.txt | wc -l )      # expect 14
grep -c sorryAx /tmp/hg_ax.txt                                        # expect 0
```

Prove the gate bites (verified 2026-09-30): replace the body of
`h_gadget_branch_prob` with `sorry`, rerun — the second line becomes `1` and
the offending line names `QuantumProofs.HGadget.h_gadget_branch_prob` with
`sorryAx` in its axiom list (`depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]`);
`git checkout proofs/lean4/QuantumProofs/HGadget.lean` and rerun — back to `0`.

**`HGadgetPush.lean` (TODO §17(d) second lemma, 2026-10-01) — CI stage
11a-hgadgetpush.** Eq. 5 of arXiv:2407.08695: `R_Z(θ)·X = X·R_Z(−θ) =
X·R_Z(−2θ)·R_Z(θ)`, plus `rz_branch_one_push` (the gadget's outcome-1 `X`
pushed forward through a later `R_Z`) and two non-vacuity witnesses
(`rz_pi_X_ne_comm`: `R_Z(π)` does *not* commute with `X`; `rz_ne_zero`).
Expected CI line, verbatim:
`✓ HGadgetPush axiom-clean (8/8 theorems: Eq. 5 R_Z(θ)X = X R_Z(−θ) = X R_Z(−2θ) R_Z(θ), outcome-1 X pushed forward, + R_Z(π)X ≠ X R_Z(π) witness, sorry-free)`.
Standalone, expect exactly 8 lines, none containing `sorryAx`:

```bash
( cd proofs/lean4 && printf 'import QuantumProofs.HGadgetPush\nopen QuantumProofs.HGadgetPush\n#print axioms rz_mul_rz\n#print axioms rz_zero\n#print axioms rz_X_comm\n#print axioms rz_X_eq5\n#print axioms rz_branch_zero\n#print axioms rz_branch_one_push\n#print axioms rz_pi_X_ne_comm\n#print axioms rz_ne_zero\n' \
    | lake env lean --stdin 2>&1 | tee /tmp/hgp_ax.txt | wc -l )     # expect 8
grep -c sorryAx /tmp/hgp_ax.txt                                       # expect 0
```

Gate bites (verified 2026-10-01): replace the body of `rz_X_comm` with
`sorry`, `lake build QuantumProofs.HGadgetPush`, rerun — the second line
becomes `3`: `rz_X_comm` itself and everything downstream of it
(`rz_X_eq5`, `rz_branch_one_push`) inherit `sorryAx`; restore with
`git checkout` and rebuild — back to `0`.

**`spec extract` output ELABORATES (CI stage 11f / 11f′, added 2026-08-29).**
Until `9dc96be` nobody had ever run Lean on what `quantum spec extract` writes:
stage 7c checked that `Bell.lean` *exists and contains* `def circuit : Circuit 2`,
and that exact file failed elaboration with five errors (dangling docstrings,
three un-imported obligation identifiers, an `equiv` goal against an undefined
`reference`). `.cp`/`.swap` were missing from the emitter, negative angles were
written unparenthesised (Lean reads `⟨a⟩ -0.78` as subtraction), and every
unbound `symbolic[…]` angle was silently written as `0.0`. A generated Lean file
that nobody compiles is a file, not a proof obligation. Run after
`lake build QuantumProofs`:

```bash
q() { cargo run --quiet -p quantum-core --bin quantum -- "$@"; }   # zsh-safe (no word-splitting of a "$CMD" string)
T=$(mktemp -d)
for spec in "examples/aria/bell.aria|Bell()|Bell" \
            "demo/02-qft/qft.aria|QFT(n=3)|QFT" \
            "demo/02-qft/qft.aria|IQFT(n=4)|IQFT"; do
  aria="${spec%%|*}"; rest="${spec#*|}"; inst="${rest%%|*}"; name="${rest##*|}"
  mkdir -p "$T/$name"
  q spec extract --aria "$aria" --instantiate "$inst" --out "$T/$name" >/dev/null
  out=$(cd proofs/lean4 && lake env lean "$T/$name/$name.lean" 2>&1)
  echo "$name errors=$(printf '%s' "$out" | grep -c 'error:') sorry_warnings=$(printf '%s' "$out" | grep -c 'declaration uses .sorry.')"
done
grep -c '\.cp '   "$T/QFT/QFT.lean"                       # 3   (controlled-phase now emitted)
grep -c '\.swap ' "$T/QFT/QFT.lean"                       # 1
grep -c '(-[0-9]' "$T/IQFT/IQFT.lean"                      # 6   (negative angles parenthesised)
grep -o '1\.5707963267948966\|0\.7853981633974483\|0\.39269908169872414' "$T/IQFT/IQFT.lean" | sort | uniq -c

# Refusal side: unbound trainable angles must NOT export (used to export as 0.0).
q spec extract --aria examples/aria/qml_classifier.aria \
     --instantiate "QMLClassifier(L=3)" --out "$T/qml"; echo "exit=$?"   # 1
ls "$T/qml" 2>/dev/null | wc -l                                            # 0 files
# An un-instantiated template is an empty circuit — also refused, exit 1.
q spec extract --aria demo/02-qft/qft.aria --instantiate "QFT" --out "$T/empty"; echo "exit=$?"
```

| Line | Expected | Tolerance |
|------|----------|-----------|
| `Bell errors=… sorry_warnings=…` | `errors=0 sorry_warnings=2` | exact |
| `QFT errors=… sorry_warnings=…` | `errors=0 sorry_warnings=2` (`assert_unitary_0`, `qft_equals_dft`) | exact |
| `IQFT errors=… sorry_warnings=…` | `errors=0 sorry_warnings=0` (no `@prove` on IQFT) | exact |
| `.cp` / `.swap` count in `QFT.lean` | `3` / `1` (7 gates, depth 6) | exact |
| parenthesised negative angles in `IQFT.lean` | `6` | exact |
| angle multiset in `IQFT.lean` | `3× 1.5707963267948966`, `2× 0.7853981633974483`, `1× 0.39269908169872414` (π/2, π/4, π/8) | exact |
| `QMLClassifier(L=3)` | refused, `exit=1`, message names all 9 `theta_0 … theta_8` as "no bound numeric value", `0` files written | exact |
| `--instantiate "QFT"` (no `n`) | refused, `exit=1` ("the circuit has no gates") | exact |

`sorry` warnings are the *point* — the obligations are meant to be open; only
`error:` lines fail the gate. CI stage 11f runs the elaboration loop verbatim
(needs Lean, so it lives under `QUANTUM_MATHLIB=1`); 11f′ asserts the refusal
and sits *outside* that gate — it only needs the binary, so every default
`./scripts/ci.sh` run exercises it. The emitter unit tests pin the same
behaviour in Rust.

**C5 mathlib `denote_pattern` layer (`MBQC_PLAN.md` §C5 steps 1–3 + 4a) —
sorry-free.** `MBQC.lean` now carries the deep mathlib-`Matrix` MBQC
denotation: the `Pattern` IR, `graphState = (∏ CZ_edges)·H^⊗n`, the `+`-branch
measurement projector `plusProj` (proved an orthogonal projector:
`plusProj_idem` ∧ `plusProj_herm`), `measLayer`, the raw operator
`denote_pattern_plus_raw`, and the output-restricted readout
`denote_pattern_plus`. Three concrete readout validations close
`native_decide`-free: `denote_pattern_plus_one_plus` (1-vertex `|+⟩` = `1/√2`),
`denote_pattern_plus_measured` (`+`-basis measure ⇒ `⟨+|+⟩ = 1`), and
`denote_pattern_plus_two_graph` (2-qubit graph state on edge `(0,1)` =
`½(|00⟩+|01⟩+|10⟩−|11⟩)`). `MBQC.lean` has **zero** sorries (the last one,
`gflow_determinism`, was closed 2026-06-03). Numeric check (after
`lake build QuantumProofs` succeeds):

```bash
M=proofs/lean4/QuantumProofs/MBQC.lean
grep -cE '^[[:space:]]+sorry[[:space:]]*$' "$M"                        # 0  (gflow_determinism since closed)
grep -cE 'theorem (plusProj_idem|plusProj_herm|denote_pattern_plus_one_plus|denote_pattern_plus_measured|denote_pattern_plus_two_graph)' "$M"  # 5
grep -cE '^(noncomputable )?def (graphState|measLayer|plusProj|denote_pattern_plus|denote_pattern_plus_raw|measBraWeight|vbit|outMatch|hadamardLayer|czLayer)' "$M"  # 10
```

**QSP LCU readout identity (`QSP.lean`, added 2026-08-05) — sorry-free.**
Encoded QSVT cannot read its polynomial off a `⟨Z̄⟩` measurement: that yields
`|U₀₀|` while the polynomial is `Re U₀₀` (measured `max|Im U₀₀| = 0.992`, see
§7.1f′). The recipe that does work is the LCU `(U_Φ + U_{−Φ})/2`, and these six
results prove it sound. Numeric check (after `lake build QuantumProofs`):

```bash
Q=proofs/lean4/QuantumProofs/QSP.lean
grep -cE '^[[:space:]]*sorry[[:space:]]*$' "$Q"                        # 0
grep -cE '^(theorem|lemma) (phase_map_conj|signal_map_conj|qsp_map_conj|qsp_neg_phases_conj|qsp_lcu_real|qsp_zero_zero_neg_s)' "$Q"   # 6
```

Axiom check — must list **only** `propext`, `Classical.choice`, `Quot.sound`
(any `sorryAx` is a regression):

```bash
cd proofs/lean4 && cat > /tmp/qsp_ax.lean <<'LEAN'
import QuantumProofs.QSP
open QuantumProofs.QSP
#print axioms qsp_neg_phases_conj
#print axioms qsp_lcu_real
LEAN
lake env lean /tmp/qsp_ax.lean
```

**Expect** both lines to read
`depends on axioms: [propext, Classical.choice, Quot.sound]`.

The same identity is checked numerically from the Rust side at
`max ‖conj(U_Φ) − U_{−Φ}‖ = 0.000e0` (§7.1f′ row 4), so proof and shipped code
are cross-checked rather than each verified only against itself.

### 8.3 Rocq 9.1.x — `QLibCompat` shim (CI stage 10)

Compiles **without** `coq-quantumlib` installed (the shim provides the
naming). Migration path documented in §"To migrate to real coq-quantumlib".

```bash
cd proofs/rocq
coqc -Q . QuantumProofs QLibCompat.v
coqc -Q . QuantumProofs Gates.v
coqc -Q . QuantumProofs QFT.v
coqc -Q . QuantumProofs Grover.v
```

Files:
- `Gates.v` — σ{x,y,z} self-inverse, XZ anti-commute, S² = Z
- `QFT.v` — 1-qubit QFT structural lemmas (off-diagonal symmetric, top row uniform)
- `Grover.v` — success probability ∈ [0, 1] via `SIN_bound` + `nra`

To migrate to real `coq-quantumlib` once it ships for Rocq 9.x: update
`proofs/rocq/dune` to `(theories QuantumLib Coq)` and delete
`QLibCompat.v` — every other file already uses QuantumLib-compatible naming.

---

## 9. Python wheel (PyO3 / maturin)

Mixed maturin layout: `crates/quantum-py/python/quantum_py/`
(pure-Python facade + bundled `quantum_py.client` socket client) +
compiled Rust extension `quantum_py._rust`. Python ≥ 3.8.

### 9.1 Editable dev loop

**Use an interpreter ≤ 3.13 — not bare `python3` when that is 3.14.** `pyo3 0.23`
supports Python ≤ 3.13. On the mac box `python3` is 3.14 and the build script
refuses with `the configured Python interpreter version (3.14) is newer than
PyO3's maximum supported version (3.13)`; on the Linux box `python3` is 3.12
(fine) and there is no `python3.13`. Pick whichever ≤ 3.13 interpreter exists. Behind a
TLS-intercepting proxy, `pip` needs `PIP_CERT=/path/to/ca.pem` (and `rustup`
`SSL_CERT_FILE=…`) or the wheel/toolchain fetches fail with certificate errors.
Building the venv from a 3.14 `python3` fails before maturin is even reached —
which is why §5.3/§9 sat unverified.

```bash
PY=$(command -v python3.13 || command -v python3.12)   # any ≤ 3.13 — see above
$PY -m venv .venv
source .venv/bin/activate
unset CONDA_PREFIX                      # if conda is active
source scripts/env.sh
pip install --upgrade pip maturin
cd crates/quantum-py && maturin develop --release && cd ../..
python python/examples/demo.py
```

Verified 2026-08-01 (`maturin 1.14.1`, debug `maturin develop`):

```
📦 Built wheel for CPython 3.13 to …/quantum_py-0.1.0-cp313-cp313-macosx_11_0_arm64.whl
🛠 Installed quantum-py-0.1.0
```

If no 3.13 interpreter is available, `PYO3_USE_ABI3_FORWARD_COMPATIBILITY=1`
builds against the stable ABI instead — enough for `cargo check`, but prefer a
real 3.13 venv for the wheel.

### 9.2 Binary-only wheel

```bash
cd crates/quantum-py && maturin build --release --strip && cd ../..
pip install --force-reinstall --no-deps target/wheels/quantum_py-*.whl

# Smoke-test the installed wheel
DYLD_LIBRARY_PATH=$LIBTORCH/lib python3 -c "
import quantum_py
c = quantum_py.bell(False)
print(quantum_py.recommended_backend(c))          # Stabilizer
obs = quantum_py.Observable.z(0).scale(0.5)
print(obs.n_terms())                              # 1
print(quantum_py.to_omega_ir(c)[:80], '...')
print(quantum_py.decode_mwpm(3, [1,0,0,0,0,0,0,0]))
print(quantum_py.client.Client)                   # socket client class
"
```

On Linux, use `LD_LIBRARY_PATH` instead of `DYLD_LIBRARY_PATH`.

### 9.3 Python smoke checklist

- [ ] `python3 -c "import quantum_py; print(quantum_py.__version__)"` → `0.1.0`
- [ ] `Observable.z(0).add(Observable.x(1)).scale(0.5).n_terms() == 2`
- [ ] `quantum_py.recommended_backend(bell(False)) == "Stabilizer"`
- [ ] `to_omega_ir(bell(False))` starts with `{"num_qubits":2,...`
- [ ] `optimize_with_passes(c, ["adjacent","adjoint"], 2)` drops identity/adjoint pairs
- [ ] `decode_mwpm(3, [0]*8) == ([], [], 0, True)`
- [ ] `decode_mwpm(3, [1,0,0,0,0,0,0,0])` → `([], [1], 1, True)` — layout is `(x_flips, z_flips, weight, decoded)`: the single flip lands in `z_flips`, weight 1, `decoded=True`
- [ ] `decode_mwpm(3, [1,0,0,0])` (wrong length) → `([], [], 0, False)` — **the
      fourth element is the point**: without it a refused decode is
      indistinguishable from a clean one on the Python side

> **Build note.** PyO3 0.23 supports Python ≤ 3.13. If the box's default
> `python3` is newer, `cargo check -p quantum-py` fails with "newer than PyO3's
> maximum supported version" — create the project venv on a supported
> interpreter (`python3.13 -m venv .venv`), which `scripts/ci.sh` stage 5 picks
> up automatically.
- [ ] `from quantum_py.client import Client` imports from the wheel
- [ ] `python python/examples/demo.py` and `full_demo.py` run unchanged

---

## 10. Release packaging

See `scripts/release/README.md` for full usage. TL;DR:

```bash
# Current machine, CPU, 90-day timebomb (default)
./scripts/release/build-host-cpu.sh

# 7-day evaluation bundle
QUANTUM_EXPIRY_DAYS=7 ./scripts/release/build-host-cpu.sh

# Cross-compile all CPU targets (skip missing toolchains)
SKIP_MISSING=1 ./scripts/release/build-all-cpu.sh

# GPU builds
LIBTORCH=/opt/libtorch-macos-arm64       ./scripts/release/build-host-gpu.sh
LIBTORCH_CUDA=/opt/libtorch-cu121        ./scripts/release/build-all-gpu.sh cuda
```

Fast end-to-end smoke:

```bash
rm -f dist/quantum-*-test-*.tar.gz   # clear old eval bundles only — a bare `rm -rf dist` also deletes the verified release tarballs
QUANTUM_EXPIRY_DAYS=7 ./scripts/release/build-host-cpu.sh
tar -tzf dist/quantum-*-cpu.tar.gz | head -20
./dist/stage-*-cpu/bin/quantum --help
```

Expected:
- Tarball in `dist/`
- Contains `bin/quantum`, `examples/aria/*.aria`, `examples/rust/*.rs`,
  `examples/wasm-guests/*/src/main.rs`, `docs/README.md`, `docs/TESTING.md`
- `./bin/quantum --help` prints usage + expiry banner on stderr (a 7-day build says `expires in 6 day(s)` — integer-day truncation, see below)

### 10.1 Timebomb matrix

The expiry is baked by `crates/quantum-core/build.rs` into the `quantum`
binary, so building that one bin exercises the identical code path the dist
ships (`build-dist.sh` sets the same variables before the same `cargo build`).
Every case below asserts an **exit code** and the **exact stderr line**.

> `build.rs` declares `cargo:rerun-if-env-changed`, so cargo will NOT rebuild
> when a variable is re-set to the value it already had — the binary keeps its
> previous bake and the test silently measures the wrong build. `touch
> crates/quantum-core/build.rs` before each case to force a fresh timestamp.

```bash
cd "$PROJECT_ROOT"
case_run() {                       # $1 = label, rest = env assignments
    local label="$1"; shift
    touch crates/quantum-core/build.rs
    # own target dir: the `expired` case must not leave a dead ./target/release/quantum behind
    env "$@" CARGO_TARGET_DIR=/tmp/tb cargo build -q --release -p quantum-core --bin quantum
    /tmp/tb/release/quantum rbs >/tmp/tb_out.txt 2>/tmp/tb_err.txt
    echo "$label exit=$? stderr=$(cat /tmp/tb_err.txt)"
    echo "  stdout_lines=$(wc -l < /tmp/tb_out.txt)"
}
case_run "days7  " QUANTUM_EXPIRY_DAYS=7
case_run "expired" QUANTUM_EXPIRY_UNIX=1
case_run "disabled" QUANTUM_EXPIRY_DAYS=0
case_run "minute1" QUANTUM_EXPIRY_MINUTES=1
```

| Case | Exit | stderr | stdout |
|------|------|--------|--------|
| `QUANTUM_EXPIRY_DAYS=7` | **0** | `quantum: this build expires in 6 day(s) (unix …). Rebuild from source to refresh.` | 7 lines (`rbs_parity_ok 1`) |
| `QUANTUM_EXPIRY_UNIX=1` | **2** | `quantum: this build expired <N> day(s) ago (unix 1). Rebuild from source.` | **0 lines** — aborts before any work |
| `QUANTUM_EXPIRY_DAYS=0` | **0** | *(empty — timebomb disabled)* | 7 lines |
| `QUANTUM_EXPIRY_MINUTES=1` | **0** | `quantum: this build expires in less than a minute (unix …). Rebuild …` | 7 lines |

Two details that look like bugs and are not:

- **`DAYS=7` reports "6 day(s)"**. `days_remaining = (EXPIRY_UNIX − now) / 86400`
  truncates, and the build consumed a few seconds, so 6 *whole* days remain.
- **`UNIX=1` reports ≈20.7k days (days since 1970-01-01 — date-dependent: 20694 on 2026-08-29)**. Expiry is the epoch itself, so the elapsed
  time is measured from 1970.

**Transition check** (proves the bomb actually fires rather than merely
printing a banner) — build with a 1-minute fuse, run twice around it:

```bash
touch crates/quantum-core/build.rs
# Own target dir, for the same reason case_run above uses one: this build
# EXPIRES mid-test, and dropping it on ./target/release/quantum would leave
# a dead binary behind that breaks every later `cargo run` step in this
# manual (7.1a-g) and ci.sh stage 7.
QUANTUM_EXPIRY_MINUTES=1 CARGO_TARGET_DIR=/tmp/tb2 \
    cargo build -q --release -p quantum-core --bin quantum
/tmp/tb2/release/quantum rbs >/dev/null 2>&1; echo "fresh exit=$?"   # 0
sleep 70
/tmp/tb2/release/quantum rbs >/tmp/x.txt 2>&1; echo "after exit=$?"  # 2
grep -c rbs_parity_ok /tmp/x.txt                                     # 0
```

Expected: `fresh exit=0`, `after exit=2`, and `0` — the expired binary
produces no output at all, not merely a warning.

### 10.1a Evaluation bundle — qubit caps (`QUANTUM_TEST=1`)

The customer eval bundle (`QUANTUM_TEST=1`, the `*-test` tarball shipped with
`demo/`) bakes **two** independent qubit caps:

- `QUANTUM_MAX_QUBITS` — general circuit cap (default **12**). Refuses any
  general `info`/`compile`/simulation over the cap.
- `QUANTUM_ECC_MAX_QUBITS` — separate cap for `quantum ecc` (default **64** in
  test mode). The surface-code demo needs 13 qubits at d=3, 37 at d=5, 49 at
  d=7, so it gets its own ceiling while general simulation stays capped at 12.
  Defaults to `QUANTUM_MAX_QUBITS` when unset; `0` = unlimited (normal builds).

Numeric checks against a `QUANTUM_TEST=1` bundle (`QUANTUM_MAX_QUBITS=12`,
`QUANTUM_ECC_MAX_QUBITS=64`):

Build the bundle first — verifying an old tarball proves nothing about HEAD:

```bash
source scripts/env.sh
QUANTUM_TEST=1 ./scripts/release/build-dist.sh cpu
V=$([ "$(uname -s)" = Darwin ] && echo mac-cpu || echo linux-cpu)   # artefact name follows the host
T=$(ls -t dist/quantum-dist-$V-test-*.tar.gz | head -1)             # the bundle just built
./scripts/release/verify-dist.sh "$T"
D=/tmp/evalcheck && rm -rf $D && mkdir -p $D
tar xzf "$T" -C $D
Q=$D/dist-$V-test/bin/quantum
# No 12/13-qubit fixtures ship — generate two H-layers (n qubits, n gates, depth 1).
# Run `$Q …` unpiped: piping into `head` closes the pipe early and the binary exits 101 (EPIPE panic).
for n in 12 13; do { echo 'OPENQASM 2.0;'; echo 'include "qelib1.inc";'; echo "qreg q[$n];"; for i in $(seq 0 $((n-1))); do echo "h q[$i];"; done; } > /tmp/q$n.qasm; done
```

| Command | Expected | Exit |
|---|---|---|
| `verify-dist.sh "$T"` | `manifest: N files, sha256 OK` (N is host-specific — 116 mac / 117 linux at 33d82b9; the `sha256 OK` is the check), `0 toolkit source files`, `VERIFY OK` | 0 |
| `$Q ecc --distance 7 --backend pauliprop` | `single_error_decode 98/98`, `logical_failure 0` (49 ≤ ecc cap 64) | 0 |
| `$Q ecc --distance 9 --backend pauliprop` | `limited to 64 qubit(s); refusing a 81-qubit circuit` | **2** |
| `$Q info /tmp/q12.qasm` | runs, `Qubits: 12` — **at** the cap, accepted | 0 |
| `$Q info /tmp/q13.qasm` | `limited to 12 qubit(s); refusing a 13-qubit circuit` | **2** |
| `cat $D/dist-$V-test/TEST-BUILD.txt` | `Qubit cap : 12 qubits general / 64 qubits for 'quantum ecc'` | 0 |

The 12-qubit row is the one that matters and is easy to omit: testing only the
13-qubit refusal cannot distinguish a correct `n > cap` from an off-by-one
`n >= cap` that would reject the very size the bundle advertises. Both rows
must be run.

### 10.1b Cross-built Linux bundles — `ecc` is inert (skips)

`quantum ecc` links the `omega-functions` backends, which only compile in a
**native** build. A `cross` (Docker) Linux build ships `ecc` inert (it prints a
rebuild hint and exits 2), so `demo/12-ecc` **skips cleanly** there. Because the
omega backends are *optional path deps in a sibling workspace*, the cross
container must mount it for lockfile resolution — `Cross.toml` exposes
`OMEGA_FUNCTIONS_DIR`, which `build-dist.sh` sets automatically for cross builds.

```bash
# from the mac box: cross-build the Linux eval bundles (ecc inert)
QUANTUM_TARGET=x86_64-unknown-linux-gnu  QUANTUM_TEST=1 ./scripts/release/build-dist.sh cpu
QUANTUM_TARGET=aarch64-unknown-linux-gnu QUANTUM_TEST=1 ./scripts/release/build-dist.sh cpu
# on the Linux/CUDA box: amd64 is NATIVE (ecc live, finance bundlable); only
# arm64 goes through cross — rootless docker needs the engine flag or the
# container trips on the /target mount ("Permission denied … .cargo-build-lock"):
CROSS_ROOTLESS_CONTAINER_ENGINE=1 QUANTUM_TARGET=aarch64-unknown-linux-gnu \
  QUANTUM_TEST=1 ./scripts/release/build-dist.sh cpu
# verify in a stock container (numbers only): all demos pass; 03/06-08 skip.
# Cross-built bundles additionally skip 12/13 (ecc inert); a NATIVE amd64
# bundle (built on the Linux box) runs 12/13 live in the same container.
docker run --rm --platform linux/amd64 -v "$PWD/dist":/qx:ro debian:bookworm-slim bash -c '
  mkdir -p /tmp/q && tar xzf "$(ls -t /qx/quantum-dist-linux-amd64-cpu-test-*.tar.gz | head -1)" -C /tmp/q   # newest only — with several bundles a bare glob makes tar treat the extras as member names
  export QUANTUM_DIST="$(ls -d /tmp/q/dist-*)" && bash "$QUANTUM_DIST/demo/run-all.sh"'
# -> ALL DEMOS PASSED  (03 skips: no cargo; 06-08: no libtorch)
```

**Per-demo verdict shape (enforced by `run-all.sh` itself since 2026-08-29,
and by `ci.sh` stage 7b2 under `QUANTUM_DIST=1`).** `ALL DEMOS PASSED` used to
mean only "no script returned non-zero"; it now also requires each demo to end
in `OK — N check(s) passed` with `N` at or above its pin, or to take one of the
named skip paths. The two lines before the banner are the roll-call — read them:

```bash
# after run-all.sh, on a host with cargo + libtorch + a NATIVE **gpu** bundle (the CI boxes):
# ran 14: 01-bell=6 02-qft=3 03-rust-harness=1 04-qos=3 05-optimizer=4 06-finance=5 07-qml-qcbm=2
#         08-qml-classifier=2 09-mbqc=4 10-ubqc=2 11-lean4=5 12-ecc=19 13-pauliprop=9 14-logical=15
# skipped 0: none   (08 reports 3 on a CUDA host: extra GPU-DNN check — needs the gpu bundle;
#                    on a cpu bundle 08 step 3 can only skip, so cpu bundle + DEMO_REQUIRE_ALL=1
#                    is unsatisfiable by construction — measured on the Linux box 2026-08-29)
# ALL DEMOS PASSED
# with a NATIVE **cpu** bundle on the same host, demo 08 step 4 takes its skip path
# ("(skip) binary reports CPU — GPU training needs the gpu bundle (+ cu128 libtorch)"),
# so the roll-call is one shorter — this is correct, not a regression (measured 2026-09-03):
# ran 13: … 07-qml-qcbm=2 09-mbqc=4 …     (no 08-qml-classifier entry)
# skipped 1: 08-qml-classifier            (2 ✓ before the skip)
# ALL DEMOS PASSED
# in the stock container above (no cargo, no libtorch):
# ran 10: 01-bell=6 02-qft=3 04-qos=3 05-optimizer=4 09-mbqc=4 10-ubqc=2 11-lean4=5 12-ecc=19 13-pauliprop=9 14-logical=15
# skipped 4: 03-rust-harness 06-finance 07-qml-qcbm 08-qml-classifier   (07/08 still prove the untrained-export refusal: 1 ✓ each before the skip)
# A demo below its pin prints e.g. "✗ 02-qft FAILED (shape drift: OK — 1, pinned minimum 3)" and the run
# ends SOME DEMOS FAILED (exit 1). DEMO_REQUIRE_ALL=1 makes any skip a failure.
```

**Mac bundles and the libtorch demos (06/07/08).** `build-dist.sh` does not
require `LIBTORCH`: a mac `-test` bundle built without it silently omits
`bin/quantum-finance`, and 06/07/08 then take their skip paths even on a host
that *has* libtorch — still `ALL DEMOS PASSED` unless `DEMO_REQUIRE_ALL=1`.
Build with `source scripts/env.sh` (or `LIBTORCH` exported) before pinning
these demos. Measured 2026-08-29, mac-cpu **and** mac-metal bundles at
`ade28f2`, `DEMO_REQUIRE_ALL=1`: `06-finance=5 07-qml-qcbm=2
08-qml-classifier=2` — matching the roll-call pins above.

### 10.2 Binary-only dist — numeric manual test (REQUIRED)

> This is the **canonical** way to run this manual: against the shipped,
> stripped, source-free distribution — not `cargo run`. Numbers only.
> Landed 2026-05-30 (item 0b): `scripts/release/build-dist.sh` +
> `verify-dist.sh`.

**Dist variants we ship (item 0b).** Four artefacts. **Mac variants are
built & tested on the mac dev box; Linux variants (`linux-cpu` +
`linux-cuda`) are built & tested on the Linux/CUDA box** (no cross-compile
of libtorch-linked binaries; see `LINUX_GPU_PLAN.md`). Run this manual on
the host that matches the variant you built.

| Variant | OS | Accel | Script | Build host |
|---|---|---|---|---|
| `mac-metal`  | macOS (Apple Silicon) | Metal (MPS) | `build-dist.sh metal`| mac dev box |
| `mac-cpu`    | macOS (Apple Silicon) | CPU only    | `build-dist.sh cpu`  | mac dev box (sanity) |
| `linux-cpu`  | Linux x86_64          | CPU only    | `build-dist.sh cpu`  | Linux/CUDA box |
| `linux-cuda` | Linux x86_64          | CUDA        | `build-dist.sh cuda` | Linux/CUDA box (NVIDIA) |
| `linux-gpu`  | Linux x86_64          | CUDA (vendor-neutral tag) | `build-dist.sh gpu` | Linux/CUDA box (NVIDIA) |
| `*-delegate-opencl` | either         | OpenCL via delegation | `build-dist.sh delegate-opencl` | either (CPU binaries + `OMEGA_SERVER_URL` doc) |

> **`gpu` arg + finance CUDA.** `build-dist.sh gpu` is the host GPU build under
> a vendor-neutral tag (Linux ⇒ cuda build, Darwin ⇒ metal build). On Linux,
> any cuda-kind build with `LIBTORCH` set compiles the bundled `quantum-finance`
> `--features cuda` (force-links `libtorch_cuda.so`; `--device cuda` ⇒
> `Device::Cuda(0)`; pair with the cu128 libtorch 2.7.0). Setting
> `QUANTUM_TARGET` to the **host triple** keeps the build native (finance +
> omega-sim ecc enabled) and opts into the arch-tagged name the
> quantum-examples repo ships, e.g. `linux-amd64-gpu`.

`delegate-opencl` (GPU_PLAN Phase 10.3) ships the same libtorch-free binaries
as `cpu`; OpenCL is reached at runtime via `OMEGA_SERVER_URL` delegation (see
`docs/OPENCL-DELEGATE.md` inside the bundle). Verify it exactly like the others:

```bash
SOURCE_DATE_EPOCH=1700000000 ./scripts/release/build-dist.sh delegate-opencl
./scripts/release/verify-dist.sh dist/quantum-dist-*-delegate-opencl-*.tar.gz
# Expect: manifest sha256 OK, 0 source files, run.sh "RUN OK ... Qubits=2, H-count=1".
# Bundle includes docs/OPENCL-DELEGATE.md (MANIFEST 64 vs 63 files; ≈0.5 KB larger gzip'd — the doc is ~1.6 KB uncompressed).
```

Build the variant for the current host, then verify through the unpacked
binaries. The commands below derive the variant tag from the OS so they
work verbatim on either host (`mac-cpu` on Darwin, `linux-cpu` on Linux):

```bash
# 0. Variant tag for THIS host (Darwin -> mac, Linux -> linux).
case "$(uname -s)" in Darwin) V=mac-cpu ;; Linux) V=linux-cpu ;; esac

# 1. Build the binary-only dist for THIS host's build type.
./scripts/release/build-dist.sh cpu          # CPU-only  -> dist/quantum-dist-$V-<sha>.tar.gz
#   SOURCE_DATE_EPOCH defaults to the HEAD commit time inside the script (build-dist.sh:145),
#   so this is already the reproducible form; set it explicitly only to pin across commits (§10.5).
# ./scripts/release/build-dist.sh metal      # macOS GPU  (V=mac-metal)
# ./scripts/release/build-dist.sh cuda        # Linux + NVIDIA (V=linux-cuda)

# 2. Verify: manifest sha256s + no-source guard + numeric run.sh end-to-end.
#    (Pin the freshest tarball — the glob can match several if dist/ has stale ones.)
./scripts/release/verify-dist.sh "$(ls -t dist/quantum-dist-$V-*.tar.gz | head -1)"   # exit 0
```

> **Linux tar note (item 0b).** The reproducible tar step branches on `$OS`:
> GNU tar (Linux) uses `--owner=0 --group=0`; bsdtar (macOS) uses
> `--uid 0 --gid 0`. GNU tar rejects `--uid` (exit 64 → empty 20-byte
> tarball), so this branch is what makes `linux-cpu`/`linux-cuda` package
> correctly. If a future tarball comes out ~20 bytes, that branch regressed.

`verify-dist.sh` unpacks, re-checks every file's sha256 against
`MANIFEST.txt`, asserts **no source leaked**, then runs the bundled
`run.sh`. You can also run `run.sh` by hand:

```bash
case "$(uname -s)" in Darwin) V=mac-cpu ;; Linux) V=linux-cpu ;; esac
D=$(mktemp -d); tar xzf "$(ls -t dist/quantum-dist-$V-*.tar.gz | head -1)" -C "$D"
ROOT="$D/dist-$V"
"$ROOT/run.sh"          # starts packaged server, pings it, checks Bell stats
```

**Numeric checks (no GUI), all asserted by `verify-dist.sh` / `run.sh`:**
- `verify-dist.sh` exits `0` and prints `manifest: N files, sha256 OK` +
  `guard: 0 toolkit source files found (demo/ excluded)`.
- `run.sh` starts `bin/quantum-server`, pings it (the server returns
  `{"pong": <build_unix>}` — under `SOURCE_DATE_EPOCH` this is the pinned
  epoch, i.e. the HEAD commit time for a default `build-dist.sh` run or
  `1700000000` in ci.sh, not the wall clock), then runs `bin/quantum info examples/bell.qasm`
  and asserts the **exact** statistics: **Qubits = 2, H-count = 1**. It
  prints `RUN OK …` on success and exits non-zero otherwise.
- (The standalone server does ping/info/parse/optimize/compile — circuit
  *execution*/counts is the omega-server's job, out of this bundle. The
  numeric contract here is the deterministic CLI statistics, not sampled
  counts.)

Two builds with the same `SOURCE_DATE_EPOCH` **and the same absolute expiry**
produce **identical sha256** for the tarball (verified: `ci.sh` `QUANTUM_DIST=1`
pins `QUANTUM_EXPIRY_UNIX=4102444800`, re-runs the build after a
`touch crates/quantum-core/build.rs`, and diffs the sha). MANIFEST per-file
sha256 is the primary reproducibility contract.

> **Why the expiry matters.** `build.rs` bakes the timebomb as an *absolute*
> instant, so the default relative window (`QUANTUM_EXPIRY_DAYS=90`) is
> re-derived from the wall clock every time the build script runs — two
> builds 2 s apart gave `5e6da305…` vs `a154b331…` on 2026-08-29, and the
> ci.sh probe had only ever passed because cargo cached the build-script
> output between its two runs. `SOURCE_DATE_EPOCH` pins the build stamp
> (`QUANTUM_BUILD_UNIX`) and the tar mtimes, nothing else. For a
> sha-reproducible dist set `QUANTUM_EXPIRY_UNIX` (absolute) or
> `QUANTUM_EXPIRY_DAYS=0`; `build-dist.sh` prints `timebomb: …` and records the
> mode in `MANIFEST.txt`, and warns when it is `relative … NOT reproducible`.
> Numeric check of the pin itself (≈2 min, own target dir):
>
> ```bash
> export CARGO_TARGET_DIR=/tmp/tb SOURCE_DATE_EPOCH=1700000000 QUANTUM_EXPIRY_UNIX=4102444800
> b() { cargo build -q --release -p quantum-core --bin quantum; sha256sum /tmp/tb/release/quantum | cut -c1-16; }
> A=$(b); touch crates/quantum-core/build.rs; sleep 2; B=$(b); [ "$A" = "$B" ] && echo REPRO OK || echo "REPRO FAIL $A $B"
> ```
> Expected: `REPRO OK`. Repeat with `QUANTUM_EXPIRY_UNIX` unset and
> `QUANTUM_EXPIRY_DAYS=90` → `REPRO FAIL` (the two hashes differ) — that is
> the wall-clock expiry, and is expected.

> **Reproducible from a PAIR of shas, not one (found 2026-09-04).** The probe
> above — and ci.sh 7b2 — build twice *in one moment*, which cannot catch an
> input that only moves between sessions. With `omega-sim` on (every native
> bundle) the four omega backends compile in from the **sibling
> `../aria-quantum-language-oss` checkout**, and nothing in the artefact used
> to record which revision that was. Measured: quantum `ade28f2` with
> identical pins (`SOURCE_DATE_EPOCH=1788066806`,
> `QUANTUM_EXPIRY_UNIX=1796083200`, same `LIBTORCH`) built
> `ab80112c…`/`ad05da95…` on 2026-09-01 and `d97fe552…`/`af3f5905…` on
> 2026-09-04 — the sibling had advanced in between. Both builds were correct;
> the *claim* "reproducible from ade28f2" was not.
> `MANIFEST.txt` now records `omega_sha:` and `libtorch:` beside `git_sha:`,
> so a bundle states every source input it has. A **core** bundle reproduces
> from the pair `(git_sha, omega_sha)`; a **finance-bearing** one (any
> `-test` bundle built with `LIBTORCH` set) reproduces from the **triple**,
> because `quantum-finance` dynamically links libtorch — upgrade the runtime
> and the binary changes with nothing else to explain it. (`bin/quantum` links
> no torch; only `bin/quantum-finance` does.) A sibling with uncommitted
> changes is recorded `<sha>-DIRTY` and is not reproducible at all. Inputs
> that genuinely do not apply read `not-linked`, so a *missing* field always
> means "bundle predates the field", never "did not matter". Numeric check:
>
> ```bash
> grep -E '^(git_sha|omega_sha|libtorch):' dist/dist-*/MANIFEST.txt
> # git_sha: <quantum sha>   omega_sha: <sibling sha>[-DIRTY] | not-linked
> # libtorch: <version> (<accel>) | not-linked
> ```
>
> **The build REFUSES a dirty sibling (2026-09-04).** Recording `-DIRTY` makes
> an unreproducible bundle legible; it does not stop one being built and
> shipped, and those are the same fact from two ends. Uncommitted sibling
> source cannot be checked out again by anyone, so such a bundle is
> unreproducible by construction and no later diligence repairs it — that is
> exactly what cost the 09-01 mac bundles their provenance. So `build-dist.sh`
> exits 1 before building, names the dirty files, and points at the override:
>
> ```bash
> # with uncommitted changes in ../aria-quantum-language-oss:
> ./scripts/release/build-dist.sh cpu ; echo "exit=$?"
> # ERROR: sibling aria-quantum-language-oss has uncommitted changes (<sha>-DIRTY).
> # exit=1                                    ← refuses BEFORE any compilation
> QUANTUM_DIST_ALLOW_DIRTY=1 ./scripts/release/build-dist.sh cpu ; echo "exit=$?"
> # exit=0, and MANIFEST carries `omega_sha: <sha>-DIRTY`; verify-dist prints
> #   provenance: quantum=…, omega=<sha>-DIRTY — NOT reproducible (sibling had uncommitted changes)
> #               libtorch=… (informational — this bundle cannot be reproduced)
> ```
>
> Scoped to the dist path deliberately: a dirty sibling during ordinary work is
> another session mid-edit and none of this script's business. `ci.sh` 7b2 sets
> the override, because its dist is a throwaway reproducibility probe and CI
> must not go red because someone is editing a *different* repository — the
> `-DIRTY` mark still lands in the probe's MANIFEST either way. Test the gate
> against a **clone** of the sibling, never the live checkout; another session
> may be working in it.
>
> **`ci.sh` 7b3 covers this automatically, and had to.** Because 7b2 sets the
> override, a CI run on a day when the real sibling is clean never reaches the
> refusal branch at all — on 2026-09-04 the first green run "covering the gate"
> proved only that setting the override does not disturb the happy path. So
> 7b3 runs *unconditionally* against a **scratch** sibling it dirties on
> purpose, and asserts three cases: dirty+no-override refuses with exit 1 and
> names the dirty files; dirty+override proceeds and still records `-DIRTY`;
> clean does not fire (a gate that fires on everything is not a gate). It
> shadows `cargo` with a stub, so case 1 also proves the refusal lands
> **before** compilation rather than after burning a release build. Nothing
> compiles: the stage costs ~2 s and needs no toolchain.
>
> The stage was mutation-tested before being trusted — remove the gate, make it
> ignore the override, or move it after the build, and 7b3 goes red on each,
> with the unmutated script green. A gate whose test has never been seen to
> fail is the thing this whole section exists to distrust.
>
> **Verified end-to-end (2026-09-04):** the Linux box rebuilt `ade28f2`
> against aria-oss `eaebb45` in a fresh worktree with the same pins and
> recovered `linux-amd64-cpu-test` **byte-exactly**
> (`95d2fda2…074211`, diffed against the surviving original, not a
> remembered value). Two traps that run exposed, both worth repeating:
> a worktree must be a **sibling** of `aria-quantum-language-oss` (the path
> deps are `../../../`, so a worktree under `/tmp` silently resolves
> nowhere), and `LIBTORCH` must be exported or `build-dist.sh` omits the ten
> quantum-finance payload files and the sha mismatches for a reason that has
> nothing to do with provenance — it says so in its own log
> (`finance: LIBTORCH unset — skipping quantum-finance`).

---

## Troubleshooting

### libtorch / tch-rs

| Symptom | Cause | Fix |
|---------|-------|-----|
| `libtorch not found` | `LIBTORCH` unset | `source scripts/env.sh` |
| `tch version mismatch` | Wrong libtorch version | `./scripts/setup-libtorch.sh` pulls the pinned 2.7.0 (matches tch 0.20) |
| CUDA tests all *skip* on an NVIDIA box | `libtorch_cuda.so` not `DT_NEEDED` (linker `--as-needed`) | rebuild `--features cuda` (build.rs forces it); check `readelf -d <testbin> \| grep cuda` |
| `CUDA error: no kernel image` | cu124/2.4.0 libtorch on a Blackwell GPU | reinstall with `setup-libtorch.sh cu128` (2.7.0) |
| `dyld: Library not loaded` (macOS) | `DYLD_LIBRARY_PATH` missing | `source scripts/env.sh` re-exports it |
| `cannot find -ltorch` (Linux) | `LD_LIBRARY_PATH` missing | `source scripts/env.sh` |
| `CXX11 ABI mismatch` (Linux) | Wrong libtorch variant | Use the `cxx11-abi` zip — `setup-libtorch.sh` already does this |
| `wrong architecture` (macOS) | Intel libtorch on Apple Silicon | Re-run `./scripts/setup-libtorch.sh` (auto-detects arm64) |
| Slow first build | torch-sys C++ compile | Normal — ~30s one-time |

### Python / maturin

| Symptom | Fix |
|---------|-----|
| `VIRTUAL_ENV + CONDA_PREFIX` warning | `unset CONDA_PREFIX` before `maturin develop` |
| `PyO3 link error` | Use `maturin develop`, **not** `cargo build -p quantum-py` |
| `ModuleNotFoundError: quantum_py._rust` | Re-run `maturin develop --release` from `crates/quantum-py/` |
| `pip install fails on wheel` (Linux) | Set `LD_LIBRARY_PATH=$LIBTORCH/lib` before `pip install` |

### Lean / mathlib

| Symptom | Fix |
|---------|-----|
| `lake: command not found` | Install elan: `curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh \| sh` |
| `Mathlib.olean missing` | `./scripts/setup-mathlib.sh` (pulls precompiled oleans) |
| `lake exe cache get` is slow | Normal — ~500 MB download; runs once |
| Stage 11 `mathlib setup failed` / `external command 'git' exited with code 128` with a warm cache | `setup-mathlib.sh` fell through to `lake update` (network). Since 2026-08-29 the up-to-date check is content-based (olean tree complete + lakefile `@ "<tag>"` == manifest `inputRev` + every `.lake/packages/<pkg>` HEAD == its `lake-manifest.json` rev + `lean-toolchain` match) and never needs the network on a warm cache. The exact drifted condition is printed as `cache stale: <reason>` on stderr (ci.sh echoes the last lines of the script's output on failure). Re-run online with `--force` to re-resolve. |
| Stage 11 `mathlib-backed proofs failed to compile` | ci.sh echoes the last lines of `lake build QuantumProofs`; reproduce with `cd proofs/lean4 && lake build QuantumProofs`. A `lake update`/git error here means a manifest package drifted after the setup check — `./scripts/setup-mathlib.sh` prints which. |
| Toolchain version mismatch | The proof dir has its own `lean-toolchain`; `cd proofs/lean4 && lean --version` triggers elan to install the pin |
| Stage 11 fails with new sorries | Check `TODO.md` §1b/2/3 + `MBQC_PLAN.md` C3 — the whole `QuantumProofs` root is **sorry-free** (0 in every file as of 2026-07-31), so ANY live `sorry` is a regression |

### Rocq

| Symptom | Fix |
|---------|-----|
| `coqc: command not found` | macOS: `brew install rocq-prover`; Linux: opam path in §3.2 |
| `Cannot find QuantumLib` | Should not happen — proofs use `QLibCompat.v` shim, not real QuantumLib. Re-check you ran `coqc QLibCompat.v` first |
| Version < 9.1 | The shim targets Rocq 9.1; older versions need opam upgrade |

### WASM

| Symptom | Fix |
|---------|-----|
| `wasm32-wasip1 target not installed` | `rustup target add wasm32-wasip1` |
| `.wasm size > 1 MB` | Re-run with `--release`; debug builds are large |

### CI script (`./scripts/ci.sh`)

| Symptom | Fix |
|---------|-----|
| Stage 4 skipped | `LIBTORCH` unset — `source scripts/env.sh` then re-run |
| Stage 7 example failure | Run the failing example directly: `cargo run -p quantum-core --example <name>` to see real error |
| Stage 9 fails | `lean --run Standalone.lean` — should print "23 total" |
| Stage 10 skipped | `coqc` not installed |
| Stage 11 skipped | Not opt-in — set `QUANTUM_MATHLIB=1 ./scripts/ci.sh` |

---

## Adding tests

- Unit tests → `#[cfg(test)] mod tests` inside each source file
- Integration tests → `crates/<crate>/tests/`
- Single test: `cargo test -p quantum-core <test_name>`
- With output: `cargo test -- --nocapture`
- Lean test: add a `#guard` or `example : … := by …` line; CI stage 9 runs the file
- Rocq test: add a `Lemma/Theorem`; stage 10 will compile it

When adding a new example, append its name to the `EXAMPLES` array in
`scripts/ci.sh` (stage 7) so it runs in CI.

### Writing a gate that can actually fail

Five rules, each earned by a gate in this repo or its sibling that looked green
while measuring nothing. They are written down because the pressure to remove them arrives from
a reasonable-sounding direction â "this assertion is redundant", "this case is
covered elsewhere" â and the failure they prevent is silent.

1. **Watch it fail before you commit it.** Run the gate through its *negative*
   case deliberately: break the thing it guards and confirm it goes red. A gate
   nobody has seen fail is a gate nobody has tested.

2. **Run the silent cases too.** A gate that fires on everything is not a gate.
   `no stale dist in the auto-discovery path` was exercised in all three states
   â no bundle (silent), bundle at HEAD (silent), stale bundle (fires) â and it
   is the two silent ones that distinguish a gate from an always-fail.

3. **Assert the MECHANISM, not just the outcome.** This is the one that gets
   cut. `ci.sh` 7b3 case 1 asserts both "exit 1" *and* "no compilation started"
   (via a `cargo` stub that records being called). Written as `assert exit 1`
   alone it would have passed forever against a gate that **could not fire** â
   which is exactly what happened: an `export QUANTUM_DIST_ALLOW_DIRTY=1` two
   stages earlier persisted, the gate never ran, and only the mechanism
   assertion noticed. *A gate that cannot fire is indistinguishable from a gate
   that never needed to.*

4. **A negative assertion needs a liveness anchor.** `grep -q FOO && fail` also
   passes when the command produced no output at all â a crash reads as a pass.
   Pair every "this must not appear" with something that must.

5. **Print what the gate searched AND what it does not check.** Two scans of the same docs reported
   5 citations and 38 â neither wrong, resolving different things, with nothing
   in either output saying so. That class of defect normally needs a *second
   independent implementation* to become visible, which is why it survives: one
   tool alone always looks complete. A gate that states its own blind spot makes
   the mismatch visible on inspection instead. Examples already in the tree: the
   colour-slope gate names its `p` window and shot count; the cross-check runner
   reports non-trivial syndrome counts alongside the agreement rate, because
   agreement over all syndromes would measure how often the error was
   undetectable rather than whether the decoders agree; and
   `tools/qec_cross_check/README.md` states outright that a green CI run does
   **not** cover the installer, since a populated venv short-circuits it.

   **State the search scope too, not only the exclusions.** A gate with two
   internal resolvers rooted differently â one at `proofs/`, one at the repo
   root â is self-consistent on both sides and green, and nothing internal can
   expose the narrowness: it took a citation accidentally landing in the gap
   between them. Printing `rooted at <X> and <Y>` would have shown it on every
   run without the accident. This is the same rule as the exclusions, applied to
   inputs rather than outputs: *a gate should state what it searched, not only
   what it skipped.*

Two environment traps behind rule 3, both hit here:

* **`export` persists for the rest of `ci.sh`.** A stage's meaning can be
  changed at a distance by an export several hundred lines above it. Use
  `env -u VAR` at the point of use rather than relying on position â a test
  that controls its own environment does not depend on the script staying tidy.
* **A pipe replaces the exit status.** `cmd | tail` reports `tail`'s status, not
  `cmd`'s, so `set -o pipefail` (already on, see the header) is load-bearing â
  and in ad-hoc shell *without* it, redirect to a file and check `$?` instead.
