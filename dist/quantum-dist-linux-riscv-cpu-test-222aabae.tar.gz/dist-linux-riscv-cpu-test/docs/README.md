# Quantum

A **quantum programming toolkit in pure Rust** — circuit construction, optimization, simulation, a
QML/ML over-layer (libtorch via `tch-rs`), a pure-Rust photonics engine, a finance lab, formal
verification export (Lean 4 + Rocq), and a reproducible binary distribution. Integrates with
[omega-functions](https://github.com/Anzaetek/omega-functions).

**9 crates** · ~**78 Rust + 36 Aria examples** · **25 paper reproductions** (16 gate-model + 9
photonic — [24 distinct papers](docs/reproduced-papers.md#what-these-checks-actually-verify), two
entries share one arXiv id) · **Lean 4 + Rocq proofs** (whole proof root sorry-free) ·
**local CI, no GitHub** (`./scripts/ci.sh`). See [`STATUS.md`](STATUS.md) for the full test
breakdown and [`TESTING.md`](TESTING.md) for the numeric-only testing manual.

## Crates

| Crate | What |
|-------|------|
| `quantum-core` | AST (symbolic params, annotations, 8 formats), 13 optimizer passes, circuit builders, ECC + MWPM, MBQC/UBQC, **Quantum Oracle Sketching** (`qos`), `quantum` CLI + `quantum-server` RPC |
| `quantum-macros` | `circuit!` proc-macro DSL |
| `quantum-qml` | Statevector simulator (mid-circuit measure+reset), tch-rs `QuantumLayer` (parameter-shift autograd), CMA-ES, surrogate trainer, GPU-aware tensor sim, and the **scaling-QML** tracks (MMD, RFF surrogates, JL sketch, IQP Born machine) |
| `quantum-photonics` | Pure-Rust linear-optical **Fock/SLOS** engine (beam splitters + phase shifters → permanents), boson sampling, **photonic generative model** |
| `quantum-data` | Loaders (CSV/DuckDB), feature engineering, HMM, GBDT, TPE, copula/AR(1) transforms |
| `quantum-backtest` | Walk-forward backtesting (`backtest() → PnL / Sharpe / max-drawdown`) — pure Rust |
| `quantum-finance` | Finance-lab CLI: QCBM, TimeGAN, regime classification, architecture search |
| `quantum-qpu` | QPU provider abstraction (`QpuProvider`) over the in-tree runtime |
| `quantum-py` | PyO3 bindings (maturin) + stdlib-only socket client |

## What's inside

### Quantum programming
- 30+ gate types; **symbolic parameters** (`ParamExpr`), annotations (Assert/Prove/Requires/…),
  composition (`>>`, `|`, repeat, inverse), and the `circuit!` macro.
- **Exporters:** QASM 2.0 · OPTICQASM · JSON · `.qc` · omega-IR · C-ABI FFI · **Lean 4** · **Rocq**.
- **Optimizer passes:** identity/adjacent/adjoint-pair cancellation, rotation/T merging,
  commutation reordering, gate decomposition, Clifford+T pipeline, Tket2 (optional).
  Every pass is gated against the statevector on random circuits, with per-pass
  coverage asserted. *(`FastTMerge` and `PhasePolyDedup` were removed 2026-08-13:
  both silently deleted gates — see `STATUS.md`.)*
- **Builders:** Bell/GHZ/QFT/QPE, Trotter (H₂/Ising/Heisenberg), photonic (Clements/MZI), QSVT, LCU
  block encoding, QML encodings (Angle/IQP/hardware-efficient), Shor + EC-DLP (secp256k1 estimate).

### QML & GPU (libtorch via `tch-rs`)
- `QuantumLayer` with parameter-shift gradients flowing through tch autograd; adjoint reverse-mode AD.
- **Device-aware** statevector sim: CPU (complex128) · Apple **Metal/MPS** · **CUDA** (+ fused NVRTC
  kernels ≥10×) · batched parameter sweeps · OpenCL delegation to omega.
- CMA-ES (pure Rust), surrogate training.

### Scaling-QML (train-on-classical / deploy-on-quantum, and more-qubits)
- **RFF surrogates** of quantum models + **Johnson–Lindenstrauss sketch → quantum-kernel classifier**.
- **IQP Born machine** — poly-time analytic MMD training (transfer-matrix `⟨Z_S⟩` certified ≤1e-10
  vs statevector), scales to many qubits; sampling deploys on a QPU.
- **Photonic generative model** — MMD-trained interferometer; deploy = boson sampling.
- **Quantum Oracle Sketching** (`quantum qos`) — emulated oracle-from-samples with the O(1/N²)
  sample-complexity law (Babbush et al. 2026, emulated).

### Paper reproductions
- **16 gate-model** (`cargo run -p quantum-qml --example papers_runner`) and **9 photonic**
  (`--example photonic_papers`), each printing a headline metric with PASS/FAIL.
- **What the bars mean:** these check *our implementation* against each paper's **mechanism and
  mathematics** — they are **not** compared against the papers' published numbers. The strongest
  are genuine cross-model certifications (e.g. `iqp_born`: an O(n) transfer-matrix ⟨Z_S⟩ against an
  O(2ⁿ) statevector at ≤1e-10); others are training-convergence smoke tests that a broken engine
  can still pass. Per-entry tiering, including the ones that cannot fail:
  [`docs/reproduced-papers.md`](docs/reproduced-papers.md#what-these-checks-actually-verify).

### Finance lab (the trading substrate)
- Regime classification (HMM + supervised DNN/QNN), QCBM/TimeGAN generative models, walk-forward
  backtest with PnL/Sharpe/drawdown, real XAUUSD fixture — all numeric-checked.

### MBQC / UBQC, ECC, formal verification
- Measurement-based + blind (BFK) quantum computation.
- **Codes:** repetition, Steane `[[7,1,3]]`, rotated surface `[[d²,1,d]]` (MWPM),
  triangular 6.6.6 **colour** `[[7/19/37,1,d]]` (exact + BP+OSD), punctured Reed–Muller
  `[[15,1,3]]` (transversal T = logical T†, 15-to-1 distillation run on a backend),
  and Bacon–Shor `[[n²,1,n]]` — the one **subsystem** code, which measures only
  weight-2 gauge operators to get weight-`2n` stabilizers.
- **Lean 4** (mathlib-backed) + **Rocq** proofs; the whole `QuantumProofs` root is
  **sorry-free** (verified: 0 live `sorry` lines across all files).

### Distribution
- Reproducible **binary-only dist** (`scripts/release/build-dist.sh`): `mac-metal`, `mac-cpu`
  (native, mac box), `linux-amd64-cpu`, `linux-amd64-gpu` (native, Linux box), `linux-arm64-cpu`
  and `linux-riscv-cpu` (cross-built via `cross`, executed under qemu for verification). Every
  bundle embeds the omega simulator backends of the sibling Aria Quantum OSS checkout (`ecc`,
  `expect`, `logical` run live on all six). `SOURCE_DATE_EPOCH` + absolute timebomb + sha256
  `MANIFEST.txt`; `verify-dist.sh` re-hashes, runs the bundled numeric smoke in a matching
  container, and proves the qubit cap and expiry **from the binaries** (a 13-qubit circuit must
  be refused; the server's pong must report the pinned expiry). Evaluation bundles ship in the
  `quantum-examples` repo.

## Quick start

```bash
# Setup libtorch (required for quantum-qml / quantum-finance)
./scripts/setup-libtorch.sh && source scripts/env.sh

# Guided ~5-minute numeric demo (quantum exec → papers → finance → scaling-QML → QOS → Lean export)
./scripts/demo.sh

# Finance/trading story on real XAUUSD: regime (HMM) → classify (DNN) → QCBM + TimeGAN → backtest
./scripts/demo-finance.sh

# Local CI — the single source of truth (no GitHub Actions). ~19 min full.
./scripts/ci.sh

# Quantum examples
cargo run -p quantum-core --example shor
cargo run -p quantum-qml  --example iqp_born_demo       # scaling-QML
cargo run -p quantum-core --example qos_sketch_demo     # Quantum Oracle Sketching

# Reproduced-paper parity
cargo run -p quantum-qml        --example papers_runner   # 16/16
cargo run -p quantum-photonics  --example photonic_papers # 6/6

# CLI (libtorch-free dist binary)
cargo run -p quantum-core --bin quantum -- info circuit.qasm
cargo run -p quantum-core --bin quantum -- compile circuit.qasm --format lean4 -o circuit.lean
cargo run -p quantum-core --bin quantum -- qos            # Quantum Oracle Sketching
```

## Documentation

- [`docs/aria-tutorial.md`](docs/aria-tutorial.md) — **tutorial for the Aria quantum language**
- [`demo/`](demo/) — **customer demo subfolders**: Aria/QASM models + minimal Rust/shell harnesses that run against the **binary-only dist** (`demo/run-all.sh`)
- [`docs/DEMO.md`](docs/DEMO.md) — **guided customer demo walkthrough** (breadth tour + trading story)
- [`STATUS.md`](STATUS.md) — current test counts and crate status
- [`TESTING.md`](TESTING.md) — numeric-only manual testing manual (every result checked against a value)
- [`TODO.md`](TODO.md) — work plan and phases
- [`docs/`](docs/) — GPU design, reproduced-papers, spec-extraction, finance-lab, UBQC
- [`INSTALL_LIBTORCH.md`](INSTALL_LIBTORCH.md) — libtorch installation

## Conventions

Pure Rust (no Python in the toolkit core; libtorch via `tch-rs`). Examples ship in **both** Rust and
Aria DSL. Acceptance is **numeric** (counts, probabilities, eigenvalues vs golden tolerances). CI is
**local only** — `./scripts/ci.sh`, never GitHub. Formal proofs in Lean 4 (+ mathlib) and Rocq.
See [`CLAUDE.md`](CLAUDE.md) for the full working rules.
