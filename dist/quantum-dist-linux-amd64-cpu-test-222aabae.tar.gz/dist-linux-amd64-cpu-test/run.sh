#!/usr/bin/env bash
# End-to-end NUMERIC smoke for the binary-only dist. No GUI, numbers only.
# Starts quantum-server, pings it, and checks `quantum info` statistics on
# the bundled Bell circuit against known-exact values.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOCK="$(mktemp -u /tmp/quantum-dist-XXXXXX.sock)"
fail() { echo "RUN FAIL: $1" >&2; exit 1; }

# 1. Server starts + responds to ping (pong carries the build unix time).
"$HERE/bin/quantum-server" --listen "unix:$SOCK" &
SRV=$!
trap 'kill $SRV 2>/dev/null || true; rm -f "$SOCK"' EXIT
for _ in $(seq 1 50); do [ -S "$SOCK" ] && break; sleep 0.1; done
[ -S "$SOCK" ] || fail "server socket not created"
# The shipped quantum-client binary speaks the length-prefixed JSON-RPC natively —
# no python/jq/nc on the host (clients/client.sh is an optional shell fallback).
PONG="$("$HERE/bin/quantum-client" --socket "unix:$SOCK" ping 2>/dev/null || true)"
echo "ping -> $PONG"
echo "$PONG" | grep -q 'pong' || fail "server did not pong"

# 1b. Baked constants, read back through the SHIPPED binaries and compared to
# the pins build-dist.sh recorded in MANIFEST.txt / TEST-BUILD.txt. Those files
# are written by the host script from its own environment; the numbers below
# come out of the binary. Up to 174f7242 the two disagreed on every cross-built
# bundle (uncapped, wall-clock expiry) and nothing here noticed. The values are
# substituted at bundle time (1792310726 etc.); 0 means "not pinned".
BUILD_EXPECT=1792310726
EXPIRY_EXPECT=1801440000
CAP_EXPECT=12
PONG_BUILD="$(echo "$PONG" | sed -n 's/.*"pong": *\([0-9][0-9]*\).*/\1/p' | head -1)"
PONG_EXPIRY="$(echo "$PONG" | sed -n 's/.*"expiry": *\([0-9][0-9]*\).*/\1/p' | head -1)"
[ "$PONG_BUILD" = "$BUILD_EXPECT" ] \
    || fail "build stamp in the binary is $PONG_BUILD, MANIFEST says source_date_epoch $BUILD_EXPECT (build env did not reach build.rs)"
if [ "$EXPIRY_EXPECT" != 0 ]; then
    [ "$PONG_EXPIRY" = "$EXPIRY_EXPECT" ] \
        || fail "expiry in the binary is $PONG_EXPIRY, MANIFEST/TEST-BUILD say $EXPIRY_EXPECT"
fi
echo "baked: build_unix=$PONG_BUILD expiry=$PONG_EXPIRY (from the server binary; match the recorded pins)"
if [ "$CAP_EXPECT" != 0 ]; then
    # A (cap+1)-qubit circuit must be refused by the shipped CLI with the
    # cap it claims. `info` is the lightest path through the cap check.
    N=$((CAP_EXPECT + 1))
    BIG="$(mktemp /tmp/quantum-dist-cap-XXXXXX)"
    {
        printf 'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[%d];\n' "$N"
        i=0; while [ "$i" -lt "$N" ]; do echo "h q[$i];"; i=$((i + 1)); done
    } > "$BIG"
    CAPOUT="$("$HERE/bin/quantum" info "$BIG" 2>&1 || true)"
    rm -f "$BIG"
    echo "$CAPOUT" | grep -q "limited to $CAP_EXPECT qubit(s); refusing a $N-qubit circuit" \
        || fail "qubit cap: a $N-qubit circuit was NOT refused by a cap-$CAP_EXPECT build (got: $(echo "$CAPOUT" | head -1))"
    echo "cap: $N-qubit circuit refused by the cap-$CAP_EXPECT build"
fi

# 2. CLI info on the Bell circuit — exact deterministic statistics.
INFO="$("$HERE/bin/quantum" info "$HERE/examples/bell.qasm")"
echo "$INFO"
QUBITS="$(echo "$INFO" | awk '/Qubits:/ {print $2}')"
HCOUNT="$(echo "$INFO" | awk '/H-count:/ {print $2}')"
[ "$QUBITS" = "2" ] || fail "expected Qubits=2, got $QUBITS"
[ "$HCOUNT" = "1" ] || fail "expected H-count=1, got $HCOUNT"

# 2b. Quantum Oracle Sketching through the stripped CLI — the scaling-QML work
# ships in the libtorch-free binary. Checks the O(1/N^2) sample-complexity law.
# Small dim (6 index qubits) so the smoke also passes under a capped dist-test.
QOS="$("$HERE/bin/quantum" qos --dim 64)"
echo "$QOS" | grep -E '^(n_qubits|error_ratio_2x|block_encoding_err) '
echo "$QOS" | grep -q "^n_qubits 6$"             || fail "qos n_qubits"
echo "$QOS" | grep -q "^error_ratio_2x 3.9999$"  || fail "qos O(1/N^2) law"
echo "$QOS" | grep -q "^block_encoding_err 0.00e0$" || fail "qos block-encoding"

# 3. Finance CLI (libtorch-linked) — SYNTHETIC backtest numeric anchor, when the
# binary is bundled AND a paired libtorch is loadable. Degrades to a skip
# (never a failure) so the core dist verifies without libtorch on the path.
if [ -x "$HERE/bin/quantum-finance" ]; then
    FIN="$(QF_BIN="$HERE/bin/quantum-finance" DATA_DIR="$HERE/examples/data" \
        bash "$HERE/examples/finance/run_backtest.sh" 2>/dev/null || true)"
    if echo "$FIN" | grep -q "FIN OK: backtest"; then
        echo "finance: synthetic backtest anchor OK"

        # 3b. GPU gate for the cuda-kind variants. Without it, `VERIFY OK` on
        # a linux-cuda tarball said nothing about the GPU: the anchor above is
        # a CPU backtest, so the bundle's ONE distinguishing feature went
        # untested by its own verifier.
        #
        # Uses `bench-device`, which is the only GPU path that works from a
        # dist. The obvious candidate — `regime-classify train --device cuda`,
        # which ci.sh stage 4c2 uses — CANNOT run here: it defaults to
        # `examples/data/xauusd_1d.csv`, real market data the bundle
        # deliberately never ships, and the bundled synthetic series has no
        # regime labels. `bench-device` needs no external data at all.
        #
        # Nested inside the anchor's SUCCESS branch on purpose. `readelf`
        # showing libtorch_cuda in DT_NEEDED only proves the binary was LINKED
        # against it, not that it is loadable — on a GPU host without libtorch
        # reachable the binary cannot start, and gating on readelf alone turned
        # that into a hard failure instead of the documented skip. The anchor
        # having just succeeded is the real proof that libtorch resolves.
        if command -v nvidia-smi >/dev/null 2>&1 \
           && readelf -d "$HERE/bin/quantum-finance" 2>/dev/null | grep -q libtorch_cuda; then
            # Rebuild the loader path from LIBTORCH exactly as
            # examples/finance/common.sh does: the stripped binary has no
            # LC_RPATH, so LIBTORCH (a plain var, not stripped by SIP) is what
            # the anchor above actually relies on.
            BD="$(LIBTORCH_BYPASS_VERSION_CHECK=1 \
                  LD_LIBRARY_PATH="${LIBTORCH:+$LIBTORCH/lib:}${LD_LIBRARY_PATH:-}" \
                  "$HERE/bin/quantum-finance" bench-device 2>/dev/null || true)"
            # Numeric contract: the GPU is reachable from the SHIPPED binary,
            # and on the `large` size it beats the CPU. Only `large` is
            # asserted — at the small `finance` size kernel-launch overhead
            # dominates and CUDA is legitimately slower.
            BD_CPU="$(echo "$BD" | sed -n 's/^size large device cpu train_ms //p')"
            BD_GPU="$(echo "$BD" | sed -n 's/^size large device cuda train_ms //p')"
            if echo "$BD" | grep -q "^cuda_available 1$" \
               && [ -n "$BD_CPU" ] && [ -n "$BD_GPU" ] \
               && awk "BEGIN{exit !($BD_GPU < $BD_CPU)}"; then
                echo "finance: GPU reachable from the dist binary (cuda_available 1; large: cuda ${BD_GPU}ms < cpu ${BD_CPU}ms)"
            else
                fail "cuda variant: bench-device did not reach the GPU (cuda_available/timings: ${BD:-none})"
            fi
        fi
    else
        echo "finance: skipped (quantum-finance present, libtorch not on path)"
    fi
fi

echo "RUN OK: server pong + Bell info (Qubits=2, H-count=1) + QOS O(1/N^2) verified numerically + baked pins/cap read back from the binaries"
