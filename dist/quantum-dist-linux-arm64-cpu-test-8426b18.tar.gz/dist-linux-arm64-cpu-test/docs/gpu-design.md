# GPU design memo (GPU_PLAN item 0, Phase 0.1)

> One-page design decisions for the GPU acceleration work. The full
> phased roadmap is [`GPU_PLAN.md`](../GPU_PLAN.md); the per-algorithm
> "should this be on GPU" verdicts are in
> [`gpu-acceleration.md`](./gpu-acceleration.md). This memo records the
> *architectural choices* the rest of the work builds on.

## 1. Two-track strategy (in-tree tch vs. omega delegation)

We do **both**, split by whether a gradient must flow:

1. **In-tree `tch`-backed statevector** for QML, where autograd /
   adjoint AD must stay local (training loops, layers, surrogate). The
   caller selects the device; `Cpu` always works, `Mps`/`Cuda` are
   feature-gated.
2. **Delegation to omega-functions GPU backends** over the existing JSON
   wire (`OmegaCircuitIR` → `omega-server /v1/quantum/execute`) for
   one-shot sample/expectation on large circuits and **OpenCL**.

Rationale: `tch` gives one API across Cpu/Mps/Cuda and keeps gradients
local; omega's OpenCL + cuStateVec are mature and hand-tuned — we do not
re-implement them. Both paths consume the same `OmegaCircuitIR` upstream.

### Why this split (the omega comparison)

omega-functions already ships every GPU *kernel* we would otherwise
write: `omega-backend-statevector-{cuda,metal,opencl}`,
`omega-backend-mps-{cuda,metal}`, Jones-style adjoint AD on Metal +
OpenCL, and a finished QML-AD GPU trainer (its GPU_PLAN Phase 4). So our
job is **not** kernels — it is (a) the in-tree device-aware sim that the
gradient flows through, and (b) wiring delegation to omega.

**Load-bearing measured fact** (omega GPU_PLAN Phase 4c, 2026-05-09):
on Apple Metal the GPU is **slower than CPU below n≈16–18** (their
14q/16p/256pt/100ep bench: Metal 197 s vs CPU 89.6 s = 0.455×). CPU wins
through n≈16 on dispatch overhead. Consequences for our ordering:

- Metal validation (Phase 2) is a **correctness** milestone, not a perf
  win at finance_lab's sizes (mostly n ≤ 12).
- The real payoff is **CUDA at large n (≥22)** and **batched gradient
  sweeps (Phase 6)** — batching 2k shifted circuits into one tensor op is
  the win that survives at small n.
- **OpenCL delegation (Phase 4) is nearly free** — omega already built
  and tuned it; we only wire the JSON executor.

## 2. Device abstraction: our own `SimDevice`, not `tch::Device`

Phase 0 introduces `quantum_qml::SimDevice { Cpu, Mps, Cuda }` and
`SimConfig { device, seed, enable_measurement }` (default `Cpu`,
measurement on). We deliberately keep **our own** enum rather than
re-exporting `tch::Device`:

- the CPU-only build (and the `cpu` dist variant) needs no libtorch
  device types in its public API;
- `Mps`/`Cuda` stay cleanly feature-gated (`metal` / `cuda`);
- a non-`Cpu` request before its phase lands debug-asserts and falls
  back to `Cpu` — **never silent wrong-device execution**.

The map `SimDevice → tch::Device` is internal and lands with
`TensorState` in Phase 1. `simulate_with_config(circuit, params, &cfg)`
is the device-agnostic entry point; in Phase 0 it delegates to the
existing `ndarray` CPU path (no behavioral change), and later phases
dispatch on `cfg.device`.

## 3. Tensor layout (Phase 1 decision, recorded now)

`TensorState` will hold the amplitudes as a **flat `[2^n]` complex64**
tensor and `reshape` to `[2, 2, …, 2]` (n axes) on demand for
single/two-qubit `einsum` contraction. Rationale: flat storage matches
the `ndarray` reference and the omega wire; per-gate reshape is a view
(no copy). MPS fallback: if `tch::Kind::ComplexFloat` is unsupported on
a given libtorch/MPS combo, fall back to an interleaved-real
`[2, 2^n] float32` layout (real/imag split) — benchmarked in Phase 2.

## 4. Gate kernel registry shape (Phase 1 decision)

Single source of truth for gate matrices: a small registry returning a
`[2,2]` (or `[4,4]`) complex tensor on the target device, built once and
cached per `(GateKind, rounded-params)` where params are static. The
`ndarray` `gate_matrix` in `simulator.rs` is the numerical reference the
tensor registry must match to ≤ 1e-10.

## 4b. MPS status (Phase 2 finding, 2026-05-30)

Measured on Apple M4 / libtorch 2.4.0:

- **float64 is unsupported on MPS** — so MPS uses `ComplexFloat` (float32),
  `Cpu`/`Cuda` use `ComplexDouble`. `TensorState` carries `rkind`
  accordingly; cross-checks use a ~1e-5 tolerance on MPS vs ≤1e-10 on CPU.
- **Complex-on-MPS reaches n = 16** (re-measured 2026-07-31, libtorch 2.7.0,
  Apple M4). The old note here said the `ComplexFloat` movedim/matmul path
  was correct only at **n ≤ 4** and **aborted at n ≥ 6** with a Metal
  `MPSNDArray ... buffer is not large enough` assertion (SIGABRT,
  uncatchable). **That is no longer true, and the ceiling that replaced it
  has a different cause.** Measured with
  `cargo run -p quantum-qml --features metal --example mps_probe -- <n>`:

  | n | max abs diff vs CPU | result |
  |---|---|---|
  | 2 … 8 | 2.1e-8 … 1.5e-8 | ok |
  | 10, 12, 14 | 8.9e-9, 5.1e-9, 3.0e-9 | ok |
  | 15, 16 | 2.6e-9, 1.5e-9 | ok |
  | **17+** | — | `Torch("MPS supports tensors with dimensions <= 16, but got 17")` |

- **The real limit is tensor RANK, not buffer size.** `TensorState` gives
  each qubit its own tensor axis, so an n-qubit state is a rank-n tensor and
  MPS refuses rank > 16. Consequences:
  - It is a **catchable Rust panic** (exit 101), not the uncatchable SIGABRT
    the old note described, so it can be probed in-process.
  - **The interleaved-real float32 rework would not lift it.** That rework
    (two real `[2^n]` tensors, `re' = Ur·re − Ui·im`, `im' = Ur·im + Ui·re`)
    addresses float64 and complex-op support, both of which already work
    here. Raising the ceiling means changing the *layout* — a flat `[2^n]`
    (or grouped-axis) state with gates applied by reshape/stride instead of
    one axis per qubit.
  - Accuracy is far better than the ~1e-5 this section used to assume for
    float32: ≤2.1e-8 everywhere measured, tightening as n grows.
  **Deferred:** per omega's measured data Metal loses to CPU below n≈16–18,
  and finance_lab is n ≤ 12, so a scaled MPS path is **off the critical
  path**. Captured as a follow-up.
- **tch-CPU overhead.** The tch `ComplexDouble` CPU path is ~17–25× slower
  than the hand-written `ndarray` simulator (see
  `bench-baselines/tensor-forward-*.json` vs `cpu-*.json`). The tch path's
  value is **device portability** (the same code targets CUDA in Phase 3),
  not CPU speed — on CPU the `ndarray` simulator stays the fast path.

## 5. What stays CPU

Per `gpu-acceleration.md`: stabilizer/Clifford, MWPM decoding, and
small-bond MPS stay CPU (weak GPU fit / sequential). GPU effort
concentrates on statevector evolution, batched gradient sweeps, and
photonic Fock-space evolution.

## Cross-references

- [`GPU_PLAN.md`](../GPU_PLAN.md) — phased roadmap (this memo = Phase 0.1)
- [`gpu-acceleration.md`](./gpu-acceleration.md) — per-algorithm verdicts
- `docs/bench-baselines/cpu-arm64-darwin-m4.json` — Phase 0.3 CPU baseline
- omega-functions `crates/omega-backend-statevector-{cuda,metal,opencl}/`
  — reference kernels the delegation path reuses
